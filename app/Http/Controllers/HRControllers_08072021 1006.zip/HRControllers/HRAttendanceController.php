<?php

namespace App\Http\Controllers\HRControllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;
use \Carbon\Carbon;
use Carbon\CarbonPeriod;
use Crypt;
use File;
use DateTime;
use DateInterval;
use DatePeriod;
use PDF;
use App\Models\HR\HREmployeeAttendance;
class HRAttendanceController extends Controller
{
    
    public function index(Request $request)
    {
        date_default_timezone_set('Asia/Manila');
        
        if($request->get('changedate') == true){
            
            $date = $request->get('changedate');

        }else{

            $date = date('Y-m-d');

        }
        
        $getMyid = DB::table('teacher')
            ->select('id')
            ->where('userid', auth()->user()->id)
            ->first();
        
        $employees = DB::table('teacher')
            ->select(
                'teacher.id',
                'teacher.firstname',
                'teacher.middlename',
                'teacher.lastname',
                'teacher.suffix',
                'teacher.picurl',
                'employee_personalinfo.gender',
                'usertype.id as usertypeid',
                'usertype.utype'
                )
            ->join('usertype','teacher.usertypeid','=','usertype.id')
            ->leftJoin('employee_personalinfo','teacher.id','=','employee_personalinfo.employeeid')
            ->where('teacher.deleted','0')
            ->where('teacher.isactive','1')
            ->where('teacher.isactive','1')
            // ->take(20)
            ->orderBy('lastname','asc')
            ->get();
          
    
        $detecttimeschedsetup = DB::table('deduction_tardinesssetup')
            ->where('status','1')
            ->first();

        $attendancearray = array();
        
        foreach($employees as $employee){

            $attendance = HREmployeeAttendance::getattendance($date, $employee);
            // return $attendance;
            array_push($attendancearray,(object)array(
                'employeeinfo'      => $employee,
                'attendance'        => (object)array(
                                            'in_am'             =>     $attendance->amin,
                                            'out_am'            =>     $attendance->amout,
                                            'in_pm'             =>     $attendance->pmin,
                                            'out_pm'            =>     $attendance->pmout,
                                            'taphistorystatus'  =>     $attendance->status
                                        )
            ));

        }
        if($request->get('changedate') == true){
            
            $attendance = array();

            return view('hr.attendance.changedate')
                ->with('currentdate',$date)
                ->with('attendance',$attendancearray);

        }else{
            // return $attendancearray;
            return view('hr.attendance.index')
                ->with('currentdate',$date)
                ->with('attendance',$attendancearray);

        }
    }
    public function gettimelogs(Request $request)
    {
        date_default_timezone_set('Asia/Manila');
        // return $request->all();

        $customtimesched = DB::table('employee_customtimesched')
            ->where('employeeid',$request->get('employeeid'))
            ->where('deleted','0')
            ->get();
        if(count($customtimesched) > 0)
        {
            if(strtolower(date('A', strtotime($customtimesched[0]->pmin))) == 'pm')
            {
                $customtimesched[0]->pmin = date('h:i:s', strtotime($customtimesched[0]->pmin));
            }
            if(strtolower(date('A', strtotime($customtimesched[0]->pmout))) == 'pm')
            {
                $customtimesched[0]->pmout = date('h:i:s', strtotime($customtimesched[0]->pmout));
            }
        }else{
            $customtimesched = array((object)[
                'amin'  => '08:00:00',
                'amout' => '12:00:00',
                'pmin'  => '01:00:00',
                'pmout' => '05:00:00'
            ]);
        }
        
        // $changedate = explode('-',$request->get('selecteddate'));

        // $date = $changedate[2].'-'.$changedate[0].'-'.$changedate[1];
        $date = $request->get('selecteddate');

        $employeeinfo = DB::table('teacher')
            ->where('id', $request->get('employeeid'))
            ->first();

        $taphistory = DB::table('taphistory')
            ->where('tdate', $date)
            ->where('studid', $request->get('employeeid'))
            ->where('utype', '!=','7')
            ->where('deleted','0')
            ->get();

        if(count($taphistory)>0)
        {
            foreach($taphistory as $tapatt)
            {
                $tapatt->mode = 0;
            }
        }

        $hr_attendance = DB::table('hr_attendance')
            ->where('tdate', $date)
            ->where('studid', $request->get('employeeid'))
			->where('deleted',0)
            ->get();

        if(count($hr_attendance)>0)
        {
            foreach($hr_attendance as $hratt)
            {
                $hratt->mode = 1;
            }
        }


        $checkifexists = collect();
        $checkifexists = $checkifexists->merge($taphistory);
        $checkifexists = $checkifexists->merge($hr_attendance);
        $checkifexists = $checkifexists->sortBy('ttime');
        $checkifexists = $checkifexists->unique('ttime');
        
        if(count($checkifexists)>0)
        {
            foreach($checkifexists as $log)
            {
                $log->ttime = date('h:i:s A',strtotime($log->ttime));
            }
        }

        // return $taphistory;
        return view('hr.attendance.timelogs')
            ->with('customtimesched', $customtimesched)
            ->with('employeeinfo', $employeeinfo)
            ->with('logs', $checkifexists);
    }
    public function addtimelog(Request $request)
    {
        date_default_timezone_set('Asia/Manila');

        $date = $request->get('selecteddate');

        $taphistory = DB::table('taphistory')
            ->where('tdate',$date)
            ->where('ttime',$request->get('timelog'))
            ->where('studid',$request->get('employeeid'))
			->where('tapstate',strtoupper($request->get('tapstate')))
			->where('deleted',0)
            ->where('utype', '!=','7')
            ->get();

        $hr_attendance = DB::table('hr_attendance')
            ->where('tdate',$date)
            ->where('ttime',$request->get('timelog'))
            ->where('studid',$request->get('employeeid'))
			->where('tapstate',strtoupper($request->get('tapstate')))
			->where('deleted',0)
            ->get();


        $checkifexists = collect();
        $checkifexists = $checkifexists->merge($taphistory);
        $checkifexists = $checkifexists->merge($hr_attendance);
        $checkifexists = $checkifexists->sortBy('ttime');
        $checkifexists = $checkifexists->unique('ttime');

        if(count($checkifexists) == 0)
        {
            DB::table('hr_attendance')
                ->insert([
                    'tdate'                 => $date,
                    'ttime'                 =>  $request->get('timelog'),
                    'tapstate'              => strtoupper($request->get('tapstate')),
                    'timeshift'             => strtoupper(date('A',strtotime($request->get('timelog')))),
                    'studid'                => $request->get('employeeid'),
                    'utype'                 => $request->get('usertypeid'),
                    // 'mode'                  => 1,
                    'createdby'             => auth()->user()->id,
                    'createddatetime'       => date('Y-m-d H:i:s')
                ]);

            return '1';
        }else{
            return '0';
        }
    }
    public function deletetimelog(Request $request)
    {
        date_default_timezone_set('Asia/Manila');
        DB::table('hr_attendance')
            ->where('id', $request->get('id'))
            ->update([
                'deleted'   => '1',
                'deletedby' => auth()->user()->id,
                'deleteddatetime'   => date('Y-m-d H:i:s')
            ]);
    }
    public function summaryindex(Request $request)
    {
        $employees = DB::table('teacher')
            ->select(
                'teacher.id',
                'teacher.firstname',
                'teacher.middlename',
                'teacher.lastname',
                'teacher.suffix',
                'teacher.picurl',
                'employee_personalinfo.gender',
                'usertype.id as usertypeid',
                'usertype.utype'
                )
            ->join('usertype','teacher.usertypeid','=','usertype.id')
            ->leftJoin('employee_personalinfo','teacher.id','=','employee_personalinfo.employeeid')
            ->where('teacher.deleted','0')
            ->where('teacher.isactive','1')
            ->where('teacher.isactive','1')
            // ->take(20)
            ->orderBy('lastname','asc')
            ->get();

        return view('hr.attendance.summaryindex')
            ->with('employees', $employees);
    }
    public function summarygenerate(Request $request)
    {
        if(is_string($request->get('id')))
        {
            $request->merge([
                'id'    => json_decode($request->get('id'))
            ]);
        }
        try{
            if(count($request->get('id')) == 0 )
            {                
                $request->request->remove('id');
            }
        }catch(\Exception $error)
        {
            if($request->get('id') == null)
            {
                $request->request->remove('id');
            }
        }
        
        // return $request->all();
        $dates = explode(' - ',$request->get('dates'));
        $datefrom   = $dates[0];
        $dateto   = $dates[1];

        $alldays        = array();

        $beginmonth             = new DateTime($datefrom);
    
        $endmonth               = new DateTime($dateto);

        $endmonth               = $endmonth->modify( '+1 day' ); 
        
        $intervalmonth          = new DateInterval('P1D');

        $daterangemonth         = new DatePeriod($beginmonth, $intervalmonth ,$endmonth);

        foreach($daterangemonth as $datemonth){

                array_push($alldays,$datemonth->format("Y-m-d"));

        }
        
        if(!$request->has('id') || count($request->get('id')) > 1)
        {
            if($request->has('id'))
            {
                $employees = DB::table('teacher')
                    ->select(
                        'teacher.id',
                        'teacher.firstname',
                        'teacher.middlename',
                        'teacher.lastname',
                        'teacher.suffix',
                        'teacher.picurl',
                        'employee_personalinfo.gender',
                        'usertype.id as usertypeid',
                        'usertype.utype'
                        )
                    ->join('usertype','teacher.usertypeid','=','usertype.id')
                    ->leftJoin('employee_personalinfo','teacher.id','=','employee_personalinfo.employeeid')
                    ->where('teacher.deleted','0')
                    ->where('teacher.isactive','1')
                    ->whereIn('teacher.id',$request->get('id'))
                    // ->take(20)
                    ->orderBy('lastname','asc')
                    ->get();
                    
            }else{
                $employees = DB::table('teacher')
                    ->select(
                        'teacher.id',
                        'teacher.firstname',
                        'teacher.middlename',
                        'teacher.lastname',
                        'teacher.suffix',
                        'teacher.picurl',
                        'employee_personalinfo.gender',
                        'usertype.id as usertypeid',
                        'usertype.utype'
                        )
                    ->join('usertype','teacher.usertypeid','=','usertype.id')
                    ->leftJoin('employee_personalinfo','teacher.id','=','employee_personalinfo.employeeid')
                    ->where('teacher.deleted','0')
                    ->where('teacher.isactive','1')
                    // ->take(20)
                    ->orderBy('lastname','asc')
                    ->get();
            }
            
            if(count($employees)>0)
            {
                foreach($employees as $employee)
                {
                        
                    $summarylogs = array();

                    $customamtimein = DB::table('employee_customtimesched')
                        ->where('employeeid', $employee->id)
                        ->where('deleted', 0)
                        ->first();

                    if(!$customamtimein)
                    {
                        $customamtimein = (object)array(
                            'amin'      => '08:00:00',
                            'amout'      => '12:00:00',
                            'pmin'      => '13:00:00',
                            'pmout'      => '17:00:00',
                        );
                    }

                    foreach($alldays as $day)
                    {
            
                        $taphistory = DB::table('taphistory')
                            ->where('studid', $employee->id)
                            ->where('deleted','0')
                            ->where('tdate', $day)
                            ->where('utype', '!=', 7)
                            ->orderBy('ttime','asc')
                            ->get();

                        if(count($taphistory)>0)
                        {
                            foreach($taphistory as $tapatt)
                            {
                                $tapatt->mode = 0;
                            }
                        }

                        $hr_attendance = DB::table('hr_attendance')
                            ->where('studid', $employee->id)
                            ->where('tdate', $day)
                            ->where('deleted',0)
                            ->orderBy('ttime','asc')
                            ->get();

                        if(count($hr_attendance)>0)
                        {
                            foreach($hr_attendance as $hratt)
                            {
                                $hratt->mode = 1;
                            }
                        }


                        $logs = collect();
                        $logs = $logs->merge($taphistory);
                        $logs = $logs->merge($hr_attendance);
                        $logs = $logs->sortBy('ttime');
                        $logs = $logs->unique('ttime');

                        $hours = 0;
                        $minutes = 0; 
                        $latehours = 0;
                        $lateminutes = 0;
                        if(count($logs)>0)
                        {
                            
                            if(collect($logs)->where('ttime','<','12:00:00')->count() > 0)
                            {
                                if(collect($logs)->where('tapstate','IN')->where('ttime','<','12:00:00')->first())
                                {
                                    $amttimeamin = collect($logs)->where('tapstate','IN')->where('ttime','<','12:00:00')->first()->ttime;
                                    $amtimein = $day.' '.$amttimeamin;
                                }else{
                                    
                                    if($customamtimein)
                                    {
                                        $amttimeamin = $customamtimein->amin;
                                        $amtimein = $day.' '.$customamtimein->amin;
                                    }else{
                                        $amttimeamin = '08:00:00';
                                        $amtimein = $day.' 08:00:00';
                                    }
                                }

                                $am_customtimein = new DateTime($amtimein);
                                $am_latetimein = new DateTime($day.' '.$customamtimein->amin);
                                $amlateinterval = $am_customtimein->diff($am_latetimein);
                                $lateh = $amlateinterval->format('%h');
                                $latem = $amlateinterval->format('%i');
                                
                                if($amttimeamin>$customamtimein->amin)
                                {
                                    $latehours+=$lateh;
                                    $lateminutes+=$latem;
                                }

                                if(collect($logs)->where('tapstate','OUT')->where('ttime','<','12:00:00')->last())
                                {
                                    $amtimeout = $day.' '.collect($logs)->where('tapstate','OUT')->where('ttime','<','12:00:00')->last()->ttime;
                                }else{
                                    
                                    $customamtimeout = DB::table('employee_customtimesched')
                                        ->where('employeeid', $employee->id)
                                        ->where('deleted', 0)
                                        ->first();
                
                                    if($customamtimeout)
                                    {
                                        $amtimeout = $day.' '.$customamtimeout->amout;
                                    }else{
                                        $amtimeout = $day.' 12:00:00';
                                    }
                                }
                                
                                $am_timein = new DateTime($amtimein);
                                $am_timeout = new DateTime($amtimeout);
                                $aminterval = $am_timein->diff($am_timeout);
                                 
                                $hours += $aminterval->format('%h');
                                $minutes += $aminterval->format('%i');
                            }
                            
                            /////
                            // return collect($logs)->where('ttime','>=','12:00:00')->count();
                            if(collect($logs)->where('ttime','>=','12:00:00')->count() > 0)
                            {
                                if(collect($logs)->where('tapstate','IN')->where('ttime','>=','12:00:00')->first())
                                {
                                    $pmtimein = $day.' '.collect($logs)->where('tapstate','IN')->where('ttime','>=','12:00:00')->first()->ttime;
                                }else{
                                    
                                    $custompmtimein = DB::table('employee_customtimesched')
                                        ->where('employeeid', $employee->id)
                                        ->where('deleted', 0)
                                        ->first();
                
                                    if($custompmtimein)
                                    {
                                        $pmtimein = $day.' '.$custompmtimein->pmin;
                                    }else{
                                        $pmtimein = $day.' 13:00:00';
                                    }
                                }
                                if(collect($logs)->where('tapstate','OUT')->where('ttime','>=','12:00:00')->last())
                                {
                                    $pmtimeout = $day.' '.collect($logs)->where('tapstate','OUT')->where('ttime','>=','12:00:00')->last()->ttime;
                                }else{
                                    
                                    $custompmtimeout = DB::table('employee_customtimesched')
                                        ->where('employeeid', $employee->id)
                                        ->where('deleted', 0)
                                        ->first();
                
                                    if($custompmtimeout)
                                    {
                                        $pmtimeout = $day.' '.$custompmtimeout->pmout;
                                    }else{
                                        $pmtimeout = $day.' 17:00:00';
                                    }
                                }
                                
                                $pm_timein = new DateTime($pmtimein);
                                $pm_timeout = new DateTime($pmtimeout);
                                $pminterval = $pm_timein->diff($pm_timeout);
                                 
                                $hours += $pminterval->format('%h');
                                $minutes += $pminterval->format('%i');
                            }
            
                        }
            
                        while($minutes>=60)
                        {
                            $hours+=1;
                            $minutes-=60;
                        }
                        while($lateminutes>=60)
                        {
                            $latehours+=1;
                            $lateminutes-=60;
                        }
                        $employee->amin = $customamtimein->amin;
                        $employee->amout = $customamtimein->amout;
                        $employee->pmin = $customamtimein->pmin;
                        $employee->pmout = $customamtimein->pmout;
                        
                        array_push($summarylogs, (object)array(
                            'date'      => $day,
                            'logs'      => $logs,
                            'latehours'     => $latehours,
                            'lateminutes'     => $lateminutes,
                            'hours'     => $hours,
                            'minutes'   => $minutes,
                        ));
                    }

                    $employee->logs = $summarylogs;
                }
            }

        }elseif(count($request->get('id')) == 1){

            $customamtimein = DB::table('employee_customtimesched')
                ->where('employeeid', $request->get('id')[0])
                ->where('deleted', 0)
                ->first();

            if(!$customamtimein)
            {
                $customamtimein = (object)array(
                    'amin'      => '08:00:00',
                    'amout'      => '12:00:00',
                    'pmin'      => '13:00:00',
                    'pmout'      => '17:00:00',
                );
            }
            $summarylogs = array();
    
            foreach($alldays as $day)
            {
    
            
                $taphistory = DB::table('taphistory')
                    ->where('studid', $request->get('id'))
                    ->where('deleted','0')
                    ->where('tdate', $day)
                    ->where('utype', '!=', 7)
                    ->orderBy('ttime','asc')
                    ->get();

                if(count($taphistory)>0)
                {
                    foreach($taphistory as $tapatt)
                    {
                        $tapatt->mode = 0;
                    }
                }

                $hr_attendance = DB::table('hr_attendance')
                    ->where('studid', $request->get('id'))
                    ->where('tdate', $day)
                    ->where('deleted',0)
                    ->orderBy('ttime','asc')
                    ->get();

                if(count($hr_attendance)>0)
                {
                    foreach($hr_attendance as $hratt)
                    {
                        $hratt->mode = 1;
                    }
                }


                $logs = collect();
                $logs = $logs->merge($taphistory);
                $logs = $logs->merge($hr_attendance);
                $logs = $logs->sortBy('ttime');
                $logs = $logs->unique('ttime');

                // if($day == '2021-06-19')
                // {
                //     return $logs;
                // }
                // $logs = DB::table('taphistory')
                //     ->where('studid', $request->get('id'))
                //     ->where('utype', '!=', 7)
                //     ->where('deleted','0')
                //     ->where('tdate', $day)
                //     ->get();
    
                $hours = 0;
                $minutes = 0; 
    
                if(count($logs)>0)
                {
                    
                    if(collect($logs)->where('ttime','<','12:00:00')->count() > 0)
                    {
                        if(collect($logs)->where('tapstate','IN')->where('ttime','<','12:00:00')->first())
                        {
                            $amtimein = $day.' '.collect($logs)->where('tapstate','IN')->where('ttime','<','12:00:00')->first()->ttime;
                        }else{
                            
        
                            if($customamtimein)
                            {
                                $amtimein = $day.' '.$customamtimein->amin;
                            }else{
                                $amtimein = $day.' 08:00:00';
                            }
                        }
                        if(collect($logs)->where('tapstate','OUT')->where('ttime','<','12:00:00')->last())
                        {
                            $amtimeout = $day.' '.collect($logs)->where('tapstate','OUT')->where('ttime','<','12:00:00')->last()->ttime;
                        }else{
                            
                            $customamtimeout = DB::table('employee_customtimesched')
                                ->where('employeeid', $request->get('id'))
                                ->where('deleted', 0)
                                ->first();
        
                            if($customamtimeout)
                            {
                                $amtimeout = $day.' '.$customamtimeout->amout;
                            }else{
                                $amtimeout = $day.' 12:00:00';
                            }
                        }
                        $am_timein = new DateTime($amtimein);
                        $am_timeout = new DateTime($amtimeout);
                        $aminterval = $am_timein->diff($am_timeout);
                         
                        $hours = $aminterval->format('%h');
                        $minutes = $aminterval->format('%i');
                    }
                    
                    /////
                    // return collect($logs)->where('ttime','>=','12:00:00')->count();
                    if(collect($logs)->where('ttime','>=','12:00:00')->count() > 0)
                    {
                        if(collect($logs)->where('tapstate','IN')->where('ttime','>=','12:00:00')->first())
                        {
                            $pmtimein = $day.' '.collect($logs)->where('tapstate','IN')->where('ttime','>=','12:00:00')->first()->ttime;
                        }else{
                            
                            $custompmtimein = DB::table('employee_customtimesched')
                                ->where('employeeid', $request->get('id'))
                                ->where('deleted', 0)
                                ->first();
        
                            if($custompmtimein)
                            {
                                $pmtimein = $day.' '.$custompmtimein->pmin;
                            }else{
                                $pmtimein = $day.' 13:00:00';
                            }
                        }
                        if(collect($logs)->where('tapstate','OUT')->where('ttime','>=','12:00:00')->last())
                        {
                            $pmtimeout = $day.' '.collect($logs)->where('tapstate','OUT')->where('ttime','>=','12:00:00')->last()->ttime;
                        }else{
                            
                            $custompmtimeout = DB::table('employee_customtimesched')
                                ->where('employeeid', $request->get('id'))
                                ->where('deleted', 0)
                                ->first();
        
                            if($custompmtimeout)
                            {
                                $pmtimeout = $day.' '.$custompmtimeout->pmout;
                            }else{
                                $pmtimeout = $day.' 17:00:00';
                            }
                        }
                        $pm_timein = new DateTime($pmtimein);
                        $pm_timeout = new DateTime($pmtimeout);
                        $pminterval = $pm_timein->diff($pm_timeout);
                         
                        $hours += $pminterval->format('%h');
                        $minutes += $pminterval->format('%i');
                    }
    
                }
    
                while($minutes>=60)
                {
                    $hours+=1;
                    $minutes-=60;
                }


                array_push($summarylogs, (object)array(
                    'date'      => $day,
                    'date'      => $day,
                    'logs'      => $logs,
                    'hours'     => $hours,
                    'minutes'   => $minutes,
                ));
            }
        }
        
        // return $summarylogs;

        if(!$request->has('exporttype'))
        {
            if(!$request->has('id') || count($request->get('id')) > 1)
            {
                return view('hr.attendance.summarylogs')
                    ->with('dates', $alldays)
                    ->with('employees', $employees);
            }elseif( count($request->get('id')) == 1){
                return view('hr.attendance.summaryemplogs')
                    ->with('logs', $summarylogs);
            }
        }else{
            
            $info = DB::table('teacher')
                    ->where('id', $request->get('id'))
                    ->first();

            if(!$request->has('id') || count($request->get('id')) > 1)
            {
                $alldays = collect($alldays)->toArray();
                $alldays = array_chunk($alldays, 5);
                
                if(strtolower(DB::table('schoolinfo')->first()->abbreviation) == 'ck')
                {
                    $employees = collect($employees)->toArray();
                    $employees = array_chunk($employees, 3);
                    // return $employees;
                    $pdf = PDF::loadview('hr/pdf/summaryattendance',compact('alldays','datefrom','dateto','employees'))->setPaper('portrait');
                }else{
                    $pdf = PDF::loadview('hr/pdf/summaryattendance',compact('alldays','datefrom','dateto','employees'))->setPaper('landscape');
                }
    
                return $pdf->stream('School Form 2');
            }elseif( count($request->get('id')) == 1){
                $pdf = PDF::loadview('hr/pdf/summaryattendanceemp',compact('summarylogs','datefrom','dateto','info'))->setPaper('portrait');
    
                return $pdf->stream('School Form 2');
            }
        }

    }
    // public function updatetime(Request $request)
    // {
    //     date_default_timezone_set('Asia/Manila');
    //         // return $request->all();
    //     $dateexplode = explode('-',$request->get('selecteddate'));
    //     $selecteddate = $dateexplode[2].'-'.$dateexplode[0].'-'.$dateexplode[1];
    //     // return $selecteddate;
    //     $checkifexists = Db::table('teacherattendance')
    //         ->where('teacher_id', $request->get('employeeid'))
    //         ->where('tdate', $selecteddate)
    //         ->get();

    //     if($request->get('amin') == "00:00"){

    //         $amin = null;

    //     }else{
            
    //         $amin = date('H:i:s', strtotime($request->get('amin').' AM'));
    //         // return $amin;
    //     }
    //     if($request->get('amout') == "00:00"){

    //         $amout = null;

    //     }else{

    //         $explodeamout = explode(':',$request->get('amout'));
    //         // return $explodeamout[0];
    //         if($explodeamout[0] == '12')
    //         {
    //             $amout =  date('H:i:s', strtotime($request->get('amout').' PM'));
    //             // return $amout;
    //         }
    //         else{
    //             $amout =  date('H:i:s', strtotime($request->get('amout').' AM'));
    //         }          

    //     }

    //     if($request->get('pmin') == "00:00"){

    //         $pmin = null;

    //     }else{
            
    //         $pmin = date('H:i:s', strtotime($request->get('pmin').' PM'));
    //         // return $pmin;
    //     }
    //     // return $checkifexists;
    //     if($request->get('pmout') == "00:00"){

    //         $pmout = null;

    //     }else{
            
    //         $pmout = date('H:i:s', strtotime($request->get('pmout').' PM'));

    //     }

    //     if(count($checkifexists) == 0){

    //         DB::table('teacherattendance')
    //             ->insert([
    //                 'teacher_id'    =>  $request->get('employeeid'),
    //                 'in_am'         =>  $amin,
    //                 'out_am'        =>  $amout,
    //                 'in_pm'         =>  $pmin,
    //                 'out_pm'        =>  $pmout,
    //                 'tdate'         =>  $selecteddate
    //             ]);

    //     }else{
            
    //         $hey = DB::table('teacherattendance')
    //             ->where('teacher_id',$request->get('employeeid'))
    //             ->where('tdate',$selecteddate)
    //             ->update([
    //                 'in_am'         =>  $amin,
    //                 'out_am'         =>  $amout,
    //                 'in_pm'         =>  $pmin,
    //                 'out_pm'         =>  $pmout
    //             ]);

    //     }
    //     return '1';
    // }
}
