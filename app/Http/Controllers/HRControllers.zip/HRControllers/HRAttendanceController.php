<?php

namespace App\Http\Controllers\HRControllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;
use \Carbon\Carbon;
use Carbon\CarbonPeriod;
use Crypt;
use File;
use DateTime;
use DateInterval;
use DatePeriod;
use App\Models\HR\HREmployeeAttendance;
class HRAttendanceController extends Controller
{
    
    public function index(Request $request)
    {
        date_default_timezone_set('Asia/Manila');
        
        if($request->get('changedate') == true){
            
            $changedate = explode('-',$request->get('changedate'));

            $date = $changedate[2].'-'.$changedate[0].'-'.$changedate[1];

        }else{

            $date = date('Y-m-d');

        }
        
        $getMyid = DB::table('teacher')
            ->select('id')
            ->where('userid', auth()->user()->id)
            ->first();
        
        $employees = DB::table('teacher')
            ->select(
                'teacher.id',
                'teacher.firstname',
                'teacher.middlename',
                'teacher.lastname',
                'teacher.suffix',
                'teacher.picurl',
                'employee_personalinfo.gender',
                'usertype.id as usertypeid',
                'usertype.utype'
                )
            ->join('usertype','teacher.usertypeid','=','usertype.id')
            ->leftJoin('employee_personalinfo','teacher.id','=','employee_personalinfo.employeeid')
            ->where('teacher.deleted','0')
            ->where('teacher.isactive','1')
            ->where('teacher.isactive','1')
            // ->take(20)
            ->orderBy('lastname','asc')
            ->get();
          
    
        $detecttimeschedsetup = DB::table('deduction_tardinesssetup')
            ->where('status','1')
            ->first();

        $attendancearray = array();
        
        foreach($employees as $employee){

            $attendance = HREmployeeAttendance::getattendance($date, $employee);
            // return $attendance;
            array_push($attendancearray,(object)array(
                'employeeinfo'      => $employee,
                'attendance'        => (object)array(
                                            'in_am'             =>     $attendance->amin,
                                            'out_am'            =>     $attendance->amout,
                                            'in_pm'             =>     $attendance->pmin,
                                            'out_pm'            =>     $attendance->pmout,
                                            'taphistorystatus'  =>     $attendance->status
                                        )
            ));

        }
        if($request->get('changedate') == true){
// return $attendancearray;
            $attendance = array();

            return view('hr.attendance.changedate')
                ->with('currentdate',date('m-d-Y', strtotime($date)))
                ->with('attendance',$attendancearray);

        }else{
            // return $attendancearray;
            return view('hr.attendance.index')
                ->with('currentdate',date('m-d-Y', strtotime($date)))
                ->with('attendance',$attendancearray);

        }
    }
    public function gettimelogs(Request $request)
    {
        date_default_timezone_set('Asia/Manila');
        // return $request->all();

        $customtimesched = DB::table('employee_customtimesched')
            ->where('employeeid',$request->get('employeeid'))
            ->where('deleted','0')
            ->get();
        // return $customtimesched;
        if(count($customtimesched) > 0)
        {
            if(strtolower(date('A', strtotime($customtimesched[0]->pmin))) == 'am')
            {
                $customtimesched[0]->pmin = date('h:i:s', strtotime($customtimesched[0]->pmin.' PM'));
            }
            if(strtolower(date('A', strtotime($customtimesched[0]->pmout))) == 'am')
            {
                $customtimesched[0]->pmout = date('h:i:s', strtotime($customtimesched[0]->pmout.' PM'));
            }
        }else{
            $customtimesched = array((object)[
                'amin'  => '08:00:00',
                'amout' => '12:00:00',
                'pmin'  => '01:00:00',
                'pmout' => '05:00:00'
            ]);
        }
        
        $changedate = explode('-',$request->get('selecteddate'));

        $date = $changedate[2].'-'.$changedate[0].'-'.$changedate[1];

        $employeeinfo = DB::table('teacher')
            ->where('id', $request->get('employeeid'))
            ->first();

        $taphistory = DB::table('taphistory')
            ->where('tdate', $date)
            ->where('studid', $request->get('employeeid'))
            ->where('utype', $request->get('usertypeid'))
            ->where('deleted','0')
            ->get();

        if(count($taphistory)>0)
        {
            foreach($taphistory as $log)
            {
                $log->ttime = date('h:i:s A',strtotime($log->ttime));
            }
        }

        // return $taphistory;
        return view('hr.attendance.timelogs')
            ->with('customtimesched', $customtimesched)
            ->with('employeeinfo', $employeeinfo)
            ->with('logs', $taphistory);
    }
    public function addtimelog(Request $request)
    {
        date_default_timezone_set('Asia/Manila');
        // return date('H:i:s', strtotime($request->get('timelog').' '.strtolower($request->get('timeshift'))));
        // return $request->all();
        $changedate = explode('-',$request->get('selecteddate'));

        $date = $changedate[2].'-'.$changedate[0].'-'.$changedate[1];

        $checkifexists = DB::table('taphistory')
            ->where('tdate',$date)
            ->where('ttime',date('H:i:s A', strtotime($request->get('timelog'))))
            // ->where('ttime',date('H:i:s', strtotime($request->get('timelog').' '.strtolower($request->get('timeshift')))))
            ->where('studid',$request->get('employeeid'))
            ->where('utype',$request->get('usertypeid'))
            ->get();

        if(count($checkifexists) == 0)
        {
            if(strtolower($request->get('timeshift')) == 'pm')
            {
                $ttime = date('H:i:s', strtotime($request->get('timelog').' '.strtolower($request->get('timeshift'))));
            }
            else{
                $ttime = date('H:i:s', strtotime($request->get('timelog')));
            }
            DB::table('taphistory')
                ->insert([
                    'tdate'                 => $date,
                    'ttime'                 =>  $ttime,
                    // 'ttime'                 =>  date('H:i:s', strtotime($request->get('timelog').' '.strtolower($request->get('timeshift')))),
                    'tapstate'              => strtoupper($request->get('tapstate')),
                    'timeshift'             => strtoupper($request->get('timeshift')),
                    'studid'                => $request->get('employeeid'),
                    'utype'                 => $request->get('usertypeid'),
                    'mode'                  => 1,
                    'createdby'             => auth()->user()->id,
                    'createddatetime'       => date('Y-m-d H:i:s')
                ]);

            return '1';
        }else{
            return '0';
        }
    }
    public function deletetimelog(Request $request)
    {
        date_default_timezone_set('Asia/Manila');
        DB::table('taphistory')
            ->where('id', $request->get('id'))
            ->update([
                'deleted'   => '1',
                'deletedby' => auth()->user()->id,
                'deleteddatetime'   => date('Y-m-d H:i:s')
            ]);
    }
    // public function updatetime(Request $request)
    // {
    //     date_default_timezone_set('Asia/Manila');
    //         // return $request->all();
    //     $dateexplode = explode('-',$request->get('selecteddate'));
    //     $selecteddate = $dateexplode[2].'-'.$dateexplode[0].'-'.$dateexplode[1];
    //     // return $selecteddate;
    //     $checkifexists = Db::table('teacherattendance')
    //         ->where('teacher_id', $request->get('employeeid'))
    //         ->where('tdate', $selecteddate)
    //         ->get();

    //     if($request->get('amin') == "00:00"){

    //         $amin = null;

    //     }else{
            
    //         $amin = date('H:i:s', strtotime($request->get('amin').' AM'));
    //         // return $amin;
    //     }
    //     if($request->get('amout') == "00:00"){

    //         $amout = null;

    //     }else{

    //         $explodeamout = explode(':',$request->get('amout'));
    //         // return $explodeamout[0];
    //         if($explodeamout[0] == '12')
    //         {
    //             $amout =  date('H:i:s', strtotime($request->get('amout').' PM'));
    //             // return $amout;
    //         }
    //         else{
    //             $amout =  date('H:i:s', strtotime($request->get('amout').' AM'));
    //         }
            

    //     }

    //     if($request->get('pmin') == "00:00"){

    //         $pmin = null;

    //     }else{
            
    //         $pmin = date('H:i:s', strtotime($request->get('pmin').' PM'));
    //         // return $pmin;
    //     }
    //     // return $checkifexists;
    //     if($request->get('pmout') == "00:00"){

    //         $pmout = null;

    //     }else{
            
    //         $pmout = date('H:i:s', strtotime($request->get('pmout').' PM'));

    //     }

    //     if(count($checkifexists) == 0){

    //         DB::table('teacherattendance')
    //             ->insert([
    //                 'teacher_id'    =>  $request->get('employeeid'),
    //                 'in_am'         =>  $amin,
    //                 'out_am'        =>  $amout,
    //                 'in_pm'         =>  $pmin,
    //                 'out_pm'        =>  $pmout,
    //                 'tdate'         =>  $selecteddate
    //             ]);

    //     }else{
            
    //         $hey = DB::table('teacherattendance')
    //             ->where('teacher_id',$request->get('employeeid'))
    //             ->where('tdate',$selecteddate)
    //             ->update([
    //                 'in_am'         =>  $amin,
    //                 'out_am'         =>  $amout,
    //                 'in_pm'         =>  $pmin,
    //                 'out_pm'         =>  $pmout
    //             ]);

    //     }
    //     return '1';
    // }
}
