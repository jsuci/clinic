<?php

namespace App\Http\Controllers\HRControllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;
use Crypt;
class SetupController extends Controller
{
    public function requirementssetup($id,Request $request)
    {

        date_default_timezone_set('Asia/Manila');

        if($id == 'dashboard'){

            $gettypes = Db::table('employee_credentialtypes')
                ->where('deleted','0')
                ->get();

            return view('hr.settings.settingscredentialtypes')
                ->with('types', $gettypes);

        }
        elseif($id == 'addnew'){

            $createdby = DB::table('teacher')
                ->where('userid', auth()->user()->id)
                ->first();

            foreach($request->get('description') as $newcredential){

                $checkifExists = Db::table('employee_credentialtypes')
                    ->where('description','like','%'.$newcredential)
                    ->where('deleted','0')
                    ->get();
                
                if(count($checkifExists) == 0){

                    DB::table('employee_credentialtypes')
                        ->insert([
                            'description'       => strtoupper($newcredential),
                            'createdby'         => $createdby->id,
                            'createddatetime'   => date('Y-m-d H:i:s')
                        ]);

                }

            }

            return back();

        }
        else{

            if(Crypt::decrypt($id) == 'edit'){

                // return $request->all();
                DB::table('employee_credentialtypes')
                    ->where('id',$request->get('typeid'))
                    ->update([
                        'description'   => $request->get('description')
                    ]);

                return back();
    
            }
            elseif(Crypt::decrypt($id) == 'delete'){

                DB::table('employee_credentialtypes')
                    ->where('id',$request->get('typeid'))
                    ->update([
                        'deleted'   => '1'
                    ]);

                return back();

            }

        }


    }
    public function departmentssetup ($action, Request $request)
    {
        
        date_default_timezone_set('Asia/Manila');

        $my_id = DB::table('teacher')
            ->select('id')
            ->where('userid',auth()->user()->id)
            ->where('isactive','1')
            ->first();

        if($action == 'dashboard'){

            $departments = Db::table('hr_school_department')
                ->select(
                    'hr_school_department.*',
                    'teacher.lastname',
                    'teacher.firstname',
                    'teacher.middlename',
                    'teacher.suffix'
                )
                ->leftJoin('teacher','hr_school_department.created_by','=','teacher.userid')
                ->where('hr_school_department.deleted','0')
                ->orderByDesc('created_on')
                ->get();
            
            return view('hr.settings.department')
                ->with('departments',$departments);

        }
        elseif($action == 'adddepartment'){

            $checkifexists = Db::table('hr_school_department')
                ->where('department','like','%'.$request->get('department'))
                ->where('deleted','0')
                ->get();
                
            if(count($checkifexists) == 0){

                DB::table('hr_school_department')
                    ->insert([
                        'department'    => $request->get('department'),
                        'deleted'       => 0,
                        'created_by'    => auth()->user()->id,
                        'created_on'    => date('Y-m-d H:i:s')
                    ]);

                return redirect()->back()->with("messageAdded", $request->get('department').' department added successfully!');

            }
            else{

                return redirect()->back()->with("messageExists", $request->get('department').' already exists!');

            }

        }
        elseif($action == 'editdepartment'){
            
            Db::update('update hr_school_department set department = ?, updated_by = ?, updated_on = ? where id = ?',[$request->get('department'),$my_id->id,date('Y-m-d H:i:s'),$request->get('departmentid')]);

            return redirect()->back()->with("messageEdited", $request->get('department').' department updated successfully!');

        }
        elseif($action == 'deletedepartment'){
            
            Db::update('update hr_school_department set deleted = ?, updated_by = ?, updated_on = ? where id = ?',['1',$my_id->id,date('Y-m-d H:i:s'),$request->get('departmentid')]);

            return redirect()->back()->with("messageDeleted", $request->get('department').' department deleted successfully!');

        }

    }
    
    public function designationssetup($action, Request $request)
    {
        date_default_timezone_set('Asia/Manila');

        $my_id = DB::table('teacher')
            ->select('id')
            ->where('userid',auth()->user()->id)
            ->where('isactive','1')
            ->first();

        if($action == 'dashboard'){

            $departments = Db::table('hr_school_department')
                ->where('deleted','0')
                ->get();

            $designations = Db::table('usertype')
                ->select(
                    'usertype.id',
                    'usertype.utype as designation',
                    'departmentid',
                    'usertype.constant',
                    'hr_school_department.department as departmentname',
                    'teacher.lastname',
                    'teacher.firstname',
                    'teacher.middlename',
                    'teacher.suffix'
                    )
                ->where('usertype.deleted','0')
                ->leftJoin('teacher','usertype.created_by','=','teacher.userid')
                ->leftJoin('hr_school_department','usertype.departmentid','=','hr_school_department.id')
                ->where('usertype.utype','!=','PARENT')
                ->where('usertype.utype','!=','STUDENT')
                ->where('usertype.utype','!=','SUPER ADMIN')
                ->get();
                
            foreach($designations as $designation){

                if($designation->departmentid == null){

                    $designation->departmentid = 0;
                    $designation->departmentname = "";

                }
                
            }
            
            return view('hr.settings.designations')
                ->with('departments',$departments)
                ->with('designations',$designations);

        }
        elseif($action == 'adddesignation'){
            
            $checkifexists = Db::table('usertype')
                ->where('utype','like','%'.$request->get('designation'))
                ->where('deleted','0')
                ->get();
                
            if(count($checkifexists) == 0){

                $refid = DB::table('usertype')
                    ->insertGetId([
                        'utype'         => strtoupper($request->get('designation')),
                        'departmentid'  => $request->get('departmentid'),
                        'constant'      => 0,
                        'deleted'       => 0,
                        'created_by'    => auth()->user()->id,
                        'created_on'    => date('Y-m-d H:i:s')
                    ]);
                
                // DB::table('usertype')
                //     ->where('id', $refid)
                //     ->update([
                //         'refid'     => $refid
                //     ]);

                return redirect()->back()->with("messageAdded", $request->get('designation').' designation added successfully!');

            }
            else{

                return redirect()->back()->with("messageExists", $request->get('designation').' already exists!');

            }

        }
        elseif($action == 'editdesignation'){
            
            DB::table('usertype')
                ->where('id',$request->get('designationid'))
                ->update([
                    'utype'             => $request->get('designation'),
                    'updated_by'        => $my_id->id,
                    'updated_on'        => date('Y-m-d H:i:s'),
                ]);
            // Db::update('update hr_designation set designation = ?, updated_by = ?, updated_on = ? where id = ?',[$request->get('designation'),$my_id->id,date('Y-m-d H:i:s'),$request->get('designationid')]);

            return redirect()->back()->with("messageEdited", $request->get('designation').' designation updated successfully!');

        }
        elseif($action == 'deletedesignation'){

            DB::table('usertype')
                ->where('id',$request->get('designationid'))
                ->update([
                    'deleted'           => '1',
                    'updated_by'        => $my_id->id,
                    'updated_on'        => date('Y-m-d H:i:s'),
                ]);
            
            // Db::update('update hr_designation set deleted = ?, updated_by = ?, updated_on = ? where id = ?',['1',$my_id->id,date('Y-m-d H:i:s'),$request->get('designationid')]);

            return redirect()->back()->with("messageDeleted", $request->get('department').' department deleted successfully!');

        }
        elseif($action == 'editdepartment'){
            // return $request->all();
            DB::table('usertype')
                ->where('id',$request->get('designationid'))
                ->update([
                    'departmentid'      => $request->get('departmentid'),
                    'updated_by'        => $my_id->id,
                    'updated_on'        => date('Y-m-d H:i:s'),
                ]);
            // Db::update('update hr_designation set departmentid = ?, updated_by = ?, updated_on = ? where id = ?',[$request->get('departmentid'),$my_id->id,date('Y-m-d H:i:s'),$request->get('designationid')]);

            return redirect()->back()->with("messageEdited", $request->get('designation')."'s department updated successfully!");

        }

    }
    public function standarddeductions($id,Request $request)
    {
        
        $id = Crypt::decrypt($id);

        if($id == 'dashboard'){
            $departments = Db::table('hr_school_department')
            ->where('deleted',0)
            ->get();

            $tardinesstype = Db::table('deduction_tardinesssetup')
                ->where('deleted','0')
                ->get();

            $tardinessdetails = Db::table('deduction_tardinessdetail')
                ->where('deduction_tardinessdetail.deleted','0')
                ->get();

            $tardinesscomputations = array();

            foreach($tardinessdetails as $tardinessdetail){
                
                $tardinessdetail->modifiedamount = number_format($tardinessdetail->amount,2,'.',',');

                $tardinessdetail->modifiedpercentage = $tardinessdetail->dailyratepercentage.' %';

                if($tardinessdetail->specific == '1'){

                    $getdepartments = Db::table('deduction_tardinessapplication')
                        ->join('hr_school_department','deduction_tardinessapplication.departmentid','=','hr_school_department.id')
                        ->where('deduction_tardinessapplication.tardinessdetailid', $tardinessdetail->id)
                        ->where('deduction_tardinessapplication.deleted', '0')
                        ->get();

                    array_push($tardinesscomputations,(object)array(
                        'computationinfo'   => $tardinessdetail,
                        'computationdepartments'   => $getdepartments
                    ));

                }else{

                    array_push($tardinesscomputations,(object)array(
                        'computationinfo'   => $tardinessdetail,
                        'computationdepartments'   => 'All'
                    ));

                }

            }

            $deductiontypes = Db::table('deduction_standard')
                ->where('deleted','0')
                ->get();
            
            return view('hr.deductiontypes')
                ->with('deductiontypes',$deductiontypes)
                ->with('departments',$departments)
                ->with('tardinesstype',$tardinesstype)
                ->with('tardinesscomputations',$tardinesscomputations);

        }

    }
    public function bracketing(Request $request)
    {
        // return $request->all();
        if(strtolower($request->get('type')) == 'pag-ibig'):

            $brackets = Db::table('hr_bracketpi')
                        ->get();

            return view('hr.brackets.bracketpagibig')
                        ->with('type', $request->get('type'))
                        ->with('brackets',$brackets);

        elseif(strtolower($request->get('type')) == 'philhealth'):
            
            $brackets = Db::table('hr_bracketph')
                        ->select(
                            'hr_bracketphdetail.id',
                            'hr_bracketphdetail.rangefrom',
                            'hr_bracketphdetail.rangeto',
                            'hr_bracketphdetail.premiumrate'
                        )
                        ->join('hr_bracketphdetail', 'hr_bracketph.id','=','hr_bracketphdetail.bracketphid')
                        ->where('hr_bracketph.year', date('Y'))
                        ->get();
            return view('hr.brackets.bracketphilhealth')
                        ->with('type', $request->get('type'))
                        ->with('brackets',$brackets);

        elseif(strtolower($request->get('type')) == 'sss'):
            
            $brackets = Db::table('hr_bracketss')
                        ->get();

            return view('hr.brackets.bracketsss')
                        ->with('type', $request->get('type'))
                        ->with('brackets',$brackets);

        elseif(strtolower($request->get('type')) == 'withholding tax'):
            
            $brackets = Db::table('hr_bracketwt')
                        ->get();

            return view('hr.brackets.bracketwithholdingtax')
                        ->with('type', $request->get('type'))
                        ->with('brackets',$brackets);

        endif;
    }
    public function bracketedit(Request $request)
    {
        // return $request->all();
        if(strtolower($request->get('type')) == 'pag-ibig'):
            
            DB::table('hr_bracketpi')
                ->where('id', $request->get('id'))
                ->update([
                    'rangefrom' => $request->get('rangefrom'),
                    'rangeto'   => $request->get('rangeto'),
                    'eescrate'  => $request->get('eescrate'),
                    'erscrate'  => $request->get('erscrate')
                ]);

        elseif(strtolower($request->get('type')) == 'philhealth'):

            DB::table('hr_bracketphdetail')
                ->where('id', $request->get('id'))
                ->update([
                    'rangefrom'     => $request->get('rangefrom'),
                    'rangeto'       => $request->get('rangeto'),
                    'premiumrate'   => $request->get('premiumrate')
                ]);

        elseif(strtolower($request->get('type')) == 'sss'):
            DB::table('hr_bracketss')
                ->where('id', $request->get('id'))
                ->update([
                    'rangefrom'             => $request->get('rangefrom'),
                    'rangeto'               => $request->get('rangeto'),
                    'monthlysalarycredit'   => $request->get('monthlysalarycredit'),
                    'ersamount'             => $request->get('ersamount'),
                    'eesamount'             => $request->get('eesamount')
                ]);
        endif;

        return back();
    }
    public function updatedeductions($id,Request $request){

        $id = Crypt::decrypt($id);
        
        if($id == 'adddeduction'){
            // return $request->all();

            $checkifExists = Db::table('deduction_standard')
                ->where('description','like','%'.$request->get('deductiontype'))
                ->where('deleted','0')
                ->get();

            if($request->get('brackettype') == null){

                $withbracket    = 0;

                $brackettype    = "";

            }else{

                $withbracket    = 1;

                $brackettype    = $request->get('brackettype');

            }
            if(count($checkifExists) == 0){

                Db::table('deduction_standard')
                    ->insert([
                        'description' => $request->get('deductiontype'),
                        'withbracket' => $withbracket,
                        'brackettype' => $brackettype
                    ]);

            }

            return back();

        }
        if($id == 'editdeduction'){
            
            Db::table('deduction_standard')
                ->where('id', $request->get('deductiontype'))
                ->update([
                    'description' => $request->get('editeddeductiontype')
                ]);

            return back();

        }
        if($id == 'deletedeductiontype'){
            
            Db::table('deduction_standard')
                ->where('id', $request->get('deductiontypeid'))
                ->update([
                    'deleted' => '1'
                ]);

            return 'success';
        }

    }
    public function tardinessdeduction($id,Request $request){

        if($id == 'dashboard'){

            $departments = Db::table('hr_school_department')
                ->where('deleted',0)
                ->get();
    
            $tardinesstype = Db::table('deduction_tardinesssetup')
                ->where('deleted','0')
                ->get();

            $tardinessdetails = Db::table('deduction_tardinessdetail')
                ->where('deduction_tardinessdetail.deleted','0')
                ->get();

            $tardinesscomputations = array();

            foreach($tardinessdetails as $tardinessdetail){
                
                $tardinessdetail->modifiedamount = number_format($tardinessdetail->amount,2,'.',',');

                $tardinessdetail->modifiedpercentage = $tardinessdetail->dailyratepercentage.' %';

                if($tardinessdetail->specific == '1'){

                    $getdepartments = Db::table('deduction_tardinessapplication')
                        ->join('hr_school_department','deduction_tardinessapplication.departmentid','=','hr_school_department.id')
                        ->where('deduction_tardinessapplication.tardinessdetailid', $tardinessdetail->id)
                        ->where('deduction_tardinessapplication.deleted', '0')
                        ->get();

                    array_push($tardinesscomputations,(object)array(
                        'computationinfo'   => $tardinessdetail,
                        'computationdepartments'   => $getdepartments
                    ));

                }else{

                    array_push($tardinesscomputations,(object)array(
                        'computationinfo'   => $tardinessdetail,
                        'computationdepartments'   => 'All'
                    ));

                }

            }
            // return $tardinesscomputations;
            return view('hr.tardiness')
                ->with('departments',$departments)
                ->with('tardinesstype',$tardinesstype)
                ->with('tardinesscomputations',$tardinesscomputations);
        }
        elseif($id == 'changecomputationtype'){
            $computationtypes = Db::table('deduction_tardinesssetup')
                ->get();
            foreach($computationtypes as $computationtype){
                if($computationtype->id == $request->get('computationtypeid')){
                    Db::table('deduction_tardinesssetup')
                        ->where('id',$request->get('computationtypeid'))
                        ->update([
                            'status'    => 1
                        ]);
                }else{
                    Db::table('deduction_tardinesssetup')
                        ->where('id','!=',$request->get('computationtypeid'))
                        ->update([
                            'status'    => 0
                        ]);
                }
            }
            return back();
        }
    } 
    public function addtardinesscomputation(Request $request)
    {
        // return $request->all();
        if($request->get('durationtype') == 'minutes'){
            $minutesbasis = 1;
            $hoursbasis = 0;
        }
        elseif($request->get('durationtype') == 'hours'){
            $minutesbasis = 0;
            $hoursbasis = 1;
        }

        if($request->get('deductionbasis') == 'fixedamount'){
            $amount = $request->get('amountdeducted');
            $percentage = 0;
            $basisfixedamount = 1;
            $basispercentage = 0;
        }
        elseif($request->get('deductionbasis') == 'dailyratepercentage'){
            $amount = 0;
            $percentage = $request->get('percentage');
            $basisfixedamount = 0;
            $basispercentage = 1;
        }

        if($request->get('applicationtype') == 'specific'){
            $specific = 1;
            $all = 0;
        }
        elseif($request->get('applicationtype') == 'all'){
            $specific = 0;
            $all = 1;
        }

        if($request->get('allowanceduration') != null || $request->get('allowanceduration') != 0){
            $allowanceduration = $request->get('allowanceduration');
            if($request->get('allowancedurationtype') == 'minutes'){
                $allowancedurationtype = 1;
            }
            elseif($request->get('allowancedurationtype') == 'hours'){
                $allowancedurationtype = 2;
            }
    
        }else{
            $allowanceduration = 0;
            $allowancedurationtype = 1;
        }
        // return $amount;
        $tardinesscomputationid = DB::table('deduction_tardinessdetail')
                ->insertGetId([
                    'lateduration'          =>     $request->get('timeduration'),
                    'minutes'               =>     $minutesbasis,
                    'hours'                 =>     $hoursbasis,
                    'amount'                =>     $amount,
                    'dailyratepercentage'   =>     $percentage,
                    'basisfixedamount'      =>     $basisfixedamount,
                    'basispercentage'       =>     $basispercentage,
                    'timeallowance'         =>     $allowanceduration,
                    'timeallowancetype'     =>     $allowancedurationtype,
                    'specific'              =>     $specific,
                    'all'                   =>     $all
                ]);

        if($all == 1){

            $departments = Db::table('hr_school_department')
                ->where('deleted',0)
                ->get();

            foreach($departments as $department){

                DB::table('deduction_tardinessapplication')
                    ->insert([
                        'tardinessdetailid'          =>     $tardinesscomputationid,
                        'departmentid'               =>     $department->id
                    ]);

            }

        }

        if($specific == 1){

            foreach($request->get('departments') as $selecteddepartment){

                DB::table('deduction_tardinessapplication')
                    ->insert([
                        'tardinessdetailid'          =>     $tardinesscomputationid,
                        'departmentid'               =>     $selecteddepartment
                    ]);

            }

        }
        
        return back();
    }
    public function edittardinesscomputation(Request $request)
    {
        
        if($request->get('durationtype') == 'hours'){
            $hours = 1;
            $minutes = 0;
        }else{
            $hours = 0;
            $minutes = 1;
        }

        if($request->get('deductionbasis') == 'dailyratepercentage'){
            $dailyratepercentage = 1;
            $basisfixedamount = 0;
            $amount = 0;
            $percentage = $request->get('percentage');
        }else{
            $dailyratepercentage = 0;
            $basisfixedamount = 1;
            $amount = $request->get('amountdeducted');
            $percentage = 0;
        }

        if($request->get('editapplicationtype') == 'all'){
            $all = 1;
            $specific = 0;
        }else{
            $all = 0;
            $specific = 1;
        }

        DB::table('deduction_tardinessdetail')
            ->where('id',$request->get('computationid'))
            ->where('deleted','0')
            ->update([
                'lateduration'          =>  $request->get('timeduration'),
                'minutes'               =>  $minutes,
                'hours'                 =>  $hours,
                'amount'                =>  $amount,
                'dailyratepercentage'   =>  $percentage,
                'basisfixedamount'      =>  $basisfixedamount,
                'basispercentage'       =>  $dailyratepercentage,
                'specific'              =>  $specific,
                'all'                   =>  $all,
                'deductfromrate'        =>  $request->get('deductfromrate')
            ]);
        if($request->get('editapplicationtype') == 'all'){
            // DB::table('deduction_tardinessapplication')
            //     ->where('tardinessdetailid', $request->get('computationid'))
            //     ->update([
            //         'deleted'   => 1
            //     ]);
        }
        elseif($request->get('editapplicationtype') == 'specific'){
            $checkifExists = Db::table('deduction_tardinessapplication')
                ->where('tardinessdetailid', $request->get('computationid'))
                ->where('deleted', 0)
                ->get();
            // return $checkifExists;
            if(count($checkifExists) == 0){
                foreach($request->get('departments') as $department){

                    DB::table('deduction_tardinessapplication')
                        ->insert([
                            'tardinessdetailid'     => $request->get('computationid'),
                            'departmentid'          => $department
                        ]);
                }
            }else{
                foreach($checkifExists as $department){
                    
                    if(in_array($department->departmentid,$request->get('departments'))){
                        $checkifExistsinapplication = Db::table('deduction_tardinessapplication')
                            ->where('tardinessdetailid', $request->get('computationid'))
                            ->where('departmentid', $department->departmentid)
                            ->where('deleted', '0')
                            ->get();
                        if(count($checkifExistsinapplication) == 0){
                            DB::table('deduction_tardinessapplication')
                                ->insert([
                                    'tardinessdetailid'     => $request->get('computationid'),
                                    'departmentid'          => $department->departmentid
                                ]);
                        }
                    }else{
                        // array_push()
                            DB::table('deduction_tardinessapplication')
                                ->where('tardinessdetailid', $request->get('computationid'))
                                ->where('departmentid', $department->departmentid)
                                ->where('deleted', '0')
                                ->update([
                                    'deleted'   => '1'
                                ]);
                    }
                }
                $checkifExistsarray = array();
                
                foreach($checkifExists as $olddepartment){
                    array_push($checkifExistsarray, $olddepartment->departmentid);
                }
                foreach($request->get('departments') as $tobeinserteddepartment){
                    
                    if(in_array($tobeinserteddepartment,$checkifExistsarray)){
                    }else{
                        DB::table('deduction_tardinessapplication')
                            ->insert([
                                'tardinessdetailid'     => $request->get('computationid'),
                                'departmentid'          => $tobeinserteddepartment
                            ]);
                    }
                }
                
            }
        }
        return back();
    }
    public function deletetardinesscomputation(Request $request){
        // return $request->all();
        DB::table('deduction_tardinessdetail')
            ->where('id', $request->get('tardinesscomputationid'))
            ->update([
                'deleted'   => 1
            ]);
        Db::table('deduction_tardinessapplication')
            ->where('tardinessdetailid', $request->get('tardinesscomputationid'))
            ->update([
                'deleted'   => 1
            ]);
        return back();
    }
    public function standardallowances($id,Request $request){
        
        $id = Crypt::decrypt($id);

        if($id == 'dashboard'){

            $standardallowances = Db::table('allowance_standard')
                ->where('deleted','0')
                ->get();

            return view('hr.standardallowances')
                ->with('standardallowances',$standardallowances);

        }

    }
    public function updateallowances($id,Request $request){

        $id = Crypt::decrypt($id);
        
        if($id == 'addallowance'){

            foreach($request->get('descriptions') as $description){

                $checkifExists = Db::table('allowance_standard')
                    ->where('description','like','%'.$description)
                    ->where('deleted','0')
                    ->get();

                if(count($checkifExists) == 0){

                    Db::table('allowance_standard')
                        ->insert([
                            'description' => $description
                        ]);

                }

            }

            return back();

        }

        if($id == 'editallowance'){
            
            Db::table('allowance_standard')
                ->where('id', $request->get('allowanceid'))
                ->update([
                    'description' => $request->get('editallowance')
                ]);

            return back();

        }

        if($id == 'deleteallowance'){
            
            Db::table('allowance_standard')
                ->where('id', $request->get('allowanceid'))
                ->update([
                    'deleted' => '1'
                ]);

            return 'success';

        }

    }
    public function holidays()
    {

        $syid = DB::table('sy')
            ->where('isactive','1')
            ->first()
            ->id;
            
        date_default_timezone_set('Asia/Manila');

        $holidays = Db::table('schoolcal')
            ->select(
                'schoolcal.description',
                'schoolcal.datefrom',
                'schoolcal.dateto',
                'schoolcaltype.typename',
                'schoolcal.noclass'
                )
            ->join('schoolcaltype','schoolcal.type','=','schoolcaltype.id')
            ->where('schoolcal.deleted', '0')
            ->where('schoolcal.syid', $syid)
            ->get();
            
        foreach($holidays as $holiday){

            foreach($holiday as $key => $value){

                if($key == 'datefrom'){

                    $holiday->datefrom = date('M d, Y', strtotime($value));

                }

                if($key == 'dateto'){

                    $holiday->dateto = date('M d, Y', strtotime($value));
                    
                }

            }

        }

        $holidaytypes = Db::table('schoolcaltype')
            ->where('type','1')
            ->where('typename','!=','OTHER HOLIDAY')
            ->where('deleted','0')
            ->get();

        // $holidayrates = Db::table('holidayrates')
        //     ->get();
            
        return view('hr.holidays')
            ->with('holidays',$holidays)
            ->with('holidaytypes',$holidaytypes);
            // ->with('holidayrates',$holidayrates);

    }
    public function addholidaytypes(Request $request)
    {
        
        $checkifExists = Db::table('schoolcaltype')
            ->where('typename','like','%'.$request->get('typename'))
            ->get();

        if(count($checkifExists) == 0){

            DB::table('schoolcaltype')
                ->insert([
                    'typename'                =>   strtoupper($request->get('typename')),
                    'ratepercentagenowork'    =>   $request->get('newnowork'),
                    'ratepercentageworkon'    =>   $request->get('newworkon'),
                    'type'                    =>    1
                ]);

        }

        return back();

    }
    public function updateholidayrates(Request $request)
    {
        
        date_default_timezone_set('Asia/Manila');

        $updatorid = Db::table('teacher')
            ->where('userid', auth()->user()->id)
            ->first();

        foreach($request->get('fixedholidayids') as $fixedholidayidkey => $fixedholidayidvalue){
        
            Db::table('schoolcaltype')
                ->where('id', $fixedholidayidvalue)
                ->update([
                    'typename'                =>   $request->get('fixedholidaydescription')[$fixedholidayidkey],
                    'ratepercentagenowork'    =>   $request->get('fixedratepercentagenowork')[$fixedholidayidkey],
                    'ratepercentageworkon'    =>   $request->get('fixedratepercentageworkon')[$fixedholidayidkey]
                ]);

        }

        return back();

    }
    public function deleteholidaytype(Request $request)
    {
        
        DB::table('schoolcaltype')
            ->where('id',$request->get('deletetypeid'))
            ->update([
                'deleted'                =>   1
            ]);

        return back()->with('messageDelete','Holiday Type: '.$request->get('deletetypename').' deleted successfully!');

    }

}
