<?php

namespace App\Http\Controllers\HRControllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use DB;
use Crypt;
use \Carbon\Carbon;
use \Carbon\CarbonPeriod;
use App\MoneyCurrency;
use PDF;
use TCPDF;
use FontLib\Font;
use DateTime;
use DateInterval;
use DatePeriod;
use Conversion;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Writer\Xls;
use App\Models\HR\HRAllowances;
use App\Models\HR\HRDeductions;
use App\Models\HR\HREmployeeAttendance;
use App\Models\HR\HRSalaryDetails;

class MYPDF extends TCPDF {

    //Page header
    public function Header() {
        $title = $this->writeHTMLCell(false, 50, 40, 20, 'PAYSLIP', false, false, false, $reseth=true, $align='L', $autopadding=true);
        // Ln();
    }

    // Page footer
    public function Footer() {
        // Position at 15 mm from bottom
        $this->SetY(-15);
        // Set font
        $this->SetFont('helvetica', 'I', 8);
        // Page number
        $this->Cell(0, 10, 'Page '.$this->getAliasNumPage().' of '.$this->getAliasNbPages(), 0, false, 'C', 0, '', 0, false, 'T', 'M');
        $this->Cell(0, 10, date('m/d/Y'), 0, false, 'C', 0, '', 0, false, 'T', 'M');
    }
}
class PayrollSummary extends TCPDF {

    //Page header
    public function Header() {
        // Logo
        // $this->Image('@'.file_get_contents('/home/xxxxxx/public_html/xxxxxxxx/uploads/logo/logo.png'),10,6,0,13);
        $schoollogo = DB::table('schoolinfo')->first();
        $image_file = public_path().'/'.$schoollogo->picurl;
        $extension = explode('.', $schoollogo->picurl);
        $this->Image('@'.file_get_contents($image_file),15,9,17,17);
        
        $schoolname = $this->writeHTMLCell(false, 50, 40, 10, '<span style="font-weight: bold">'.$schoollogo->schoolname.'</span>', false, false, false, $reseth=true, $align='L', $autopadding=true);
        $schooladdress = $this->writeHTMLCell(false, 50, 40, 15, '<span style="font-weight: bold; font-size: 10px;">'.$schoollogo->address.'</span>', false, false, false, $reseth=true, $align='L', $autopadding=true);
        $title = $this->writeHTMLCell(false, 50, 40, 20, 'PAYROLL', false, false, false, $reseth=true, $align='L', $autopadding=true);
        // Ln();
    }

    // Page footer
    public function Footer() {
        // Position at 15 mm from bottom
        $this->SetY(-15);
        // Set font
        $this->SetFont('helvetica', 'I', 8);
        // Page number
        $this->Cell(0, 10, 'Page '.$this->getAliasNumPage().' of '.$this->getAliasNbPages(), 0, false, 'C', 0, '', 0, false, 'T', 'M');
        $this->Cell(-10, 10, date('m/d/Y'), 0, false, 'R', 0, '', 0, false, 'T', 'M');
    }
}
class HRPayrollController extends Controller
{
   public function index(Request $request)
   {
        $employees = Db::table('teacher')
            ->select(
                'teacher.id as employeeid',
                'teacher.lastname',
                'teacher.firstname',
                'teacher.middlename',
                'teacher.suffix',
                'usertype.utype',
                // 'teacher.gender',
                'teacher.picurl'
                )
            ->join('usertype','teacher.usertypeid','=','usertype.id')
            ->where('teacher.deleted','0')
            ->where('teacher.usertypeid','!=','7')
            ->where('teacher.usertypeid','!=','9')
            ->orderBy('lastname','asc')
            ->get();

            $payrolldates = DB::table('payroll')
                    ->where('status','1')
                    ->first();

            $newpayroll = 0;
            if(count(collect($payrolldates))>0)
            {
                $payrolldates->datefrom  = date_format(date_create($payrolldates->datefrom),"m/d/Y");
                $payrolldates->dateto    = date_format(date_create($payrolldates->dateto),"m/d/Y");

                $checkifexists = DB::table('payroll_history')
                    ->where('payrollid', $payrolldates->id)
                    ->where('deleted','0')
                    ->count();

                if($checkifexists>0)
                {
                    $newpayroll = 1;
                }
            }
            // return  (int)count(collect($payrolldates));
            // return collect($payrolldates)->datefrom;
            // return gettype(0);
            // return $payrolldates->datefrom;
            return view('hr.payroll.index')
                    ->with('employees', $employees)
                    ->with('payrolldates', $payrolldates)
                    ->with('newpayroll', $newpayroll);
   }
   public function setpayrolldate(Request $request)
   {
        date_default_timezone_set('Asia/Manila');
    //    return $request->all();
       $dateexplode = explode(' - ', $request->get('payrolldates'));
       $datefrom    = date_format(date_create($dateexplode[0]),"Y-m-d");
       $dateto      = date_format(date_create($dateexplode[1]),"Y-m-d");
       DB::table('payroll')
        ->insert([
            'datefrom'      => $datefrom,
            'dateto'        => $dateto,
            'createdby'     => auth()->user()->id,
            'createdon'     => date('Y-m-d H:i:s')
        ]);
   }
   public function newpayroll(Request $request)
   {
        date_default_timezone_set('Asia/Manila');
    //    return $request->all();
        DB::table('payroll')
            ->update([
                'status'    => 0,
                'updatedby' => auth()->user()->id,
                'updatedon' => date('Y-m-d H:i:s')
            ]);

        DB::table('payroll')
            ->insert([
                'datefrom'  => $request->get('datefrom'),
                'dateto'    => $request->get('dateto'),
                'createdby' => auth()->user()->id,
                'createdon' => date('Y-m-d H:i:s')
            ]);
        
   }
   public function changepayroll(Request $request)
   {
        date_default_timezone_set('Asia/Manila');
    //    return $request->all();
        DB::table('payroll')
            ->where('id', $request->get('payrollid'))
            ->update([
                'datefrom'  => $request->get('datefrom'),
                'dateto'    => $request->get('dateto'),
                'updatedby' => auth()->user()->id,
                'updatedon' => date('Y-m-d H:i:s')
            ]);
        
   }
   public function payrollleapyear(Request $request)
   {
       // return $request->all();
       DB::table('payroll')
           ->where('status','1')
           ->update([
               'leapyear'  => $request->get('leapyearactivation')
           ]);

       return back();
   }
   public function getsalarydetails(Request $request)
   {
       
        $payrolldates = Db::table('payroll')
        ->where('status','1')
        ->first();
        $salarydetails = HRSalaryDetails::salarydetails($request->get('employeeid'),$payrolldates);
        // return $salarydetails;
        // ====================================================================================================================== standard deductions

        $standarddeductionsmodel = HRDeductions::standarddeductions($salarydetails->payrollinfo->datefrom, $salarydetails->payrollinfo->id, $request->get('employeeid'));
        $standarddeductions = $standarddeductionsmodel;
        // return $standarddeductions;
        if(count($standarddeductionsmodel) == 0)
        {
            $standarddeductionsfullamount = 0.00;
        }else{
            $standarddeductionsfullamount = $standarddeductionsmodel[0]->fullamount;
        }
        // ====================================================================================================================== other deductions

        $otherdeductionsmodel = HRDeductions::otherdeductions($salarydetails->payrollinfo->datefrom, $salarydetails->payrollinfo->id, $request->get('employeeid'));
        $otherdeductions = $otherdeductionsmodel;
        // return $otherdeductions;
        if(count($otherdeductionsmodel) == 0)
        {
            $otherdeductionsfullamount = 0.00;
        }else{
            $otherdeductionsfullamount = $otherdeductionsmodel[0]->fullamount;
        }

        // ====================================================================================================================== standard allowance

        $standardallowancesmodel = HRAllowances::standardallowances($salarydetails->payrollinfo->datefrom, $salarydetails->payrollinfo->id, $request->get('employeeid'));
        $standardallowances = $standardallowancesmodel;
                // return $standardallowances;

        if(count($standardallowances) == 0)
        {
            $standardallowancesfullamount = 0.00;
        }else{
            $standardallowancesfullamount = $standardallowancesmodel[0]->fullamount;
        }
        
        // ====================================================================================================================== other allowance

        $otherallowancesmodel = HRAllowances::otherallowances($salarydetails->payrollinfo->datefrom, $salarydetails->payrollinfo->id, $request->get('employeeid'));
        $otherallowances = $otherallowancesmodel;
        // return $otherallowances;
        if(count($otherallowancesmodel) == 0)
        {
            $otherallowancesfullamount = 0.00;
        }else{
            $otherallowancesfullamount = $otherallowancesmodel[0]->fullamount;
        }

        $checkifreleased = Db::table('payroll_history')
            ->where('payrollid', $payrolldates->id)
            ->where('employeeid', $request->get('employeeid'))
            ->get();
            
        return view('hr.payroll.salarydetails')
            ->with('employeeid', $request->get('employeeid'))
            ->with('payrollinfo', $salarydetails->payrollinfo)
            ->with('picurl', $salarydetails->picurl)
            ->with('personalinfo', $salarydetails->personalinfo)
            ->with('basicsalaryinfo', $salarydetails->basicsalaryinfo)
            ->with('attendancedetails', $salarydetails->attendancedetails)
            ->with('payrollworkingdays', $salarydetails->payrollworkingdays)
            ->with('perdaysalary', $salarydetails->perdaysalary)
            ->with('leavedetails', $salarydetails->leavedetails)
            ->with('overtimedetails', $salarydetails->overtimedetails)
            ->with('permonthhalfsalary', $salarydetails->permonthhalfsalary)
            ->with('standarddeductions',$standarddeductions)
            ->with('otherdeductions',$otherdeductions)
            ->with('standardallowances',$standardallowances)
            ->with('otherallowances',$otherallowances)
            ->with('checkifreleased',count($checkifreleased));
   }
   public function saveconfiguration(Request $request)
   {
        date_default_timezone_set('Asia/Manila');
        $payrolldates = Db::table('payroll')
            ->where('status','1')
            ->first();
            
       if($request->has('standarddeductionids'))
       {
        if(count($request->get('standarddeductionids')) > 0)
        {
            foreach($request->get('standarddeductionids') as $standarddeductionkey => $standarddeductionvalue)
            {
                $checkifexists = DB::table('payroll_historydetail')
                 ->where('employeeid',$request->get('employeeid'))
                 ->where('payrollid',$payrolldates->id)
                 ->where('deductionid',$standarddeductionvalue)
                 ->where('type','standard')
                 ->where('deleted','0')
                 ->count();
 
                 if($checkifexists == 0)
                 {
                     DB::table('payroll_historydetail')
                      ->insert([
                          'employeeid'        => $request->get('employeeid'),
                          'payrollid'         => $payrolldates->id,
                          'deductionid'       => $standarddeductionvalue,
                          'deductiondesc'     => $request->get('standarddeductiondescs')[$standarddeductionkey],
                          'type'              => 'standard',
                          'paymentoption'     => $request->get('standarddeductionpaymentoptions')[$standarddeductionkey],
                          'amount'            => $request->get('standarddeductionamounts')[$standarddeductionkey],
                          'createdby'         => auth()->user()->id,
                          'createddatetime'   => date('Y-m-d H:i:s')
                      ]);
                 }else{
                     DB::table('payroll_historydetail')
                         ->where('employeeid',$request->get('employeeid'))
                         ->where('payrollid',$payrolldates->id)
                         ->where('deductionid',$standarddeductionvalue)
                         ->where('type','standard')
                         ->update([
                             'deductiondesc'     => $request->get('standarddeductiondescs')[$standarddeductionkey],
                             'type'              => 'standard',
                             'paymentoption'     => $request->get('standarddeductionpaymentoptions')[$standarddeductionkey],
                             'amount'            => $request->get('standarddeductionamounts')[$standarddeductionkey],
                             'updatedby'         => auth()->user()->id,
                             'updateddatetime'   => date('Y-m-d H:i:s')
                         ]);
                 }
            }
        }
       }
       if($request->has('otherdeductionids'))
       {
        if(count($request->get('otherdeductionids')) > 0)
        {
            foreach($request->get('otherdeductionids') as $otherdeductionkey => $otherdeductionvalue)
            {
                $checkifexists = DB::table('payroll_historydetail')
                 ->where('employeeid',$request->get('employeeid'))
                 ->where('payrollid',$payrolldates->id)
                 ->where('deductionid',$otherdeductionvalue)
                 ->where('type','other')
                 ->where('deleted','0')
                 ->count();
 
                 if($checkifexists == 0)
                 {
                     DB::table('payroll_historydetail')
                      ->insert([
                          'employeeid'        => $request->get('employeeid'),
                          'payrollid'         => $payrolldates->id,
                          'deductionid'       => $otherdeductionvalue,
                          'deductiondesc'     => $request->get('otherdeductiondescs')[$otherdeductionkey],
                          'type'              => 'other',
                          'paymentoption'     => $request->get('otherdeductionpaymentoptions')[$otherdeductionkey],
                          'amount'            => $request->get('otherdeductionamounts')[$otherdeductionkey],
                          'createdby'         => auth()->user()->id,
                          'createddatetime'   => date('Y-m-d H:i:s')
                      ]);
                 }else{
                     DB::table('payroll_historydetail')
                         ->where('employeeid',$request->get('employeeid'))
                         ->where('payrollid',$payrolldates->id)
                         ->where('deductionid',$otherdeductionvalue)
                         ->where('type','other')
                         ->update([
                             'deductiondesc'     => $request->get('otherdeductiondescs')[$otherdeductionkey],
                             'type'              => 'other',
                             'paymentoption'     => $request->get('otherdeductionpaymentoptions')[$otherdeductionkey],
                             'amount'            => $request->get('otherdeductionamounts')[$otherdeductionkey],
                             'updatedby'         => auth()->user()->id,
                             'updateddatetime'   => date('Y-m-d H:i:s')
                         ]);
                 }
            }
        }
       }
       if($request->has('standardallowanceids'))
       {
        if(count($request->get('standardallowanceids')) > 0)
        {
            foreach($request->get('standardallowanceids') as $standardallowancekey => $standardallowancevalue)
            {
                $checkifexists = DB::table('payroll_historydetail')
                 ->where('employeeid',$request->get('employeeid'))
                 ->where('payrollid',$payrolldates->id)
                 ->where('allowanceid',$standardallowancevalue)
                 ->where('type','standard')
                 ->where('deleted','0')
                 ->count();
 
                 if($checkifexists == 0)
                 {
                     DB::table('payroll_historydetail')
                      ->insert([
                          'employeeid'        => $request->get('employeeid'),
                          'payrollid'         => $payrolldates->id,
                          'allowanceid'       => $standardallowancevalue,
                          'allowancedesc'     => $request->get('standardallowancedescs')[$standardallowancekey],
                          'type'              => 'standard',
                          'paymentoption'     => $request->get('standardallowancepaymentoptions')[$standardallowancekey],
                          'amount'            => $request->get('standardallowanceamounts')[$standardallowancekey],
                          'createdby'         => auth()->user()->id,
                          'createddatetime'   => date('Y-m-d H:i:s')
                      ]);
                 }else{
                     DB::table('payroll_historydetail')
                         ->where('employeeid',$request->get('employeeid'))
                         ->where('payrollid',$payrolldates->id)
                         ->where('allowanceid',$standardallowancevalue)
                         ->where('type','standard')
                         ->update([
                             'allowancedesc'     => $request->get('standardallowancedescs')[$standardallowancekey],
                             'type'              => 'standard',
                             'paymentoption'     => $request->get('standardallowancepaymentoptions')[$standardallowancekey],
                             'amount'            => $request->get('standardallowanceamounts')[$standardallowancekey],
                             'updatedby'         => auth()->user()->id,
                             'updateddatetime'   => date('Y-m-d H:i:s')
                         ]);
                 }
            }
        }
       }
       if($request->has('otherallowanceids'))
       {
        if(count($request->get('otherallowanceids')) > 0)
        {
            foreach($request->get('otherallowanceids') as $otherallowancekey => $otherallowancevalue)
            {
                $checkifexists = DB::table('payroll_historydetail')
                 ->where('employeeid',$request->get('employeeid'))
                 ->where('payrollid',$payrolldates->id)
                 ->where('allowanceid',$otherallowancevalue)
                 ->where('type','other')
                 ->where('deleted','0')
                 ->count();
 
                 if($checkifexists == 0)
                 {
                     DB::table('payroll_historydetail')
                      ->insert([
                          'employeeid'        => $request->get('employeeid'),
                          'payrollid'         => $payrolldates->id,
                          'allowanceid'       => $otherallowancevalue,
                          'allowancedesc'     => $request->get('otherallowancedescs')[$otherallowancekey],
                          'type'              => 'other',
                          'paymentoption'     => $request->get('otherallowancepaymentoptions')[$otherallowancekey],
                          'amount'            => $request->get('otherallowanceamounts')[$otherallowancekey],
                          'createdby'         => auth()->user()->id,
                          'createddatetime'   => date('Y-m-d H:i:s')
                      ]);
                 }else{
                     DB::table('payroll_historydetail')
                         ->where('employeeid',$request->get('employeeid'))
                         ->where('payrollid',$payrolldates->id)
                         ->where('allowanceid',$otherallowancevalue)
                         ->where('type','other')
                         ->update([
                             'allowancedesc'     => $request->get('otherallowancedescs')[$otherallowancekey],
                             'type'              => 'other',
                             'paymentoption'     => $request->get('otherallowancepaymentoptions')[$otherallowancekey],
                             'amount'            => $request->get('otherallowanceamounts')[$otherallowancekey],
                             'updatedby'         => auth()->user()->id,
                             'updateddatetime'   => date('Y-m-d H:i:s')
                         ]);
                 }
            }
        }
       }
   }
   public function payrollsummary(Request $request)
   {
        $payrollactive = DB::table('payroll')
        ->where('status','1')
        ->first();

       $payrolldates = DB::table('payroll')
        ->orderBy('dateto','asc')
        ->get();

        $basistypes = DB::table('employee_basistype')
            ->where('deleted','0')
            ->get();

        $departments = DB::table('hr_school_department')
            ->where('deleted','0')
            ->get();
            
       $employees = Db::table('teacher')
       ->select(
           'teacher.id as employeeid',
           'employee_basicsalaryinfo.salarybasistype as salarytypeid'
           )
       ->join('usertype','teacher.usertypeid','=','usertype.id')
       ->leftJoin('hr_school_department','usertype.departmentid','=','hr_school_department.id')
       ->leftJoin('employee_basicsalaryinfo','teacher.id','=','employee_basicsalaryinfo.employeeid')
    //    ->leftJoin('employee_basistype','teacher.id','=','employee_basicsalaryinfo.employeeid')
       ->where('teacher.deleted','0')
       ->where('teacher.usertypeid','!=','7')
       ->where('teacher.usertypeid','!=','9')
       ->orderBy('lastname','asc')
       ->get();

        if(count($employees)>0)
        {
            foreach($employees as $employee)
            {
                $checkifreleased = Db::table('payroll_history')
                    ->where('employeeid', $employee->employeeid)
                    ->where('payrollid', $payrollactive->id)
                    ->where('deleted','0')
                    ->get();
                    
                if(count($checkifreleased) > 0)
                {
                    $employee->released = 1;
                }else{
                    $employee->released = 0;
                }
                $checkifconfigured = Db::table('payroll_historydetail')
                    ->where('employeeid', $employee->employeeid)
                    ->where('payrollid', $payrollactive->id)
                    ->where('deleted','0')
                    ->get();
                if(count($checkifconfigured) > 0)
                {
                    $employee->configured = 1;
                }else{
                    $employee->configured = 0;
                }
                if($employee->salarytypeid == null )
                {
                    $employee->salaryinfo = 1; //nosalaryinfo
                }else{
                    $employee->salaryinfo = 2;
                }
            }
        }

        // return $employees;
        
       return view('hr.payroll.payrollsummary')
        ->with('payrolldates', $payrolldates)
        ->with('employees', $employees)
        ->with('departments', $departments)
        ->with('basistypes', $basistypes);
   }
   public function filterpayrollsummary(Request $request)
   {
        $payrolldates = Db::table('payroll')
            ->where('id',$request->get('selectedpayrollid'))
            ->first();
            
        $salarytype = null;
       $employees = Db::table('teacher')
           ->select(
               'teacher.id as employeeid',
               'teacher.lastname',
               'teacher.firstname',
               'teacher.middlename',
               'teacher.suffix',
               'usertype.utype',
            //    'teacher.gender',
               'teacher.employmentstatus',
               'teacher.picurl',
               'hr_school_department.id as departmentid',
               'employee_basicsalaryinfo.salarybasistype as salarytypeid'
               )
           ->join('usertype','teacher.usertypeid','=','usertype.id')
           ->leftJoin('hr_school_department','usertype.departmentid','=','hr_school_department.id')
           ->leftJoin('employee_basicsalaryinfo','teacher.id','=','employee_basicsalaryinfo.employeeid')
        //    ->leftJoin('employee_basistype','teacher.id','=','employee_basicsalaryinfo.employeeid')
           ->where('teacher.deleted','0')
           ->where('teacher.usertypeid','!=','7')
           ->where('teacher.usertypeid','!=','9')
           ->orderBy('lastname','asc')
           ->get();

        if($request->get('selecteddepartmentid')!= null)
        {
            $employees = collect($employees->where('departmentid', $request->get('selecteddepartmentid')))->values()->all();
        }
        if($request->get('selectedemploymentstatusid')!= null)
        {
            $employees = collect($employees->where('employmentstatus', $request->get('selectedemploymentstatusid')))->values()->all();
        }
        if($request->get('selectedsalarytypeid')!= null)
        {
            $employees = collect($employees->where('salarytypeid', $request->get('selectedsalarytypeid')))->values()->all();
            $salarytype = DB::table('employee_basistype')
                ->where('id', $request->get('selectedsalarytypeid'))
                ->first()->type;
        }
        
        if(count($employees)>0)
        {
            foreach($employees as $employee)
            {
                $checkifconfigured = DB::table('payroll_historydetail')
                    ->where('payrollid', $payrolldates->id)
                    ->where('employeeid', $employee->employeeid)
                    ->where('deleted','0')
                    ->get();

                if(count($checkifconfigured)>0)
                {
                    $employee->configured = 1;
                }else{
                    $employee->configured = 0;
                }

                $checkifreleased = DB::table('payroll_history')
                    ->where('payrollid', $payrolldates->id)
                    ->where('employeeid', $employee->employeeid)
                    ->where('deleted','0')
                    ->get();

                if(count($checkifreleased)>0)
                {
                    $employee->released = 1;
                }else{
                    $employee->released = 0;
                }
                
                $salarydetails = HRSalaryDetails::salarydetails($employee->employeeid,$payrolldates);
                // return $salarydetails;
                // ====================================================================================================================== standard deductions

                $standarddeductionsmodel = HRDeductions::standarddeductions($payrolldates->datefrom, $payrolldates->id,$employee->employeeid);
                $standarddeductions = $standarddeductionsmodel;
                if(count($standarddeductionsmodel) == 0)
                {
                    $standarddeductionsfullamount = 0.00;
                }else{
                    $standarddeductionsfullamount = $standarddeductionsmodel[0]->fullamount;
                }
                // return $standarddeductionsfullamount;
                // ====================================================================================================================== other deductions

                $otherdeductionsmodel = HRDeductions::otherdeductions($payrolldates->datefrom, $payrolldates->id, $employee->employeeid);
                $otherdeductions = $otherdeductionsmodel;
                if(count($otherdeductionsmodel) == 0)
                {
                    $otherdeductionsfullamount = 0.00;
                }else{
                    $otherdeductionsfullamount = $otherdeductionsmodel[0]->fullamount;
                }

                // ====================================================================================================================== standard allowance

                $standardallowancesmodel = HRAllowances::standardallowances($payrolldates->datefrom, $payrolldates->id, $employee->employeeid);
                $standardallowances = $standardallowancesmodel;
                // return $standardallowances;
                if(count($standardallowances) == 0)
                {
                    $standardallowancesfullamount = 0.00;
                }else{
                    $standardallowancesfullamount = $standardallowancesmodel[0]->fullamount;
                }
                
                // ====================================================================================================================== other allowance

                $otherallowancesmodel = HRAllowances::otherallowances($payrolldates->datefrom, $payrolldates->id, $employee->employeeid);
                $otherallowances = $otherallowancesmodel;
                if(count($otherallowancesmodel) == 0)
                {
                    $otherallowancesfullamount = 0.00;
                }else{
                    $otherallowancesfullamount = $otherallowancesmodel[0]->fullamount;
                }
                $salarydetails->standarddeductions  = $standarddeductions;
                $salarydetails->otherdeductions = $otherdeductions;
                $salarydetails->standardallowances  = $standardallowances;
                $salarydetails->otherallowances = $otherallowances;
                
                $basicsalaryinfo = DB::table('employee_basicsalaryinfo')
                    ->where('employeeid', $employee->employeeid)
                    ->first();
                $ratetype = DB::table('employee_basistype')
                    ->where('id', $basicsalaryinfo->salarybasistype)
                    ->first()->type;

                    $basicsalaryinfo->salarytype = $ratetype;

                $salarydetails->basicsalary   = self::getbasicsalary($payrolldates,$basicsalaryinfo);;

                // return $salarydetails->basicsalaryinfo;
                    
                // return collect($salarydetails)->forget(['payrollinfo','picurl','personalinfo'])->basicsalaryinfo;
                unset($salarydetails->payrollinfo);
                unset($salarydetails->picurl);
                unset($salarydetails->personalinfo);
                // unset($salarydetails["payrollinfo"]); 
                // return collect($salarydetails);
                $totalleavesearn = 0;
                if(count($salarydetails->leavedetails)>0)
                {
                    foreach($salarydetails->leavedetails as $leavedetail)
                    {
                        $totalleavesearn+=$leavedetail->amountearn;
                    }
                }
                // return ($salarydetails->attendancedetails->attendancedeductions)+($salarydetails->attendancedetails->latedeductionamount);
                // return collect($salarydetails->attendancedetails->attendancepresent);

                
                $employee->salarydetails = $salarydetails;
                $employee->absencesandtardiness = $salarydetails->attendancedetails->attendancedeductions + $salarydetails->attendancedetails->latedeductionamount;
                $employee->totaldeductions = $standarddeductionsfullamount+$otherdeductionsfullamount;
                $employee->totalallowances = $standardallowancesfullamount+$otherallowancesfullamount;
                $employee->grosssalarypay = $salarydetails->attendancedetails->attendanceearnings+$totalleavesearn;
                $employee->netpay = ($employee->totalallowances+$salarydetails->attendancedetails->attendanceearnings+$totalleavesearn)-($employee->totaldeductions+$salarydetails->attendancedetails->latedeductionamount);
            }
        }
        $standarddeductions = Db::table('deduction_standard')
            ->where('deleted','0')
            ->get();
        if(strtolower($salarytype) == 'hourly')
        {

        }else{
            // return $employees;
            $released = count(collect($employees)->where('released',1));
            if($released == count($employees))
            {
                $print = 1;
            }else{
                $print = 0;
            }
            return view('hr.payroll.filteredemployees.default')
            ->with('print', $print)
            ->with('employees', $employees)
            ->with('standarddeductions', $standarddeductions);
        }

   }
   public function releaseslipsingle(Request $request)
   {
        $exporttype          = $request->get('exporttype');
        $employeeid          = $request->get('employeeid');
        $payrollid           = $request->get('payrollid');

                                $payrolldates = DB::table('payroll')
                                    ->where('id', $payrollid)
                                    ->first();

        $payrolldatefrom     = $payrolldates->datefrom;
        $payrolldateto       = $payrolldates->dateto;

                                $basicsalaryinfo = DB::table('employee_basicsalaryinfo')
                                    ->select('employee_basicsalaryinfo.*','employee_basistype.type as ratetype')
                                    ->leftJoin('employee_basistype','employee_basicsalaryinfo.salarybasistype','=','employee_basistype.id')
                                    ->where('employee_basicsalaryinfo.employeeid', $employeeid)
                                    ->first();
        $basicpay            =  $basicsalaryinfo->amount;
        $ratetype            =  $basicsalaryinfo->ratetype;
        $projectbasedtype    =  $basicsalaryinfo->projectbasedtype;
        $dayspresent         =  $request->get('dayspresent');
        $dayspresentamount   =  $request->get('dayspresentamount');
        $daysabsent          =  $request->get('daysabsent');
        $daysabsentamount    =  $request->get('daysabsentamount');
        $lateminutes         =  $request->get('lateminutes');
        $lateamount          =  $request->get('lateamount');
        $undertimeminutes    =  $request->get('undertimeminutes');
        $undertimeamount     =  $request->get('undertimeamount');
        $holidaypay          =  $request->get('holidaypay');
        $overtimepay         =  $request->get('overtimepay');
        $holidayovertimepay =  $request->get('holidayovertimepay');

        $leaveid  =  $request->get('leaveids');
        $leavedays  =  $request->get('leavedays');
        $leaveamount  =  $request->get('leaveamount');
        if($request->has('leaveids'))
        {
            if($leaveid != null)
            {
                $checkifexists = DB::table('payroll_historydetail')
                    ->where('employeeid',$employeeid)
                    ->where('payrollid',$payrollid)
                    ->where('employeeleaveid',$leaveid)
                    ->where('deleted','0')
                    ->get();
                if(count($checkifexists)==0)
                {
                    DB::table('payroll_historydetail')
                        ->insert([
                            'employeeid'        => $employeeid,
                            'payrollid'         => $payrollid,
                            'employeeleaveid'   => $leaveid,
                            'days'              => $leavedays,
                            'amount'            => $leaveamount
                        ]);
                }
            }
        }

        $deductionsamount = 0;
        
        $deductions = DB::table('payroll_historydetail')
            ->where('payrollid', $payrollid)
            ->where('employeeid', $employeeid)
            ->where('deductionid','!=',0)
            ->where('deleted','0')
            ->get();
            
        if(count($deductions)>0)
        {
            foreach($deductions as $deduction)
            {
                $deductionsamount+=$deduction->amount;

                if($deduction->type == 'other')
                {
                    $originalamount = DB::table('employee_deductionother')
                        ->where('id', $deduction->deductionid)
                        ->first()
                        ->amount;


                    $totalpaid = DB::table('payroll_historydetail')
                        // ->where('payrollid', $payrollid)
                        ->where('employeeid', $employeeid)
                        ->where('type','other')
                        ->where('deductionid','>',0)
                        ->sum('amount');
                    // return $totalpaid;
                    if($totalpaid>=$originalamount)
                    {
                        DB::table('employee_deductionother')
                        ->where('id', $deduction->deductionid)
                        ->update([
                            'paid'  => 1
                        ]);
                    }
                }
                
            }
        }

        $allowancesamount = 0;

        $allowances = DB::table('payroll_historydetail')
            ->where('payrollid', $payrollid)
            ->where('employeeid', $employeeid)
            ->where('allowanceid','>',0)
            ->where('deleted','0')
            ->get();


        if(count($allowances)>0)
        {
            foreach($allowances as $allowance)
            {
                $allowancesamount+=$allowance->amount;
                if($allowance->type == 'other')
                {
                    $originalamount = DB::table('employee_allowanceother')
                        ->where('id', $allowance->allowanceid)
                        ->first()
                        ->amount;


                    $totalpaid = DB::table('payroll_historydetail')
                        // ->where('payrollid', $payrollid)
                        ->where('employeeid', $employeeid)
                        ->where('type','other')
                        ->where('allowanceid','>',0)
                        ->sum('amount');
                    // return $totalpaid;
                    if($totalpaid>=$originalamount)
                    {
                        DB::table('employee_allowanceother')
                        ->where('id', $allowance->allowanceid)
                        ->update([
                            'paid'  => 1
                        ]);
                    }
                }
            }
        }


        $totalearnings       =  $dayspresentamount+$holidaypay+$overtimepay+$holidayovertimepay+$leaveamount+$allowancesamount;
        // $totaldeductions     =  $lateamount+$deductionsamount;
        $totaldeductions     =  $deductionsamount;
        
        $netpay              =  $totalearnings-($totaldeductions+$lateamount);

        $checkifexists = DB::table('payroll_history')
            ->where('employeeid',$employeeid)
            ->where('payrollid',$payrollid)
            ->where('deleted','0')
            ->get();

        if(count($checkifexists) == 0)
        {
            DB::table('payroll_history')
                ->insert([
                    'employeeid'            =>$employeeid,
                    'payrollid'             =>$payrollid,
                    'payrolldatefrom'       =>$payrolldatefrom,
                    'payrolldateto'         =>$payrolldateto,
                    'basicpay'              =>$basicpay,
                    'ratetype'              =>$ratetype,
                    'projectbasedtype'      =>$projectbasedtype,
                    'dayspresent'           =>$dayspresent,
                    'dayspresentamount'     =>$dayspresentamount,
                    'daysabsent'            =>$daysabsent,
                    'daysabsentamount'      =>$daysabsentamount,
                    'lateminutes'           =>$lateminutes,
                    'lateamount'            =>$lateamount,
                    'undertimeminutes'      =>$undertimeminutes,
                    'undertimeamount'       =>$undertimeamount,
                    'holidaypay'            =>$holidaypay,
                    'overtimepay'           =>$overtimepay,
                    'holidayovertimepay'    =>$holidayovertimepay,
                    'totalearnings'         =>$totalearnings,
                    'totaldeductions'       =>$totaldeductions,
                    'netpay'                =>$netpay,
                    'createdby'             =>auth()->user()->id,
                    'createddatetime'       =>date('Y-m-d H:i:s')
                ]);
        }

        return  self::generateslip($employeeid,$payrollid,$exporttype,'single');

   }

   public static function generateslip($employeeid,$payrollid,$exporttype,$exportclass)
   {
        $schoolinfo = Db::table('schoolinfo')
            ->select(
                'schoolinfo.schoolid',
                'schoolinfo.schoolname',
                'schoolinfo.authorized',
                'refcitymun.citymunDesc as division',
                'schoolinfo.district',
                'schoolinfo.address',
                'schoolinfo.picurl',
                'refregion.regDesc as region'
            )
            ->leftJoin('refregion','schoolinfo.region','=','refregion.regCode')
            ->leftJoin('refcitymun','schoolinfo.division','=','refcitymun.citymunCode')
            ->first();
        $employeeinfo = Db::table('teacher')
            ->where('id', $employeeid)
            ->first();
       if($exportclass == 'single')
       {

            $payrolldetails = Db::table('payroll_history')
                ->where('payrollid', $payrollid)
                ->where('employeeid', $employeeid)
                ->where('deleted','0')
                ->first();

            $payrolldetails->otherdetails = Db::table('payroll_historydetail')
                ->where('payrollid', $payrollid)
                ->where('employeeid', $employeeid)
                ->where('deleted','0')
                ->get();

            if($exporttype == 'pdf')
            {
            
                $pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
                // set document information
                $pdf->SetCreator('CK');
                $pdf->SetAuthor('CK Children\'s Publishing');
                $pdf->SetTitle($schoolinfo->schoolname.' - PAYSLIP');
                $pdf->SetSubject('PAYSLIP');
                
                // set header and footer fonts
                // $pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
                // $pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
                
                $pdf->setPrintHeader(false);
                $pdf->setPrintFooter(false);
                
                // set default monospaced font
                $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
                
                // set margins
                // $pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
                $pdf->SetMargins(5, 0, 5, true);
                $pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
                $pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
                
                // $pdf->SetLineStyle(array('width' => 0.5, 'cap' => 'butt', 'join' => 'miter', 'dash' => 4, 'color' => array(255, 0, 0)));
                // set auto page breaks
                $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
                
                // set image scale factor
                $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
                
                // set some language-dependent strings (optional)
                if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
                    require_once(dirname(__FILE__).'/lang/eng.php');
                    $pdf->setLanguageArray($l);
                }
                
                // ---------------------------------------------------------
                
                // set font
                $pdf->SetFont('dejavusans', '', 10);
                
                
                // - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                // Print a table
                
                // add a page
                $pdf->AddPage();
                    
                $payrolldetails->payrolldatefrom    = date('M d, Y', strtotime($payrolldetails->payrolldatefrom));
                $payrolldetails->payrolldateto      = date('M d, Y', strtotime($payrolldetails->payrolldateto));
                set_time_limit(3000);
                $view = \View::make('hr/payroll/payslip/pdf_single',compact('payrolldetails','employeeinfo','schoolinfo'));
                $html = $view->render();
                $pdf->writeHTML($html, true, false, true, false, '');
                // $pdf->writeHTML(view('registrar/pdf/pdf_numberofenrollees')->compact('enrollees','schoolinfo','from','to')->render());
                
                // $pdf->lastPage();
                
                // ---------------------------------------------------------
                //Close and output PDF document
                $pdf->Output('Payslip.pdf', 'I');
            }
       }
   }
   public function viewslip(Request $request)
   {
    //    return $request->all();
        return  self::generateslip($request->get('employeeid'),$request->get('payrollid'),$request->get('exporttype'),$request->get('exportclass'));
   }
   public function exportsummary(Request $request)
   {
       
       $salarytype = DB::table('employee_basistype')
        ->where('id', $request->get('selectedsalarytypeid'))
        ->first()->type;
       
       $schoolinfo = Db::table('schoolinfo')
        ->select(
            'schoolinfo.schoolid',
            'schoolinfo.schoolname',
            'schoolinfo.authorized',
            'refcitymun.citymunDesc as division',
            'schoolinfo.district',
            'schoolinfo.address',
            'schoolinfo.picurl',
            'refregion.regDesc as region'
        )
        ->leftJoin('refregion','schoolinfo.region','=','refregion.regCode')
        ->leftJoin('refcitymun','schoolinfo.division','=','refcitymun.citymunCode')
        ->first();

        $payrolldates = DB::table('payroll')
            ->where('id',$request->get('selectedpayrollid'))
            ->first();

        $payroll_history = DB::table('payroll_history')
            ->where('payrollid', $request->get('selectedpayrollid'))
            ->where('deleted',0)
            ->get();


        if(count($payroll_history)>0)
        {
            foreach($payroll_history as $history)
            {
                $employeeinfo = DB::table('teacher')
                    ->select('firstname','lastname','middlename','suffix')
                    ->where('id', $history->employeeid)
                    ->first();

                $history->firstname  = $employeeinfo->firstname;
                $history->lastname  = $employeeinfo->lastname;
                $history->middlename  = $employeeinfo->middlename;
                $history->suffix  = $employeeinfo->suffix;

                $basicsalaryinfo = DB::table('employee_basicsalaryinfo')
                    ->where('employeeid', $history->employeeid)
                    ->first();

                $basicsalaryinfo->salarytype = $history->ratetype;
                    
                $history->basicsalary   = self::getbasicsalary($payrolldates,$basicsalaryinfo);;

                $historydetail = array();

                $history->historydetails = DB::table('payroll_historydetail')
                    ->where('payrollid', $request->get('selectedpayrollid'))
                    ->where('employeeid', $history->employeeid)
                    ->where('deleted',0)
                    ->get();
            }
        }

        // return $payroll_history;

        $standarddeductions = DB::table('deduction_standard')
            ->select('id', 'description')
            ->where('deleted','0')
            ->get();


        $payrolldates->datefrom    = date('M d, Y', strtotime($payrolldates->datefrom));
        $payrolldates->dateto      = date('M d, Y', strtotime($payrolldates->dateto));


       if(strtolower($salarytype) == 'hourly')
       {

       }else{



            if($request->get('exporttype') == 'pdf')
            {
                $pdf = new PayrollSummary(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
                // set document information
                $pdf->SetCreator('CK');
                $pdf->SetAuthor('CK Children\'s Publishing');
                $pdf->SetTitle($schoolinfo->schoolname.' - PAYROLL SUMMARY');
                $pdf->SetSubject('PAYSLIP');
                
                // set header and footer fonts
                $pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
                $pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
                
                // $pdf->setPrintHeader(false);
                // $pdf->setPrintFooter(false);
                
                // set default monospaced font
                $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
                
                // set margins
                $pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
                // $pdf->SetMargins(5, 0, 5, true);
                $pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
                $pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
                
                // $pdf->SetLineStyle(array('width' => 0.5, 'cap' => 'butt', 'join' => 'miter', 'dash' => 4, 'color' => array(255, 0, 0)));
                // set auto page breaks
                $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
                
                // set image scale factor
                $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
                
                // set some language-dependent strings (optional)
                if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
                    require_once(dirname(__FILE__).'/lang/eng.php');
                    $pdf->setLanguageArray($l);
                }
                
                // ---------------------------------------------------------
                
                // set font
                $pdf->SetFont('dejavusans', '', 10);
                
                
                // - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                // Print a table
                
                // add a page
                $pdf->AddPage('L',array(216,356));
                    
                set_time_limit(3000);

                $payrolldetails = collect($payroll_history)->sortBy('lastname');
                $view = \View::make('hr/payroll/payslip/pdf_summary_default',compact('payrolldetails','payrolldates','schoolinfo','standarddeductions'));
                $html = $view->render();
                $pdf->writeHTML($html, true, false, true, false, '');
                // $pdf->writeHTML(view('registrar/pdf/pdf_numberofenrollees')->compact('enrollees','schoolinfo','from','to')->render());
                
                // $pdf->lastPage();
                
                // ---------------------------------------------------------
                //Close and output PDF document
                $pdf->Output('Payslip.pdf', 'I');
            }

       }
   }

   
   public static function getbasicsalary($payrolldates,$basicsalaryinfo)
   {
       $employeeworkdaysinaweek = 0; 

        $payrollworkingdays = array();

        $begin = new DateTime($payrolldates->datefrom);

        $end = new DateTime($payrolldates->dateto);

        $end = $end->modify( '+1 day' ); 
        
        $intervalday = new DateInterval('P1D');

        $daterange = new DatePeriod($begin, $intervalday ,$end);

        foreach($daterange as $date){
            
            if(strtolower($date->format("D")) == 'mon' && $basicsalaryinfo->mondays == 1)
            {
                array_push($payrollworkingdays,$date->format("Y-m-d"));
                $employeeworkdaysinaweek+=1;
            }
            elseif(strtolower($date->format("D")) == 'tue' && $basicsalaryinfo->tuesdays == 1)
            {
                array_push($payrollworkingdays,$date->format("Y-m-d"));
                $employeeworkdaysinaweek+=1;
            }
            elseif(strtolower($date->format("D")) == 'wed' && $basicsalaryinfo->wednesdays == 1)
            {
                array_push($payrollworkingdays,$date->format("Y-m-d"));
                $employeeworkdaysinaweek+=1;
            }
            elseif(strtolower($date->format("D")) == 'thu' && $basicsalaryinfo->thursdays == 1)
            {
                array_push($payrollworkingdays,$date->format("Y-m-d"));
                $employeeworkdaysinaweek+=1;
            }
            elseif(strtolower($date->format("D")) == 'fri' && $basicsalaryinfo->fridays == 1)
            {
                array_push($payrollworkingdays,$date->format("Y-m-d"));
                $employeeworkdaysinaweek+=1;
            }
            elseif(strtolower($date->format("D")) == 'sat' && $basicsalaryinfo->saturdays == 1)
            {
                array_push($payrollworkingdays,$date->format("Y-m-d"));
                $employeeworkdaysinaweek+=1;
            }
            elseif(strtolower($date->format("D")) == 'sun' && $basicsalaryinfo->sundays == 1)
            {
                array_push($payrollworkingdays,$date->format("Y-m-d"));
                $employeeworkdaysinaweek+=1;
            }

        }
        
        
        $basicsalary    = 0;
        $permonthhalfsalary = 0;
        $perdaysalary       = 0;
        $hourlyrate         = 0;
        if(strtolower($basicsalaryinfo->salarytype) == 'monthly'){
            // return $workdays;
            if(count($payrollworkingdays) == 0){

                $dailyrate =  $basicsalaryinfo->amount / (int)(date('t') - date('01'));

            }else{
                // round($getrate[0]->amount / $monthdaycount, 2);
                // return $getrate[0]->amount / count($monthworkdays);
                // return $getrate[0]->amount;
                if($payrolldates->leapyear == 0){
                    
                    $dailyrate =  ($basicsalaryinfo->amount*12)/($employeeworkdaysinaweek*52);
                    
                }else{

                    $dailyrate =  ($basicsalaryinfo->amount*12)/(($employeeworkdaysinaweek*52)+1);

                }
                
                
                
            }
            // return $dailyrate;
            if($dailyrate == 0 || $basicsalaryinfo->hoursperday == 0){
                // return 'asdasd';
                $hourlyrate = 0;
            }else{
                
                $hourlyrate = ($dailyrate)/$basicsalaryinfo->hoursperday;
            }
            // return $payrollworkingdays;
            $permonthhalfsalary = $basicsalaryinfo->amount/2;
            if(count($payrollworkingdays) == 0)
            {
                $perdaysalary = $dailyrate;
            }else{
                $perdaysalary = $permonthhalfsalary/count($payrollworkingdays);
            }
            $basicsalary = $permonthhalfsalary;

        }
        elseif(strtolower($basicsalaryinfo->salarytype) == 'daily'){

            $dailyrate =  round($basicsalaryinfo->amount, 2);

            $hourlyrate = ($dailyrate)/$basicsalaryinfo->hoursperday;

            $perdaysalary = $dailyrate;
            $permonthhalfsalary = $perdaysalary*count($payrollworkingdays);
            $basicsalary = $permonthhalfsalary;

            // return $hourlyrate;

        }
        elseif(strtolower($basicsalaryinfo->salarytype) == 'hourly'){

            $hoursperday = 0;
            if($hoursperday == 0){
                if($basicsalaryinfo->mondayhours > 0){
                    $hoursperday = $basicsalaryinfo->mondayhours;
                }
                if($basicsalaryinfo->tuesdayhours > 0){
                    $hoursperday = $basicsalaryinfo->tuesdayhours;
                }
                if($basicsalaryinfo->wednesdayhours > 0){
                    $hoursperday = $basicsalaryinfo->wednesdayhours;
                }
                if($basicsalaryinfo->thursdayhours > 0){
                    $hoursperday = $basicsalaryinfo->thursdayhours;
                }
                if($basicsalaryinfo->fridayhours > 0){
                    $hoursperday = $basicsalaryinfo->fridayhours;
                }
                if($basicsalaryinfo->saturdayhours > 0){
                    $hoursperday = $basicsalaryinfo->saturdayhours;
                }
                if($basicsalaryinfo->sundayhours > 0){
                    $hoursperday = $basicsalaryinfo->sundayhours;
                }
            }
            
            $dailyrate = ($basicsalaryinfo->amount/$hoursperday);
            
            $hourlyrate = $basicsalaryinfo->amount;
            $perdaysalary = $dailyrate;
            $basicsalary = $perdaysalary*count($payrollworkingdays);


        }
        elseif(strtolower($basicsalaryinfo->salarytype) == 'project'){
            
            if($basicsalaryinfo->projectbasedtype == 'persalaryperiod'){
                
                $dailyrate =  $basicsalaryinfo->amount/count($workdays); 

                $hourlyrate =  ($basicsalaryinfo->amount/count($workdays))/$basicsalaryinfo->hoursperday; 

            }
            elseif($basicsalaryinfo->projectbasedtype == 'perday'){
                
                $dailyrate = $basicsalaryinfo->amount;

                $hourlyrate = $basicsalaryinfo->amount/$basicsalaryinfo->hoursperday;

            }
            elseif($basicsalaryinfo->projectbasedtype == 'permonth'){
                
                $payrollworkingdays = ($basicsalaryinfo->amount/count($monthworkdays))/$basicsalaryinfo->hoursperday;

                $dailyrate =  $basicsalaryinfo->amount/count($monthworkdays); 

                
                // return
                
            }
            $perdaysalary = $dailyrate;
            $basicsalary = $perdaysalary*count($payrollworkingdays);
            
        }

        return $basicsalary;
   }
}
