<?php

namespace App\Http\Controllers\HRControllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;
use PDF;
use TCPDF;
class HRSummaryController extends Controller
{
    public function summaryofattendance($id, Request $request)
    {

        date_default_timezone_set('Asia/Manila');

        if($id == 'dashboard')
        {

            $selecteddate = date('Y-m-d');

            $selectedstatus = 'all';

        }elseif($id == 'filter' || $id == 'print')
        {

            $selecteddate = $request->get('selecteddate');

            $selectedstatus = $request->get('selectedstatus');

        }
        
        $employees = DB::table('teacher')
            ->select(
                'teacher.id',
                'teacher.firstname',
                'teacher.middlename',
                'teacher.lastname',
                'teacher.suffix',
                'usertype.utype as designation'
            )
            ->join('usertype','teacher.usertypeid','=','usertype.id')
            ->where('isactive','1')
            ->orderby('lastname','asc')
            ->get();
            
        $present = array();
        $tardy = array();
        $absent = array();

        if($selectedstatus == 'all')
        {

            foreach($employees as $employee)
            {
    
                $employeeattendance = DB::table('teacherattendance')
                    ->where('teacher_id', $employee->id)
                    ->where('tdate', $selecteddate)
                    ->get();

                if(count($employeeattendance) == 0)
                {

                    array_push($absent, $employee);

                }else{
                    // return $employeeattendance[0]->out_am;
                    $attendanceinam         =   $employeeattendance[0]->in_am;
                    $attendanceoutam        =   $employeeattendance[0]->out_am;
                    $attendanceinpm         =   $employeeattendance[0]->in_pm;
                    $attendanceoutpm        =  $employeeattendance[0]->out_pm;

                    $checkcustomtimeschedstatus = DB::table('deduction_tardinesssetup')
                        ->where('status', '1')
                        ->first();

                    $tardyreport = 0;


                    if(strtolower($checkcustomtimeschedstatus->type) == 'custom')
                    {

                        $gettimesched = DB::table('employee_customtimesched')
                            ->where('employeeid', $employee->id)
                            ->where('deleted', '0')
                            ->get();
                            
                        if(count($gettimesched) == 0)
                        {


                            if($attendanceinam > date('H:i:s',strtotime('8:00:00 AM')) || $attendanceoutam < date('H:i:s',strtotime('12:00:00 PM')) || $attendanceinpm > date('H:i:s',strtotime('01:00:00 PM')) || $attendanceoutpm < date('H:i:s',strtotime('05:00:00 PM')))
                            {

                                $tardyreport+=1;

                            }
                            

                        }else{

                            // if($gettimesched[0]->amin < $employeeattendance[0]->in_am || $gettimesched[0]->amout > $employeeattendance[0]->out_am || $gettimesched[0]->pmin < $employeeattendance[0]->in_pm || $gettimesched[0]->pmout > $employeeattendance[0]->out_pm)
                            if($attendanceinam > date('H:i:s', strtotime($gettimesched[0]->amin.' AM')) || $attendanceoutam < date('H:i:s', strtotime($gettimesched[0]->amout.' PM')) || $attendanceinpm > date('H:i:s', strtotime($gettimesched[0]->pmin.' PM')) || $attendanceoutpm < date('H:i:s', strtotime($gettimesched[0]->pmout.' PM')))
                            {

                                $tardyreport+=1;

                            }

                        }

                        if($tardyreport == 0)
                        {

                            array_push($present, $employee);

                        }
                        elseif($tardyreport == 1)
                        {

                            array_push($tardy, $employee);

                        }

                    }else{

                        // if($employeeattendance[0]->in_am > date('H:i:s',strtotime('08:00:00 AM')) || $employeeattendance[0]->out_am < date('H:i:s',strtotime('12:00:00 PM')) || $employeeattendance[0]->in_pm > date('H:i:s',strtotime('01:00:00 PM')) || $employeeattendance[0]->out_pm < date('H:i:s',strtotime('05:00:00 PM')))
                        // return $attendanceoutam;
                        if($attendanceinam > date('H:i:s',strtotime('8:00:00 AM')) || $attendanceoutam < date('H:i:s',strtotime('12:00:00 PM')) || $attendanceinpm > date('H:i:s',strtotime('01:00:00 PM')) || $attendanceoutpm < date('H:i:s',strtotime('05:00:00 PM')))
                        {

                            $tardyreport+=1;

                        }

                        if($tardyreport == 0)
                        {

                            array_push($present, $employee);

                        }
                        elseif($tardyreport == 1)
                        {

                            array_push($tardy, $employee);

                        }

                    }

                }
    
            }

        }
        elseif($selectedstatus == 'present')
        {

            foreach($employees as $employee)
            {
    
                $employeeattendance = DB::table('teacherattendance')
                    ->where('teacher_id', $employee->id)
                    ->where('tdate', $selecteddate)
                    ->get();

                if(count($employeeattendance) > 0)
                {
                    $attendanceinam         =   $employeeattendance[0]->in_am;
                    $attendanceoutam        =   $employeeattendance[0]->out_am;
                    $attendanceinpm         =   $employeeattendance[0]->in_pm;
                    $attendanceoutpm        =  $employeeattendance[0]->out_pm;

                    $checkcustomtimeschedstatus = DB::table('deduction_tardinesssetup')
                        ->where('status', '1')
                        ->first();

                    $tardyreport = 0;

                    if(strtolower($checkcustomtimeschedstatus->type) == 'custom')
                    {


                        $gettimesched = DB::table('employee_customtimesched')
                            ->where('employeeid', $employee->id)
                            ->where('deleted', '0')
                            ->get();

                        if(count($gettimesched) == 0)
                        {

                            // if($employeeattendance[0]->in_am > '8:00:00' || $employeeattendance[0]->out_am < '12:00:00' || $employeeattendance[0]->in_pm > '01:00:00' || $employeeattendance[0]->out_pm < '05:00:00')
                            if($attendanceinam > date('H:i:s',strtotime('8:00:00 AM')) || $attendanceoutam < date('H:i:s',strtotime('12:00:00 PM')) || $attendanceinpm > date('H:i:s',strtotime('01:00:00 PM')) || $attendanceoutpm < date('H:i:s',strtotime('05:00:00 PM')))
                            {

                                $tardyreport+=1;

                            }
                            

                        }else{

                            // if($gettimesched[0]->amin < $employeeattendance[0]->in_am || $gettimesched[0]->amout < $employeeattendance[0]->out_am || $gettimesched[0]->pmin < $employeeattendance[0]->in_pm || $gettimesched[0]->pmout > $employeeattendance[0]->out_pm)
                            if($attendanceinam > date('H:i:s', strtotime($gettimesched[0]->amin.' AM')) || $attendanceoutam < date('H:i:s', strtotime($gettimesched[0]->amout.' PM')) || $attendanceinpm > date('H:i:s', strtotime($gettimesched[0]->pmin.' PM')) || $attendanceoutpm < date('H:i:s', strtotime($gettimesched[0]->pmout.' PM')))
                            {

                                $tardyreport+=1;

                            }

                        }

                        if($tardyreport == 0)
                        {

                            array_push($present, $employee);

                        }

                    }else{


                        // if($employeeattendance[0]->in_am > '8:00:00' || $employeeattendance[0]->out_am < '12:00:00' || $employeeattendance[0]->in_pm > '01:00:00' || $employeeattendance[0]->out_pm < '05:00:00')
                        if($attendanceinam > date('H:i:s',strtotime('8:00:00 AM')) || $attendanceoutam < date('H:i:s',strtotime('12:00:00 PM')) || $attendanceinpm > date('H:i:s',strtotime('01:00:00 PM')) || $attendanceoutpm < date('H:i:s',strtotime('05:00:00 PM')))
                        {

                            $tardyreport+=1;

                        }

                        if($tardyreport == 0)
                        {

                            array_push($present, $employee);

                        }

                    }

                }
    
            }

        }
        elseif($selectedstatus == 'tardy')
        {

            foreach($employees as $employee)
            {
    
                $employeeattendance = DB::table('teacherattendance')
                    ->where('teacher_id', $employee->id)
                    ->where('tdate', $selecteddate)
                    ->get();

                if(count($employeeattendance) > 0)
                {
                    $attendanceinam         =   $employeeattendance[0]->in_am;
                    $attendanceoutam        =   $employeeattendance[0]->out_am;
                    $attendanceinpm         =   $employeeattendance[0]->in_pm;
                    $attendanceoutpm        =  $employeeattendance[0]->out_pm;
                    
                    $checkcustomtimeschedstatus = DB::table('deduction_tardinesssetup')
                        ->where('status', '1')
                        ->first();

                    $tardyreport = 0;

                    if(strtolower($checkcustomtimeschedstatus->type) == 'custom')
                    {

                        $gettimesched = DB::table('employee_customtimesched')
                            ->where('employeeid', $employee->id)
                            ->where('deleted', '0')
                            ->get();

                        if(count($gettimesched) == 0)
                        {

                            // if($employeeattendance[0]->in_am > '8:00:00' || $employeeattendance[0]->out_am < '12:00:00' || $employeeattendance[0]->in_pm > '01:00:00' || $employeeattendance[0]->out_pm < '05:00:00')
                            if($attendanceinam > date('H:i:s',strtotime('8:00:00 AM')) || $attendanceoutam < date('H:i:s',strtotime('12:00:00 PM')) || $attendanceinpm > date('H:i:s',strtotime('01:00:00 PM')) || $attendanceoutpm < date('H:i:s',strtotime('05:00:00 PM')))
                            {

                                $tardyreport+=1;

                            }
                            

                        }else{

                            // if($gettimesched[0]->amin < $employeeattendance[0]->in_am || $gettimesched[0]->amout > $employeeattendance[0]->out_am || $gettimesched[0]->pmin < $employeeattendance[0]->in_pm || $gettimesched[0]->pmout > $employeeattendance[0]->out_pm)
                            if($attendanceinam > date('H:i:s', strtotime($gettimesched[0]->amin.' AM')) || $attendanceoutam < date('H:i:s', strtotime($gettimesched[0]->amout.' PM')) || $attendanceinpm > date('H:i:s', strtotime($gettimesched[0]->pmin.' PM')) || $attendanceoutpm < date('H:i:s', strtotime($gettimesched[0]->pmout.' PM')))
                            {

                                $tardyreport+=1;

                            }

                        }

                        if($tardyreport == 1)
                        {

                            array_push($tardy, $employee);

                        }

                    }else{



                        // if($employeeattendance[0]->in_am > '07:00:00' || $employeeattendance[0]->out_am < '12:00:00' || $employeeattendance[0]->in_pm > '01:00:00' || $employeeattendance[0]->out_pm < '05:00:00')
                        if($attendanceinam > date('H:i:s',strtotime('8:00:00 AM')) || $attendanceoutam < date('H:i:s',strtotime('12:00:00 PM')) || $attendanceinpm > date('H:i:s',strtotime('01:00:00 PM')) || $attendanceoutpm < date('H:i:s',strtotime('05:00:00 PM')))
                        {

                            $tardyreport+=1;

                        }

                        if($tardyreport == 1)
                        {

                            array_push($tardy, $employee);

                        }

                    }

                }
    
            }

        }
        elseif($selectedstatus == 'absent')
        {

            foreach($employees as $employee)
            {
    
                $employeeattendance = DB::table('teacherattendance')
                    ->where('teacher_id', $employee->id)
                    ->where('tdate', $selecteddate)
                    ->get();

                if(count($employeeattendance) == 0)
                {

                    array_push($absent, $employee);

                }
    
            }

        }
        
        if($id == 'print'){

            $schoolinfo = DB::table('schoolinfo')
                ->first();

            $selecteddate = date('F d, Y', strtotime($selecteddate));
                
            $preparedby = DB::table('teacher')
                ->where('userid', auth()->user()->id)
                ->first();

            $dateprepared =date('F d, Y h:i:s A');

            // $pdf = PDF::loadview('hr/pdf/summaryemployeeattendace',compact('present','tardy','absent','selectedstatus','selecteddate','schoolinfo','preparedby','dateprepared'))->setPaper('8.5x11');

            // return $pdf->stream('Payroll History.pdf'); 
            $pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
            // set document information
            $pdf->SetCreator('CK');
            $pdf->SetAuthor('CK Children\'s Publishing');
            $pdf->SetTitle($schoolinfo->schoolname.' - Attendance Report - Employees');
            $pdf->SetSubject('Attendance Report - Employees');
            
            // set header and footer fonts
            $pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
            $pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
            
            // set default monospaced font
            $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
            
            // set margins
            $pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
            $pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
            $pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
            
            // $pdf->SetLineStyle(array('width' => 0.5, 'cap' => 'butt', 'join' => 'miter', 'dash' => 4, 'color' => array(255, 0, 0)));
            // set auto page breaks
            $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
            
            // set image scale factor
            $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
            
            // set some language-dependent strings (optional)
            if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
                require_once(dirname(__FILE__).'/lang/eng.php');
                $pdf->setLanguageArray($l);
            }
            
            // ---------------------------------------------------------
            
            // set font
            $pdf->SetFont('dejavusans', '', 10);
            
            
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
            // Print a table
            
            // add a page
            $pdf->AddPage();
                
            $html = '';
            $count = 1;
                if(count($present) > 0)
                {
                    $html.='
                        <table border="1" cellpadding="2" style="font-size: 10px">
                            <thead style="text-align: center;font-size: 10px !important; font-weight: bold;">
                                <tr>
                                    <th colspan="2" style="text-align: center;">PRESENT</th>
                                </tr>
                                <tr>
                                    <th>Name</th>
                                    <th>Designation</th>
                                </tr>
                            </thead>
                            <tbody>';

                                foreach($present as $presentemployee){
                                    $html.='<tr>
                                        <td>'.$count.'. '.$presentemployee->lastname.', '.$presentemployee->firstname.' '.$presentemployee->middlename[0].'. '.$presentemployee->suffix.'</td>
                                        <td style="text-align: center;">'.$presentemployee->designation.'</td>
                                    </tr>';
                                    $count+=1;
                                }
                                $html.='</tbody>
                        </table>
                        <table >
                            <thead>
                                <tr>
                                    <th ></th>
                                </tr>
                                </thead>
                                </table>';
                }
                if(count($tardy) > 0)
                {
                    $html.='
                    <table border="1" cellpadding="2" style="font-size: 10px">
                        <thead style="text-align: center;font-size: 10px !important; font-weight: bold;">
                            <tr>
                                <th colspan="2" style="text-align: center;">TARDY</th>
                            </tr>
                            <tr>
                                <th>Name</th>
                                <th>Designation</th>
                            </tr>
                        </thead>
                        <tbody>';

                        foreach($tardy as $tardyemployee){
                            $html.='<tr>
                                <td>'.$count.'. '.$tardyemployee->lastname.', '.$tardyemployee->firstname.' '.$tardyemployee->middlename[0].'. '.$tardyemployee->suffix.'</td>
                                <td style="text-align: center;">'.$tardyemployee->designation.'</td>
                            </tr>';
                            $count+=1;

                        }
                        $html.='</tbody>
                    </table>
                    <table >
                        <thead>
                            <tr>
                                <th ></th>
                            </tr>
                            </thead>
                            </table>';
                }
                if(count($absent) > 0)
                {
                    $html.='
                    <table border="1" cellpadding="2" style="font-size: 10px">
                        <thead style="text-align: center;font-size: 10px !important; font-weight: bold;">
                            <tr>
                                <th colspan="2" style="text-align: center;">ABSENT</th>
                            </tr>
                            <tr>
                                <th>Name</th>
                                <th>Designation</th>
                            </tr>
                        </thead>
                        <tbody>';

                        foreach($absent as $absentemployee){
                            $html.='<tr>
                                <td>'.$count.'. '.$absentemployee->lastname.', '.$absentemployee->firstname.' '.$absentemployee->middlename[0].'. '.$absentemployee->suffix.'</td>
                                <td style="text-align: center;">'.$absentemployee->designation.'</td>
                            </tr>';
                            $count+=1;

                        }
                        $html.='</tbody>
                    </table>
                    <br>';
                }
                // output the HTML content
                
                set_time_limit(3000);
                $pdf->writeHTML($html, true, false, true, false, '');
                
                $pdf->lastPage();
                
                // ---------------------------------------------------------
                //Close and output PDF document
                $pdf->Output('Student Assessment.pdf', 'I');

        }else{

            return view('hr.summaries.employeeattendancereport')
                ->with('present', $present)
                ->with('tardy', $tardy)
                ->with('absent', $absent)
                ->with('selectedstatus', $selectedstatus)
                ->with('selecteddate', $selecteddate);

        }

    }
}

class MYPDF extends TCPDF {

    //Page header
    public function Header() {
        $schoollogo = DB::table('schoolinfo')->first();
        $image_file = public_path().'/'.$schoollogo->picurl;
        $extension = explode('.', $schoollogo->picurl);
        $this->Image('@'.file_get_contents($image_file),15,9,17,17);
        
        $schoolname = $this->writeHTMLCell(false, 50, 40, 10, '<span style="font-weight: bold">'.$schoollogo->schoolname.'</span>', false, false, false, $reseth=true, $align='L', $autopadding=true);
        $schooladdress = $this->writeHTMLCell(false, 50, 40, 15, '<span style="font-weight: bold; font-size: 10px;">'.$schoollogo->address.'</span>', false, false, false, $reseth=true, $align='L', $autopadding=true);
        $title = $this->writeHTMLCell(false, 50, 40, 20, 'Attendance Report - Employees', false, false, false, $reseth=true, $align='L', $autopadding=true);
        // Ln();
    }

    // Page footer
    public function Footer() {
        // Position at 15 mm from bottom
        $this->SetY(-15);
        // Set font
        $this->SetFont('helvetica', 'I', 8);
        // Page number
        $this->Cell(0, 10, 'Page '.$this->getAliasNumPage().' of '.$this->getAliasNbPages(), 0, false, 'C', 0, '', 0, false, 'T', 'M');
        $this->Cell(0, 10, date('m/d/Y'), 0, false, 'C', 0, '', 0, false, 'T', 'M');
    }
}