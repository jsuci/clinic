<?php

namespace App\Http\Controllers\HRControllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;
class HRPayrollV2Controller extends Controller
{
    public function index(Request $request)
    {
        return 'asdasd';
    }
}
