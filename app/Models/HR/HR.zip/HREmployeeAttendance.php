<?php

namespace App\Models\HR;

use Illuminate\Database\Eloquent\Model;
use DB;
class HREmployeeAttendance extends Model
{
    public static function getattendance($date,$employee)
    {
        date_default_timezone_set('Asia/Manila');
        
        $taphistory = DB::table('taphistory')
            ->where('tdate', $date)
            // ->where('tdate', '2020-10-13')
            ->where('studid', $employee->id)
            // ->where('studid', 11)
            ->where('utype', $employee->usertypeid)
            // ->where('utype', 1)
            ->orderBy('ttime')
            ->where('deleted','0')
            ->get();
            // return $taphistory;
        $status = 1;

        if(count($taphistory) == 0)
        {
            
            $detailamin     = '00:00:00';
            $detailamout    = '00:00:00';
            $detailpmin     = '00:00:00';
            $detailpmout    = '00:00:00';

            // $status         = 0;

        }elseif(count($taphistory) == 1){
            
            if(date('A', strtotime($taphistory[0]->ttime)) == 'AM')
            {
                $detailamin     = $taphistory[0]->ttime;
                $detailamout    = '00:00:00';
                $detailpmin     = '00:00:00';
                $detailpmout    = '00:00:00';
            }else{
                $detailamin     = '00:00:00';
                $detailamout    = '00:00:00';
                $detailpmin     = date('h:i:s',strtotime($taphistory[0]->ttime));
                $detailpmout    = '00:00:00';
            }

            // $status         = 1;
            
        }else{
            // return $taphistory;
            $customtimesched = Db::table('employee_customtimesched')
                ->where('employeeid', 11)
                ->first();

            if(count(collect($customtimesched)) == 0){

                DB::table('employee_customtimesched')
                    ->insert([
                        'amin'          =>  '08:00:00',
                        'amout'         =>  '12:00:00',
                        'pmin'          =>  '13:00:00',
                        'pmout'         =>  '17:00:00',
                        'employeeid'    =>  $employee->id,
                        'createdby'     =>  auth()->user()->id,
                        'createdon'     =>  date('Y-m-d H:i:s')
                    ]);
                
                $customtimesched = Db::table('employee_customtimesched')
                    ->where('employeeid', $employee->id)
                    ->first();

            }else{
                if(strtolower(date('A', strtotime($customtimesched->pmin))) == 'am')
                {
                    $customtimesched->pmin = date('H:i:s',strtotime($customtimesched->pmin.' PM'));
                }
                
                if(strtolower(date('A', strtotime($customtimesched->pmout))) == 'am')
                {
                    $customtimesched->pmout = date('H:i:s',strtotime($customtimesched->pmout.' PM'));
                }
            }
            // return collect($customtimesched);
            
            // $custom_amin = $customtimesched->amin;
            // $custom_amout = $customtimesched->amout;

            $detailamintimes   = collect($taphistory->where('ttime','<',$customtimesched->amout)->where('tapstate','IN'))->values()->sortby('ttime');
            if(count($detailamintimes) == 0)
            {

                $detailamin     =   "00:00:00";

            }else{
                
                $detailamin     = date('h:i:s', strtotime(collect($detailamintimes)->sortBy('ttime')->first()->ttime));
                
                $key            = $taphistory->search(function($item) use($detailamintimes){
                                    return $item->id == collect($detailamintimes)->first()->id;
                                });
                                
                $taphistory->pull($key);
            }
            
            
            // $detailamin =  reset($taphistory)[0]->ttime;
            // unset($taphistory[0]);
            // $taphistory = collect($taphistory)->values();
            
            $detailamouttimes   = collect($taphistory->where('ttime','<=',$customtimesched->pmin)->where('tapstate','OUT'))->values()->sortby('ttime');
            
            // $detailamouttimes   = collect($taphistory->whereBetween('ttime',[$customtimesched->amout,$customtimesched->pmin])->where('tapstate','OUT'))->values()->sortby('ttime');

            if(count($detailamouttimes) == 0)
            {

                $detailamout    =   "00:00:00";

            }else{
                
                $detailamout        = date('h:i:s',strtotime(collect($detailamouttimes)->last()->ttime));
                
                if(count($taphistory)>0)
                {   
                    foreach($taphistory as $removekey => $removevalue)
                    {
                        if($removevalue->ttime <= $detailamout)
                        {
                            unset($taphistory[$removekey]);
                        }
                        
                    }


                }
                
            }
            // return $detailamout;
            
            $detailpmintimes    = collect($taphistory->where('tapstate','IN'))->values()->sortBy('ttime');
            // return $detailpmintimes;
            if(count($detailpmintimes) == 0)
            {

                $detailpmin     =   "00:00:00";

            }else{
                
                $detailpmin     = date('h:i:s', strtotime(collect($detailpmintimes)->sortBy('ttime')->first()->ttime));
                
                $key            = $taphistory->search(function($item) use($detailpmintimes){
                                    return $item->id == collect($detailpmintimes)->first()->id;
                                });

                $taphistory->pull($key);
            }
            $detailpmouttimes    = collect($taphistory->where('ttime','>',$customtimesched->pmin)->where('tapstate','OUT'))->values()->sortBy('ttime');

            if(count($detailpmouttimes) == 0)
            {

                $detailpmout     =   "00:00:00";

            }else{
                $detailpmout     = date('h:i:s', strtotime(collect($detailpmouttimes)->sortBy('ttime')->last()->ttime));
            }

        }
        // return $detailamin;
        // return $date.' '.$detailamin;
        // if(date('Y-m-d H:i:s') < date('Y-m-d H:i:s',strtotime($date.' '.$detailamin.' AM')))
        // {
        //     $detailamin = '00:00:00';
        // }
        // if(date('Y-m-d H:i:s') < date('Y-m-d H:i:s',strtotime($date.' '.$detailamin.' AM')))
        // {
        //     $detailamin = '00:00:00';
        // }

        return (object)array(
            'amin'  => $detailamin,
            'amout' => $detailamout,
            'pmin'  => $detailpmin,
            'pmout' => $detailpmout,
            'status' => $status
        );
    }
    public static function payrollattendancev2($date,$employee,$hourlyrate,$basicsalaryinfo)
    {
        date_default_timezone_set('Asia/Manila');
        // $date = '2020-10-07';
        // return collect($employee);
        $customtimesched = Db::table('employee_customtimesched')
            ->where('employeeid', $employee->employeeid)
            ->first();
        // return collect($customtimesched);
        if($customtimesched){

            DB::table('employee_customtimesched')
                ->insert([
                    'amin'          =>  '08:00:00',
                    'amout'         =>  '12:00:00',
                    'pmin'          =>  '13:00:00',
                    'pmout'         =>  '17:00:00',
                    'employeeid'    =>  $employee->employeeid,
                    'createdby'     =>  auth()->user()->id,
                    'createdon'     =>  date('Y-m-d H:i:s')
                ]);
            
            $customtimesched = Db::table('employee_customtimesched')
                ->where('employeeid', $employee->employeeid)
                ->first();

        }else{
            if(strtolower(date('A', strtotime($customtimesched->pmin))) == 'am')
            {
                $customtimesched->pmin = date('H:i:s',strtotime($customtimesched->pmin.' PM'));
            }
            
            if(strtolower(date('A', strtotime($customtimesched->pmout))) == 'am')
            {
                $customtimesched->pmout = date('H:i:s',strtotime($customtimesched->pmout.' PM'));
            }
        }

        // if($date>date('Y-m-d'))
        // {
        //     $status = 0;
        // }
        $taphistory = DB::table('taphistory')
            // ->select('ttime','tapstate')
            ->where('tdate', $date)
            // ->where('tdate', '2020-10-23')
            ->where('studid', $employee->employeeid)
            ->where('utype', $employee->usertypeid)
            ->orderBy('ttime','asc')
            ->where('deleted','0')
            ->get();
        // return $taphistory;
        if(count($taphistory) > 0)
        {
            $status = 1;
        }else{
            $status = 2;
        }

        // return $taphistory;

        $attendance = array();
        
        if(count($taphistory) == 1)
        {
            
            if(date('A', strtotime($taphistory[0]->ttime)) == 'AM')
            {
                $detailamin     = $taphistory[0]->ttime;
                $detailamout    = null;
                $detailpmin     = null;
                $detailpmout    = null;
            }else{
                $detailamin     = null;
                $detailamout    = null;
                $detailpmin     = date('h:i:s',strtotime($taphistory[0]->ttime));
                $detailpmout    = null;
            }
            $attendance = (object)array(
                'amin'          => $detailamin,
                'amout'         =>  $detailamout,
                'pmin'          => $detailpmin,
                'pmout'         =>  $detailpmout
            );
            
        }else if(count($taphistory) > 1){
            // $status = 1;
            $taphistory = collect($taphistory)->values();

            $detailamintimes   = collect($taphistory->where('ttime','<',$customtimesched->amout)->where('tapstate','IN'))->values()->sortby('ttime');
            if(count($detailamintimes) == 0)
            {

                $detailamin     =   "00:00:00";

            }else{
                
                $detailamin     = date('h:i:s', strtotime(collect($detailamintimes)->sortBy('ttime')->first()->ttime));
                
                $key            = $taphistory->search(function($item) use($detailamintimes){
                                    return $item->id == collect($detailamintimes)->first()->id;
                                });
                                
                $taphistory->pull($key);
            }
            // return $detailamin;

            $detailamouttimes   = collect($taphistory->where('ttime','<=',$customtimesched->pmin)->where('tapstate','OUT'))->values()->sortby('ttime');
            // return $detailamouttimes;
            // $detailamouttimes   = collect($taphistory->whereBetween('ttime',[$customtimesched->amout,$customtimesched->pmin])->where('tapstate','OUT'))->values()->sortby('ttime');
            // return $detailamouttimes;
            if(count($detailamouttimes) == 0)
            {

                $detailamout    =   null;

            }else{
                
                // $detailamout        = collect($detailamouttimes)->last()->ttime;
                
                $detailamout        = date('h:i:s',strtotime(collect($detailamouttimes)->last()->ttime));
                
                if(count($taphistory)>0)
                {   
                    foreach($taphistory as $removekey => $removevalue)
                    {
                        if($removevalue->ttime <= $detailamout)
                        {
                            unset($taphistory[$removekey]);
                        }
                        
                    }


                }
                
            }
            
            
            $detailpmintimes    = collect($taphistory->where('tapstate','IN'))->values()->sortBy('ttime');
            // return $taphistory;
            // return $detailpmintimes;
            if(count($detailpmintimes) == 0)
            {

                $detailpmin     =   null;

            }else{
                
                $detailpmin     = date('H:i:s', strtotime(collect($detailpmintimes)->sortBy('ttime')->first()->ttime));
                
                $key            = $taphistory->search(function($item) use($detailpmintimes){
                                    return $item->id == collect($detailpmintimes)->first()->id;
                                });
                $taphistory->pull($key);
            }
            $detailpmouttimes    = collect($taphistory->where('tapstate','OUT'))->values()->sortBy('ttime');

            if(count($detailpmouttimes) == 0)
            {

                $detailpmout     =   null;

            }else{
                $detailpmout     = date('H:i:s', strtotime(collect($detailpmouttimes)->sortBy('ttime')->last()->ttime));
            }
            $attendance = (object)array(
                'amin'      => $detailamin,
                'amout'      =>  $detailamout,
                'pmin'      => $detailpmin,
                'pmout'      =>  $detailpmout
            );

        }
        // return collect($attendance);
        

        $getlatedeductionsetup = Db::table('deduction_tardinesssetup')
            ->where('status','1')
            ->first();
        // return collect($employee);
        if(strtolower($getlatedeductionsetup->type) == 'custom'){
                
            $deductiontardinessapplication = Db::table('deduction_tardinessapplication')
                ->where('departmentid',$employee->departmentid)
                ->where('deleted','0')
                ->get();
                // return collect($deductiontardinessapplication);
            if(count($deductiontardinessapplication)>0){
                $deductioncomputation = Db::table('deduction_tardinessdetail')
                    ->where('id',$deductiontardinessapplication[0]->tardinessdetailid)
                    ->where('deleted','0')
                    ->get();
            } 
        }
        
        $latedeductionamount    = 0;

        $lateminutes            = 0;

        $presentminutes         = 0;

        $undertimeminutes       = 0;
        
        $holidaypay             = 0;

        $dailynumofhours        = 0;

        $absentdeduction        = 0;
        
        $noabsentdays           = 0;

        $minuteslate            = 0;
        $customlateduration     = 0;
        $customlateallowance    = 0;
        $customlateamount       = 0;

        $minuteslatehalfday     = 0;

        $lateamin               = 0;
        $undertimeamout         = 0;
        $latepmin               = 0;
        $undertimepmout         = 0;

        $hoursperday = 0;
        // return collect($employee);
        if(strtolower($employee->ratetype) == 'hourly')
        {
            
            if($date<=date('Y-m-d'))
            {
                $selectedday = strtolower(date('D', strtotime($date)));
                if(strtolower($selectedday) == 'mon')
                {
                    $hoursperday = $basicsalaryinfo->mondayhours;
                }
                elseif(strtolower($selectedday) == 'tue')
                {
                    $hoursperday = $basicsalaryinfo->tuesdayhours;
                }
                elseif(strtolower($selectedday) == 'wed')
                {
                    $hoursperday = $basicsalaryinfo->wednesdayhours;
                }
                elseif(strtolower($selectedday) == 'thu')
                {
                    $hoursperday = $basicsalaryinfo->thursdayhours;
                }
                elseif(strtolower($selectedday) == 'fri')
                {
                    $hoursperday = $basicsalaryinfo->fridayhours;
                }
                elseif(strtolower($selectedday) == 'sat')
                {
                    $hoursperday = $basicsalaryinfo->saturdayhours;
                }
                elseif(strtolower($selectedday) == 'sun')
                {
                    $hoursperday = $basicsalaryinfo->sundayhours;
                }
                else
                {
                    $hoursperday = 0;
                }
    
                $customtimesched = DB::table('employee_basishourly')
                    ->select('timein','timeout','timeshift')
                    ->where('deleted','0')
                    ->where('employeeid',$employee->employeeid)
                    ->where('day', $selectedday)
                    ->get();
                    
                $taphistories = DB::table('taphistory')
                    ->select('ttime','tapstate')
                    ->where('tdate', $date)
                    // ->where('tdate', '2020-10-16')
                    ->where('studid', $employee->employeeid)
                    ->where('utype', $employee->usertypeid)
                    ->orderBy('ttime','asc')
                    ->orderByDesc('tapstate')
                    ->where('deleted','0')
                    ->get();
                
                // return $taphistories;
                $taparray = array();
                if(count($taphistories)>0)
                {
                    $state = 1;
                    $timein = null;
                    $timeout = null;
                    $last_key = collect($taphistories)->keys()->last();
                    foreach($taphistories as $taphistorykey=>$taphistoryvalue) {
                        if($taphistoryvalue->tapstate == 'IN')
                        {
                            if($state == 1)
                            {
                                $state = 2;
                                $timein = $taphistoryvalue->ttime;
                                
                                if ($taphistorykey == $last_key) {
                                    array_push($taparray, (object)array(
                                        'timein'    => $timein,
                                        'timeout'   => null
                                    ));
                                }
                            }
                        }
                        else{
                            if($state == 1)
                            {
    
                                $state = 2;
                                array_push($taparray, (object)array(
                                    'timein'    => null,
                                    'timeout'   => $taphistoryvalue->ttime
                                ));
    
                            }else{
                                $state = 1;
                                array_push($taparray, (object)array(
                                    'timein'    => $timein,
                                    'timeout'   => $taphistoryvalue->ttime
                                ));
                            }
                        }
                    }    
    
                }
                if(count($taparray)>0)
                {
                    // return $taparray;
                    foreach($taparray as $taptime)
                    {
                        
                        $time1 = strtotime('08:00:00');
                        $time2 = strtotime('09:30:00');
                        $difference = round(abs($time2 - $time1) / 3600,2);
                    }
                }
                // return $customtimesched;
                // return $customtimesched;
                if(count($customtimesched) > 0 && count($taparray) > 0)
                {
                    // return $deductioncomputation;
                    
                    if(isset($deductioncomputation))
                    {
                        if($deductioncomputation[0]->hours == '1')
                        {
                            $customlateminutes = ($deductioncomputation[0]->lateduration*60);
                        }
                        else{
                            $customlateminutes = $deductioncomputation[0]->lateduration;
                        }
                        if($deductioncomputation[0]->timeallowancetype == 1)
                        {
                            $timeallowance = $deductioncomputation[0]->timeallowance;
                        }else{
                            $timeallowance = ($deductioncomputation[0]->timeallowance*60);
                        }
                        if($deductioncomputation[0]->basisfixedamount == 1)
                        {
                            
                            $customlateamount = $deductioncomputation[0]->amount;
    
                        }else{

                            if(strtolower($selectedday) == 'mon')
                            {
                                $hoursperday = $basicsalaryinfo->mondayhours;
                            }
                            elseif(strtolower($selectedday) == 'tue')
                            {
                                $hoursperday = $basicsalaryinfo->tuesdayhours;
                            }
                            elseif(strtolower($selectedday) == 'wed')
                            {
                                $hoursperday = $basicsalaryinfo->wednesdayhours;
                            }
                            elseif(strtolower($selectedday) == 'thu')
                            {
                                $hoursperday = $basicsalaryinfo->thursdayhours;
                            }
                            elseif(strtolower($selectedday) == 'fri')
                            {
                                $hoursperday = $basicsalaryinfo->fridayhours;
                            }
                            elseif(strtolower($selectedday) == 'sat')
                            {
                                $hoursperday = $basicsalaryinfo->saturdayhours;
                            }
                            elseif(strtolower($selectedday) == 'sun')
                            {
                                $hoursperday = $basicsalaryinfo->sundayhours;
                            }
                            else
                            {
                                $hoursperday = 0;
                            }
                            $customlateamount = ($customlateminutes*(($hoursperday*$hourlyrate)*($deductioncomputation[0]->lateduration/100)));
                        }
    
                        $customlateduration = $customlateminutes;
                        $customlateallowance = $timeallowance;
                    }

                    // return $customtimesched;
                    foreach($customtimesched as $schedkey=>$schedvalue)
                    {
                        // return 
                        $enteredsched = collect($taparray)->where('timein', '<=',$schedvalue->timein);
                        // return $enteredsched;
                        if(count($enteredsched) == 0)
                        {
                            $enteredsched = collect($taparray)->where('timein', '<=',$schedvalue->timeout);
                        }
                        else{
                            // $enteredsched = collect($enteredsched)->where('timeout', '<=',$schedvalue->timeout);
                            // return collect(array_key_exists($schedkey+1, $customtimesched));
                            if(array_key_exists($schedkey+1, $customtimesched))
                            {
                                // return 'adsasd';
                                $enteredsched = collect($enteredsched)->where('timeout', '<=',$customtimesched[$schedkey+1]->timeout);
                            }else{
                                $enteredsched = collect($enteredsched);
                            }
                            // return $enteredsched;
                        }
                        
                        if(count($enteredsched) == 0)
                        {
                            
                            $lateconfig = strtotime($schedvalue->timeout) - strtotime($schedvalue->timein);
                            if($lateconfig > 0)
                            {
    
                                if($schedvalue->timeshift == 'mor')
                                {
                                    $lateamin += ($lateconfig/60);
                                }else{
                                    $latepmin += ($lateconfig/60);
                                }
                            } 
                        }else{
                            
                            $enteredsched =  collect($enteredsched)->sortByDesc('timein')->values();
                            
                            $lateconfig = strtotime($enteredsched[0]->timein) - strtotime($schedvalue->timein);
                            if($lateconfig > 0)
                            {
    
                                if($schedvalue->timeshift == 'mor')
                                {
                                    $lateamin += ($lateconfig/60);
                                }else{
                                    $latepmin += ($lateconfig/60);
                                }
                            } 
    
                            $undertimeconfig = strtotime($schedvalue->timeout) - strtotime($enteredsched[0]->timeout);
                            if($undertimeconfig > 0)
                            {
                                if($schedvalue->timeshift == 'mor')
                                {
                                    $undertimeamout += ($undertimeconfig/60);
                                }else{
                                    $undertimepmout += ($undertimeconfig/60);
                                }
                            } 
                            // return $undertimeconfig/60;
                        }
                           
                        // return $enteredsched;
                    }
                    // return $latepmin;
                }
            }

            
        }else{
            $hoursperday = $basicsalaryinfo->hoursperday;
            
            if(count(collect($attendance))>0)
            {
                $logintimeamin = $attendance->amin;
                $logintimeamout = $attendance->amout;
                $logintimepmin = $attendance->pmin;
                $logintimepmout = $attendance->pmout;
                
                if($basicsalaryinfo->attendancebased == 1)
                {
                    
                    if(isset($deductioncomputation))
                    {
                        
                        $customtimeamin = $customtimesched->amin;
                        $customtimeamout = $customtimesched->amout;
                        if(strtolower(date('A', strtotime($customtimesched->pmin))) == 'am')
                        {
                            $customtimepmin = date('H:i:s',strtotime($customtimesched->pmin.' PM'));
                        }else{
                            $customtimepmin = $customtimesched->pmin;
                        }
                        
                        if(strtolower(date('A', strtotime($customtimesched->pmout))) == 'am')
                        {
                            $customtimepmout = date('H:i:s',strtotime($customtimesched->pmout.' PM'));
                        }else{
                            $customtimepmout = $customtimesched->pmout;
                        }
                    }
                    else{
                        $customtimeamin = '08:00';
                        $customtimeamout = '12:00';
                        $customtimepmin = '13:00';
                        $customtimepmout = '17:00';
                    }
                    // return $basicsalaryinfo->shiftid;
                    
                            
                    if($basicsalaryinfo->shiftid == 0 || $basicsalaryinfo->shiftid == 1)
                    {
                        if($logintimeamin == null)
                        {
                            if($logintimeamout == null)
                            {
                                $late =  strtotime($customtimeamout) - strtotime($customtimeamin);
                                
                                if($basicsalaryinfo->shiftid == 1)
                                {
                                    $noabsentdays+=1;
                                    
                                    $absentdeduction+= ($dailyrate);
                                }
                            }else{
                                $late =  strtotime($logintimeamout) - strtotime($customtimeamin);
                                
                                $dailynumofhours += $basicsalaryinfo->hoursperday;
    
                            }
                            
                            if($late <= 0){
    
                                $late = 0;
    
                            }else{
                                
                                $late = $late/60;
                                
                                if(isset($deductioncomputation))
                                {
                                    if($deductioncomputation[0]->hours == '1')
                                    {
                                        $customlateminutes = ($deductioncomputation[0]->lateduration*60);
                                    }
                                    else{
                                        $customlateminutes = $deductioncomputation[0]->lateduration;
                                    }
                                    if($deductioncomputation[0]->timeallowancetype == 1)
                                    {
                                        $timeallowance = $deductioncomputation[0]->timeallowance;
                                    }else{
                                        $timeallowance = ($deductioncomputation[0]->timeallowance*60);
                                    }
                                    if($deductioncomputation[0]->basisfixedamount == 1)
                                    {
                                        
                                        $customlateamount = $deductioncomputation[0]->amount;
    
                                    }else{
                                        $customlateamount = ($customlateminutes*($dailyrate*($deductioncomputation[0]->lateduration/100)));
                                    }
    
                                    $customlateduration = $customlateminutes;
                                    $customlateallowance = $timeallowance;
                                }
                            }
                            $lateamin = $late;
                            
                        }else{
                                  
                            $late =  strtotime($logintimeamin) - strtotime($customtimeamin);
                            
                            $dailynumofhours += $basicsalaryinfo->hoursperday;
                            
                            if($late <= 0){
    
                                $late = 0;
    
                            }else{
                                $late = ($late/60);
                                
                                if(isset($deductioncomputation))
                                {
                                    
                                    if($deductioncomputation[0]->hours == '1')
                                    {
                                        $customlateminutes = ($deductioncomputation[0]->lateduration*60);
                                    }
                                    else{
                                        $customlateminutes = $deductioncomputation[0]->lateduration;
                                    }
                                    if($deductioncomputation[0]->timeallowancetype == 1)
                                    {
                                        $timeallowance = $deductioncomputation[0]->timeallowance;
                                    }else{
                                        $timeallowance = ($deductioncomputation[0]->timeallowance*60);
                                    }
                                    
                                    if($deductioncomputation[0]->basisfixedamount == 1)
                                    {
                                        
                                        $customlateamount = $deductioncomputation[0]->amount;
    
                                    }else{
                                        $customlateamount = ($customlateminutes*($dailyrate*($deductioncomputation[0]->lateduration/100)));
                                    }
                                    $customlateduration = $customlateminutes;
                                    $customlateallowance = $timeallowance;
                                    
                                }
                            }
    
                            $lateamin = $late;
                            
                        }
    
                    }
                    if($basicsalaryinfo->shiftid == 0 || $basicsalaryinfo->shiftid == 2)
                    {
                        
                        if($logintimepmin == null)
                        {
    
                            if($logintimepmout == null)
                            {
    
                                if(date('Y-m-d H:i:s')>= date('Y-m-d', strtotime($date.' '.$customtimepmout)))
                                {
                                    $late =  strtotime($customtimepmout) - strtotime($customtimepmin);
                                }
                                else{
                                    $late = 0;
                                }
                                
                                if($basicsalaryinfo->shiftid == 2)
                                {
                                    $noabsentdays+=1;
                                    
                                    $absentdeduction+= ($dailyrate);
                                }
                                
                            }else{
    
                                $late =  strtotime($logintimepmout) - strtotime($customtimepmin);
    
                                $dailynumofhours += $basicsalaryinfo->hoursperday;
    
                            }
                            
                            if($late <= 0){
    
                                $late = 0;
    
                            }else{
                                
                                $late = $late/60;
                                
                                if(isset($deductioncomputation))
                                {
                                    if($deductioncomputation[0]->hours == '1')
                                    {
                                        $customlateminutes = ($deductioncomputation[0]->lateduration*60);
                                    }
                                    else{
                                        $customlateminutes = $deductioncomputation[0]->lateduration;
                                    }
                                    if($deductioncomputation[0]->timeallowancetype == 1)
                                    {
                                        $timeallowance = $deductioncomputation[0]->timeallowance;
                                    }else{
                                        $timeallowance = ($deductioncomputation[0]->timeallowance*60);
                                    }
                                    if($deductioncomputation[0]->basisfixedamount == 1)
                                    {
                                        
                                        $customlateamount = $deductioncomputation[0]->amount;
    
                                    }else{
                                        $customlateamount = ($customlateminutes*($dailyrate*($deductioncomputation[0]->lateduration/100)));
                                    }
    
                                    $customlateduration = $customlateminutes;
                                    $customlateallowance = $timeallowance;
                                }
    
                            }
                            
                        }else{  
    
                            $late =  strtotime($logintimepmin) - strtotime($customtimepmin);
                            
                            $dailynumofhours += $basicsalaryinfo->hoursperday;
                            
                            if($late <= 0){
    
                                $late = 0;
    
                            }else{
    
                                $late = $late/60;
                                
                                if(isset($deductioncomputation))
                                {
                                    if($deductioncomputation[0]->hours == '1')
                                    {
                                        $customlateminutes = ($deductioncomputation[0]->lateduration*60);
                                    }
                                    else{
                                        $customlateminutes = $deductioncomputation[0]->lateduration;
                                    }
                                    if($deductioncomputation[0]->timeallowancetype == 1)
                                    {
                                        $timeallowance = $deductioncomputation[0]->timeallowance;
                                    }else{
                                        $timeallowance = ($deductioncomputation[0]->timeallowance*60);
                                    }
                                    if($deductioncomputation[0]->basisfixedamount == 1)
                                    {
                                        
                                        $customlateamount = $deductioncomputation[0]->amount;
    
                                    }else{
                                        $customlateamount = ($customlateminutes*($dailyrate*($deductioncomputation[0]->lateduration/100)));
                                    }
    
                                    $customlateduration = $customlateminutes;
                                    $customlateallowance = $timeallowance;
    
                                }
    
                            }
    
                        }
    
                        $latepmin = $late;
    
                    }
                    
                    // if(isset($deductioncomputation))
                    // {
                        // if($minuteslate>0)
                        // {
                        //     // return ($hourlyrate/60)*28;
                        //     // return $hourlyrate;
                        //     $latedeductionamount+=($minuteslate*($hourlyrate/60));
                        // }
                    // ============== UNDERTIME
                    // return $logintimeamout;
                    if($basicsalaryinfo->shiftid == 0 || $basicsalaryinfo->shiftid == 1)
                    {
                        // return date('H:i:s');
                        // return $logintimeamout;
                            if($logintimeamout == null)
                            { 
                                if($customtimeamout<=date('H:i:s')){
                                    $lateundertime =  strtotime($customtimeamout) - strtotime($customtimeamin);
                                }else{
                                    $lateundertime = 0;
                                }
                            }else{ 
                                $lateundertime =  strtotime($customtimeamout) - strtotime($logintimeamout);
                                // return $lateundertime/60;
                            }
                            if($lateundertime>0)
                            {
                                $undertimeamout+=$lateundertime/60;
                            }
                                             
                    }
                    // return $logintimepmout;
                    
                    if($basicsalaryinfo->shiftid == 0 || $basicsalaryinfo->shiftid == 2)
                    {
                        if($logintimepmout == null)
                        { 
                            if($customtimepmout<=date('H:i:s'))
                            {
                                $lateundertime =  strtotime($customtimepmout) - strtotime($customtimepmin);
                            }else{
                                $lateundertime = 0;
                            }
                        }else{ 
                            $lateundertime =  strtotime($customtimepmout) - strtotime($logintimepmout);
                            // return $logintimepmout;
                        }   
                        
                        // if($lateundertime>0 && $customtimepmout<=date('H:i:s'))
                        // {
                        //     $undertimepmout+=$lateundertime/60;
                        // }  
                        if($lateundertime>0)
                        {
                            $undertimepmout+=$lateundertime/60;
                        }
                    }
                }
            }
          
        }
        // return $customlateamount;
        $lateminutes = ($lateamin + $latepmin)-$customlateallowance;
        // return $lateminutes;
        // return $later
        if($lateminutes>0)
        {
            if(isset($deductioncomputation))
            {
                $minutes = $lateminutes;
                // return $customlateamount;
                if($deductioncomputation[0]->deductfromrate == 1){
                    
                    for($x= 1; $minutes >= $customlateduration; $x++)
                    {
                        // return 'ad';
                        $minutes = $minutes-$customlateduration;
                        // return $customlateamount;
                        $latedeductionamount+=$customlateamount;
                    }
    
                }else{
                    if($minutes>=$customlateduration)
                    {
                        $latedeductionamount+=$customlateamount;
                    }
                    // $minutes = $minutes-$customlateduration;
                }
                
            }
            // return $customlateamount;
        }else{
            $lateminutes = 0;
        }
        // return $latedeductionamount;
        // $presentminutes=($hoursperday*60) - ($lateminutes+$undertimeamout+$undertimepmout);
        
        $presentminutes=($hoursperday*60);
        $hoursrendered = ($presentminutes-$lateminutes)/60;
        // return 300/60;

        $presentdaysamount=($hoursperday*$basicsalaryinfo->amount);
        return (object)array(
            'status'   => $status,
            'latedeductionamount'   => $latedeductionamount,
            'lateminutes'   => $lateminutes,
            'hoursrendered'   => $hoursrendered,
            'presentminutes'   => $presentminutes,
            'presentdaysamount'   => $presentdaysamount,
            'undertimeminutes'   => $undertimeminutes,
            'holidaypay'   => $holidaypay,
            'dailynumofhours'   => $dailynumofhours,
            'absentdeduction'   => $absentdeduction,
            'noabsentdays'   => $noabsentdays,
            'minuteslate'   => $minuteslate,
            'minuteslatehalfday'   => $minuteslatehalfday,
            'lateamin'   => $lateamin,
            'undertimeamout'   => $undertimeamout,
            'latepmin'   => $latepmin,
            'undertimepmout'   => $undertimepmout
        );
    }
}
