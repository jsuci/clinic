<?php

namespace App\Models\HR;

use Illuminate\Database\Eloquent\Model;
use DB;
use Crypt;
use \Carbon\Carbon;
use \Carbon\CarbonPeriod;
use App\MoneyCurrency;
use PDF;
use FontLib\Font;
use DateTime;
use DateInterval;
use DatePeriod;
use Conversion;
class HRSalaryDetails extends Model
{
    public static function salarydetails($employeeid,$payrolldates)
    {
        
        date_default_timezone_set('Asia/Manila');
        $picurl = DB::table('teacher')
        ->where('id', $employeeid)
        ->first()->picurl;

       $personalinfo = DB::table('teacher')
        ->select(
            'employee_personalinfo.gender',
            'civilstatus.civilstatus',
            'hr_school_department.department',
            'hr_school_department.id as departmentid',
            'teacher.id as employeeid',
            'teacher.lastname',
            'teacher.firstname',
            'teacher.middlename',
            'teacher.suffix',
            'usertype.utype',
            'usertype.id as usertypeid'
            )
        ->leftJoin('employee_personalinfo','teacher.id','employee_personalinfo.employeeid')
        ->leftJoin('civilstatus','employee_personalinfo.maritalstatusid','civilstatus.civilstatus')
        ->leftJoin('usertype','teacher.usertypeid','=','usertype.id')
        ->leftJoin('hr_school_department','usertype.departmentid','hr_school_department.id')
        ->where('teacher.id', $employeeid)
        ->first();

        
        $basicsalaryinfo = DB::table('employee_basicsalaryinfo')
            ->select(
                'employee_basicsalaryinfo.amount as basicsalary',
                'employee_basicsalaryinfo.shiftid',
                'employee_basistype.type as salarytype',
                'employee_basicsalaryinfo.amount',
                'employee_basicsalaryinfo.hoursperday',
                'employee_basicsalaryinfo.mondays',
                'employee_basicsalaryinfo.tuesdays',
                'employee_basicsalaryinfo.wednesdays',
                'employee_basicsalaryinfo.thursdays',
                'employee_basicsalaryinfo.fridays',
                'employee_basicsalaryinfo.saturdays',
                'employee_basicsalaryinfo.sundays',
                'employee_basicsalaryinfo.mondayhours',
                'employee_basicsalaryinfo.tuesdayhours',
                'employee_basicsalaryinfo.wednesdayhours',
                'employee_basicsalaryinfo.thursdayhours',
                'employee_basicsalaryinfo.fridayhours',
                'employee_basicsalaryinfo.saturdayhours',
                'employee_basicsalaryinfo.sundayhours',
                'employee_basicsalaryinfo.attendancebased',
                'employee_basicsalaryinfo.projectbasedtype'
            )
            ->join('employee_basistype','employee_basicsalaryinfo.salarybasistype','=','employee_basistype.id')
            ->where('employeeid', $employeeid)
            ->first();

        if(count(collect($basicsalaryinfo)) == 0)
        {
            $basicsalaryinfo = (object)array(
                'basicsalary'   => '0.00',
                'shiftid'   => null,
                'salarytype'   => null,
                'mondays'   => null,
                'tuesdays'   => null,
                'wednesdays'   => null,
                'thursdays'   => null,
                'fridays'   => null,
                'saturdays'   => null,
                'sundays'   => null,
                'attendancebased'   => null
                // 'employee_basicsalaryinfo.projectbased' => null
            );
        }


        $employeeworkdaysinaweek = 0;

        $payrollworkingdays = array();

        $begin = new DateTime($payrolldates->datefrom);

        $end = new DateTime($payrolldates->dateto);

        $end = $end->modify( '+1 day' ); 
        
        $intervalday = new DateInterval('P1D');

        $daterange = new DatePeriod($begin, $intervalday ,$end);

        foreach($daterange as $date){
            
            if(strtolower($date->format("D")) == 'mon' && $basicsalaryinfo->mondays == 1)
            {
                array_push($payrollworkingdays,$date->format("Y-m-d"));
                $employeeworkdaysinaweek+=1;
            }
            elseif(strtolower($date->format("D")) == 'tue' && $basicsalaryinfo->tuesdays == 1)
            {
                array_push($payrollworkingdays,$date->format("Y-m-d"));
                $employeeworkdaysinaweek+=1;
            }
            elseif(strtolower($date->format("D")) == 'wed' && $basicsalaryinfo->wednesdays == 1)
            {
                array_push($payrollworkingdays,$date->format("Y-m-d"));
                $employeeworkdaysinaweek+=1;
            }
            elseif(strtolower($date->format("D")) == 'thu' && $basicsalaryinfo->thursdays == 1)
            {
                array_push($payrollworkingdays,$date->format("Y-m-d"));
                $employeeworkdaysinaweek+=1;
            }
            elseif(strtolower($date->format("D")) == 'fri' && $basicsalaryinfo->fridays == 1)
            {
                array_push($payrollworkingdays,$date->format("Y-m-d"));
                $employeeworkdaysinaweek+=1;
            }
            elseif(strtolower($date->format("D")) == 'sat' && $basicsalaryinfo->saturdays == 1)
            {
                array_push($payrollworkingdays,$date->format("Y-m-d"));
                $employeeworkdaysinaweek+=1;
            }
            elseif(strtolower($date->format("D")) == 'sun' && $basicsalaryinfo->sundays == 1)
            {
                array_push($payrollworkingdays,$date->format("Y-m-d"));
                $employeeworkdaysinaweek+=1;
            }

        }
        
        
        $basicsalary    = 0;
        $permonthhalfsalary = 0;
        $perdaysalary       = 0;
        $hourlyrate         = 0;
        if(strtolower($basicsalaryinfo->salarytype) == 'monthly'){
            // return $workdays;
            if(count($payrollworkingdays) == 0){

                $dailyrate =  $basicsalaryinfo->amount / (int)(date('t') - date('01'));

            }else{
                // round($getrate[0]->amount / $monthdaycount, 2);
                // return $getrate[0]->amount / count($monthworkdays);
                // return $getrate[0]->amount;
                if($payrolldates->leapyear == 0){
                    
                    $dailyrate =  ($basicsalaryinfo->amount*12)/($employeeworkdaysinaweek*52);
                    
                }else{

                    $dailyrate =  ($basicsalaryinfo->amount*12)/(($employeeworkdaysinaweek*52)+1);

                }
                
                
                
            }
            // return $dailyrate;
            if($dailyrate == 0 || $basicsalaryinfo->hoursperday == 0){
                // return 'asdasd';
                $hourlyrate = 0;
            }else{
                
                $hourlyrate = ($dailyrate)/$basicsalaryinfo->hoursperday;
            }
            // return $payrollworkingdays;
            $permonthhalfsalary = $basicsalaryinfo->amount/2;
            if(count($payrollworkingdays) == 0)
            {
                $perdaysalary = $dailyrate;
            }else{
                $perdaysalary = $permonthhalfsalary/count($payrollworkingdays);
            }
            $basicsalary = $permonthhalfsalary;

        }
        elseif(strtolower($basicsalaryinfo->salarytype) == 'daily'){

            $dailyrate =  round($basicsalaryinfo->amount, 2);
    
            $hourlyrate = ($dailyrate)/$basicsalaryinfo->hoursperday;

            $perdaysalary = $dailyrate;
            $permonthhalfsalary = $perdaysalary*count($payrollworkingdays);
            $basicsalary = $permonthhalfsalary;

            // return $hourlyrate;

        }
        elseif(strtolower($basicsalaryinfo->salarytype) == 'hourly'){
    
            $hoursperday = 0;
            if($hoursperday == 0){
                if($basicsalaryinfo->mondayhours > 0){
                    $hoursperday = $basicsalaryinfo->mondayhours;
                }
                if($basicsalaryinfo->tuesdayhours > 0){
                    $hoursperday = $basicsalaryinfo->tuesdayhours;
                }
                if($basicsalaryinfo->wednesdayhours > 0){
                    $hoursperday = $basicsalaryinfo->wednesdayhours;
                }
                if($basicsalaryinfo->thursdayhours > 0){
                    $hoursperday = $basicsalaryinfo->thursdayhours;
                }
                if($basicsalaryinfo->fridayhours > 0){
                    $hoursperday = $basicsalaryinfo->fridayhours;
                }
                if($basicsalaryinfo->saturdayhours > 0){
                    $hoursperday = $basicsalaryinfo->saturdayhours;
                }
                if($basicsalaryinfo->sundayhours > 0){
                    $hoursperday = $basicsalaryinfo->sundayhours;
                }
            }
            
            $dailyrate = ($basicsalaryinfo->amount/$hoursperday);
            
            $hourlyrate = $basicsalaryinfo->amount;
            $perdaysalary = $dailyrate;
            $basicsalary = $perdaysalary*count($payrollworkingdays);


        }
        elseif(strtolower($basicsalaryinfo->salarytype) == 'project'){
            
            if($basicsalaryinfo->projectbasedtype == 'persalaryperiod'){
                
                $dailyrate =  $basicsalaryinfo->amount/count($workdays); 

                $hourlyrate =  ($basicsalaryinfo->amount/count($workdays))/$basicsalaryinfo->hoursperday; 

            }
            elseif($basicsalaryinfo->projectbasedtype == 'perday'){
                
                $dailyrate = $basicsalaryinfo->amount;

                $hourlyrate = $basicsalaryinfo->amount/$basicsalaryinfo->hoursperday;

            }
            elseif($basicsalaryinfo->projectbasedtype == 'permonth'){
                
                $payrollworkingdays = ($basicsalaryinfo->amount/count($monthworkdays))/$basicsalaryinfo->hoursperday;

                $dailyrate =  $basicsalaryinfo->amount/count($monthworkdays); 

                
                // return
                
            }
            $perdaysalary = $dailyrate;
            $basicsalary = $perdaysalary*count($payrollworkingdays);
            
        }

        // return $perdaysalary;
        

        $attendancepresent  = array();
        $attendanceabsent   = array();
        $attendanceunchecked   = array();
        $attendanceabsentdeductions = 0;

        $holidays           = array();

        
        $latedeductionamount    = 0;

        $lateminutes            = 0;

        $presentminutes         = 0;

        $undertimeminutes       = 0;
        
        $holidaypay             = 0;

        $dailynumofhours        = 0;
        $minuteslate            = 0;
        $minuteslatehalfday     = 0;

        $lateamin     = 0;
        $undertimeamout     = 0;
        $latepmin     = 0;
        $undertimepmout     = 0;

        // return array_reverse($payrollworkingdays)->sortByDesc();
        if(count($payrollworkingdays)>0)
        {
            foreach($payrollworkingdays as $payrollworkingday)
            {
                $attendance = HREmployeeAttendance::payrollattendancev2($payrollworkingday,$personalinfo,$hourlyrate);
                // return $attendance;
                $latedeductionamount    += $attendance->latedeductionamount;
        
                $lateminutes            += $attendance->lateminutes;
        
                $presentminutes         += $attendance->presentminutes;
        
                $undertimeminutes       += $attendance->undertimeminutes;
                
                $holidaypay             += $attendance->holidaypay;
        
                $dailynumofhours        += $attendance->dailynumofhours;

                $lateamin               += $attendance->lateamin;
                $undertimeamout         += $attendance->undertimeamout;
                $latepmin               += $attendance->latepmin;
                $undertimepmout         += $attendance->undertimepmout;
        
                // $absentdeduction        += $attendance->absentdeduction;
                // return count(collect($attendance));
                if($attendance->status == 0)
                {
                    if($payrollworkingday<=date('Y-m-d'))
                    {
                        array_push($attendanceabsent, $payrollworkingday);
                    }else{
                        array_push($attendanceunchecked, $payrollworkingday);
                    }
                
                    // $noabsentdays           += 1;

                }else{
                    array_push($attendancepresent, $payrollworkingday);
                }
            }
        }
        // return $attendancepresent;
        
        
        $leaves = Db::table('employee_leaves')
            ->join('hr_leaves','employee_leaves.leaveid','=','hr_leaves.id')
            ->where('hr_leaves.deleted','0')
            ->where('employee_leaves.payrolldone','0')
            ->where('employee_leaves.status','approved')
            ->where('employee_leaves.employeeid',$employeeid)
            ->get();
    

        $st_date = $payrolldates->datefrom;
        $ed_date = $payrolldates->dateto;
    
        $syid = DB::table('sy')
            ->where('isactive','1')
            ->first();

        $getholidays = DB::table('schoolcal')
            ->leftJoin('schoolcaltype','schoolcal.type','=','schoolcaltype.id')
            ->where('schoolcal.syid',$syid->id)
            ->where('schoolcal.deleted','0')
            ->where('schoolcaltype.type','1')
            ->get();
            
        $holidaypay = 0;
        if(count($getholidays)>0)
        {
            foreach($getholidays as $holiday)
            {
                
                $holidays = array();

                $holidaybegin = new DateTime($holiday->datefrom);

                $holidayend = new DateTime($holiday->dateto);

                $holidayend = $holidayend->modify( '+1 day' ); 
                
                $holidayintervalday = new DateInterval('P1D');

                $holidaydaterange = new DatePeriod($holidaybegin, $holidayintervalday ,$holidayend);

                foreach($holidaydaterange as $holidaydate){

                    array_push($holidays,$holidaydate->format("Y-m-d"));
                }
                if(count($holidays)>0)
                {
                    foreach($holidays as $holidaydate)
                    {
                        if(in_array($holidaydate, $attendanceabsent))
                        {
                            //no work
                            $holidaypay += ($dailyrate * ($holiday->ratepercentagenowork/100));
                        }
                        if(in_array($holidaydate, $attendancepresent))
                        {

                            $holidaypay+=($dailyrate * ($holiday->ratepercentageworkon/100));
                        }
                    }
                }

            }
        }

        $leavedetails = array();

        if(count($leaves) > 0){
            
            foreach($leaves as $leave){
                $amountearn = 0;
                $amountdeduct = 0;
                $leavesnumdays = 0;
                $leaveid = 0;
                $status = 0; //0 = deduct; 1 = earn;

                $startdate = $leave->datefrom;
                $enddate = $leave->dateto;
                $allleavedates = range(strtotime($startdate), strtotime($enddate),86400);
                
                $leavedatesperiod = array();
                foreach($allleavedates as $allleavedate)
                {   
                    array_push($leavedatesperiod, date('Y-m-d', $allleavedate));
                }
                // return $allleavedates;
                
                $daysleave = array();
                foreach ($leavedatesperiod as $leavedatesperiod) {
                    if(strtolower(date('D',strtotime($leavedatesperiod))) == 'mon')
                    {
                         if($basicsalaryinfo->mondays == 1)
                         {
                             array_push($daysleave,date('Y-m-d',strtotime($leavedatesperiod)));
                         }
                    } 
                    if(strtolower(date('D',strtotime($leavedatesperiod))) == 'tue')
                    {
                         if($basicsalaryinfo->tuesdays == 1)
                         {
                             array_push($daysleave,date('Y-m-d',strtotime($leavedatesperiod)));
                         }
                    } 
                    if(strtolower(date('D',strtotime($leavedatesperiod))) == 'wed')
                    {
                         if($basicsalaryinfo->wednesdays == 1)
                         {
                             array_push($daysleave,date('Y-m-d',strtotime($leavedatesperiod)));
                         }
                    } 
                    if(strtolower(date('D',strtotime($leavedatesperiod))) == 'thu')
                    {
                         if($basicsalaryinfo->thursdays == 1)
                         {
                             array_push($daysleave,date('Y-m-d',strtotime($leavedatesperiod)));
                         }
                    } 
                    if(strtolower(date('D',strtotime($leavedatesperiod))) == 'fri')
                    {
                         if($basicsalaryinfo->fridays == 1)
                         {
                             array_push($daysleave,date('Y-m-d',strtotime($leavedatesperiod)));
                         }
                    } 
                    if(strtolower(date('D',strtotime($leavedatesperiod))) == 'sat')
                    {
                         if($basicsalaryinfo->saturdays == 1)
                         {
                             array_push($daysleave,date('Y-m-d',strtotime($leavedatesperiod)));
                         }
                    } 
                    if(strtolower(date('D',strtotime($leavedatesperiod))) == 'sun')
                    {
                         if($basicsalaryinfo->sundays == 1)
                         {
                             array_push($daysleave,date('Y-m-d',strtotime($leavedatesperiod)));
                         }
                    } 
                }
                
                $leaveid = $leave->id;

                $daysperiodleave = array();
                foreach($daysleave as $dayleave){
                    if (in_array($dayleave, $payrollworkingdays)) {
                        $leavesnumdays+=1;
                        array_push($daysperiodleave, $dayleave);
                    }
                }
                
                $daysperiodholiday = array();
                foreach ($getholidays as $getholiday) {
                    $beginholiday = new DateTime($getholiday->datefrom);
                    $endholiday = new DateTime($getholiday->dateto);
                    $endholiday = $endholiday->modify( '+1 day' );                     
                    $intervalholiday = new DateInterval('P1D');
                    $daterangeholiday = new DatePeriod($beginholiday, $intervalholiday ,$endholiday);
                    foreach($daterangeholiday as $dateholiday){
                        array_push($daysperiodholiday,$dateholiday->format("Y-m-d"));
                    }
                }

                $numdaysholidays    = 0;
                $payholidaydays     = 0;
                foreach($daysperiodleave as $dayperiodleave){
                    if(in_array($dayperiodleave,$daysperiodholiday)){
                        $numdaysholidays+=1;
                        $payholidaydays+=($dailyrate* $getholiday->ratepercentagenowork)/100;                       
                    }                    
                    $pos = array_search($dayperiodleave, $attendanceabsent);
                    unset($attendanceabsent[$pos]);
                }
                
                $getpay = DB::table('hr_leaves')
                    ->where('id',$leave->id)
                    ->where('deleted','0')
                    ->get();
                if(count($getpay) == 0){
                    $amountdeduct+=($dailyrate*$leavesnumdays);
                }else{
                    if($getpay[0]->withpay == 1){
                        $amountearn+=($dailyrate*$leavesnumdays);
                        $status=1;
                    }
                }
                
                if($numdaysholidays>0){
                    $amountearn+=$payholidaydays;
                    $status=1;
                }

                if($leaveid != 0)
                {
                    $description = DB::table('hr_leaves')
                        ->where('id', $leaveid)
                        ->first();

                    if(count(collect($description)) == 0)
                    {
                        $leavedescription = "";
                    }else{
                        $leavedescription = $description->leave_type;
                    }
                    $leavedays = array();
    
                    $leavebegin = new DateTime($leave->datefrom);
    
                    $leaveend = new DateTime($leave->dateto);
    
                    $leaveend = $leaveend->modify( '+1 day' ); 
                    
                    $leaveinterval = new DateInterval('P1D');
    
                    $leaverange = new DatePeriod($leavebegin, $leaveinterval ,$leaveend);
                    // return collect($leaverange);
                    foreach($leaverange as $leavedate){
                        // unset($attendanceabsent[array_search($leavedate->format("Y-m-d"), $attendanceabsent)]);
                        $key = array_search($leavedate->format("Y-m-d"), $attendanceabsent);
                        if ($key === false) 
                        {
                        }else{
                            collect($attendanceabsent)->forget([$key]);
                        }
                        array_push($leavedays,$leavedate->format("Y-m-d"));
                    }
                    
                    array_push($leavedetails,(object)array(
                        'leaveid'       => $leaveid,
                        'description'   => $leavedescription,
                        'noofdays'      => $leavesnumdays,
                        'amountearn'    => number_format($amountearn,2),
                        'amountdeduct'  => number_format($amountdeduct,2),
                        'leavedays'     => $leavedays,
                        'status'        => $status
                    ));
                }
            }
        }
        
        $overtimedetails = array();
        $overtimes = Db::table('employee_overtime')
            ->where('employee_overtime.deleted','0')
            ->where('employee_overtime.payrolldone','0')
            ->where('employee_overtime.status','approved')
            ->where('employee_overtime.employeeid',$employeeid)
            ->get();
            
        if(count($overtimes) > 0){
            
            $holidayovertimepay = 0;
            $overtimesalary     = 0;
            $dailyovertimehours = 0;

            $daysperiodholiday = array();

            foreach ($getholidays as $getholiday) {

                $beginholiday = new DateTime($getholiday->datefrom);

                $endholiday = new DateTime($getholiday->dateto);

                $endholiday = $endholiday->modify( '+1 day' ); 
                
                $intervalholiday = new DateInterval('P1D');

                $daterangeholiday = new DatePeriod($beginholiday, $intervalholiday ,$endholiday);


                foreach($daterangeholiday as $dateholiday){

                    array_push($daysperiodholiday,$dateholiday->format("Y-m-d"));

                }

            }

            foreach($overtimes as $overtime){

                $daysovertimelist = array();

                $beginovertime = new DateTime($overtime->datefrom);

                $endovertime = new DateTime($overtime->dateto);

                $endovertime = $endovertime->modify( '+1 day' ); 
                
                $intervalovertime = new DateInterval('P1D');

                $daterangeovertime = new DatePeriod($beginovertime, $intervalovertime ,$endovertime);

                foreach($daterangeovertime as $dateovertime){
                    array_push($daysovertimelist,$dateovertime->format("Y-m-d"));
                }
                
                foreach($daysovertimelist as $dayovertime){
                    if(in_array($dayovertime,$daysperiodholiday)){
                        
                        $holidayovertimepay+=(($hourlyrate* $getholiday->workon)/100)*$overtime->numofhours;
                        
                    }else{
                        $overtimesalary+=$hourlyrate*$overtime->numofhours;
                    }
                }
            }
            array_push($overtimedetails,(object)array(
                'holidayovertimepay'    => number_format((float)$holidayovertimepay, 2, '.', ''),
                'overtimesalary'        => number_format((float)$overtimesalary, 2, '.', ''),
                'dailyovertimehours'    => $dailyovertimehours
            ));
        }
        
        $attendanceearnings = ($perdaysalary*count($attendancepresent));
        $attendancedeductions = ($perdaysalary*count($attendanceabsent));
        // return $attendancedeductions;
        $attendancedetails = (object)array(

            'attendanceearnings'   => number_format((float)$attendanceearnings, 2, '.', ''),
            'attendancedeductions'   => number_format((float)$attendancedeductions, 2, '.', ''),
            'latedeductionamount'   => number_format((float)$latedeductionamount, 2, '.', ''),
            'lateminutes'   => $lateminutes,
            'presentminutes'   => $presentminutes,
            'undertimeminutes'   => $undertimeminutes,
            'holidaypay'   => number_format((float)$holidaypay, 2, '.', ''),
            'dailynumofhours'   => $dailynumofhours,
            'attendancepresent'   => $attendancepresent,
            'attendanceabsent'   => $attendanceabsent,
            'minuteslate'   => $minuteslate,
            'minuteslatehalfday'   => $minuteslatehalfday,
            'lateamin'   => $lateamin,
            'undertimeamout'   => $undertimeamout,
            'latepmin'   => $latepmin,
            'undertimepmout'   => $undertimepmout
        );
        $basicsalaryinfo->payrollbasic = $basicsalary;
        return (object)array(
            'payrollinfo'           => $payrolldates,
            'picurl'                => $picurl,
            'personalinfo'          => $personalinfo,
            'basicsalaryinfo'       => $basicsalaryinfo,
            'attendancedetails'     => $attendancedetails,
            'payrollworkingdays'    => $payrollworkingdays,
            'perdaysalary'          => $perdaysalary,
            'leavedetails'          => $leavedetails,
            'overtimedetails'       => $overtimedetails,
            'permonthhalfsalary'    => $permonthhalfsalary
        );
    }
}
