

@extends('hr.layouts.app')
@section('content')
<!-- DataTables -->
<link rel="stylesheet" href="{{asset('plugins/datatables-bs4/css/dataTables.bootstrap4.css')}}">
<link rel="stylesheet" href="{{asset('plugins/fullcalendar/main.min.css')}}">
<link rel="stylesheet" href="{{asset('plugins/fullcalendar-daygrid/main.min.css')}}">
<link rel="stylesheet" href="{{asset('plugins/fullcalendar-timegrid/main.min.css')}}">
<link rel="stylesheet" href="{{asset('plugins/fullcalendar-bootstrap/main.min.css')}}">
<link rel="stylesheet" href="{{asset('plugins/fullcalendar-interaction/main.min.css')}}">
<div class="row">
  <div class="col-md-4">
		<div class="card flex-fill dash-statistics" style="height: 300px;">
			<div class="card-header bg-success">
				<h3 class="card-title"><i style="color: #ffc107" class="fas fa-bars"></i> <b>Attendance</b></h3>
			</div>
			<div class="card-body"  style="overflow: scroll;">
                <table class="table responsive" >
                          <thead>
                              <tr>
                                  <th>Name</th>
                                  <th>Status</th>	
                              </tr>
                          </thead>
                          <tbody>
                              @foreach($todaysattendance as $todaysattendanceemployee)
                              <tr>
                              <td>{{$todaysattendanceemployee->name}}</td>
                              <td>
                                  @if($todaysattendanceemployee->status == '0')
                                    <span class="right badge badge-danger">Absent</span>
                                  @else
                                    <span class="right badge badge-success">Present</span>
                                  @endif
                                </td>
                              </tr>
                              @endforeach
                          </tbody>
                </table>
			</div>
		</div>
	</div>
  	<div class="col-md-8">
		<div class="card flex-fill dash-statistics" style="height: 300px;">
			<div class="card-header bg-warning">
				<h3 class="card-title"><i style="color: #ffc107" class="fas fa-bars"></i> <b>Employees</b> ( {{count($employees)}} )</h3>
			</div>
			<div class="card-body" style="overflow: scroll;">
              <table class="table responsive" >
						<thead>
							<tr>
								<th>Name</th>
								<th>Department</th>
								<th>Designation</th>
								<th>Contact #</th>	
							</tr>
						</thead>
						<tbody>
							@foreach($employees as $employee)
							<tr>
							<td>{{$employee->lastname}}, {{$employee->firstname}} </td>
							<td>{{$employee->department}}</td>
							<td>{{$employee->designation}}</td>
							<td>{{$employee->contactnum}}</td>
							</tr>
							@endforeach
						</tbody>
              </table>
			</div>
		</div>
	</div>
</div>
<div class="row">
	<div class="col-md-6 tschoolcalendar">
        <div class="card card-primary tschoolcalendar" style="height: 300px;">
            <div class="card-header bg-info">
                <h3 class="card-title">School Calendar</h3>
            </div>
            <div class="card-body p-1" style="overflow: scroll;">
                <div class="calendarHolder">
                    <div id='newcal'></div>
                </div>
            </div>
        </div>
    </div>
	<div class="col-md-6 ">
        <div class="card card-primary" style="height: 300px;">
            <div class="card-header bg-danger">
                <h3 class="card-title">Leaves</h3>
            </div>
            <div class="card-body p-1" style="overflow: scroll;">
              <table class="table responsive" >
						<thead>
							<tr>
								<th>Name</th>
								<th>Start date</th>
								<th>End date</th>
								<th>Status</th>
							</tr>
						</thead>
						<tbody>
                            @foreach($leaveapplications as $leaveapplication)
                                <tr>
                                    <td>
                                        {{$leaveapplication->lastname}}
                                    </td>
                                    <td>
                                        {{$leaveapplication->datefrom}}
                                    </td>
                                    <td>
                                        {{$leaveapplication->dateto}}
                                    </td>
                                    <td>
                                        @if($leaveapplication->status == 'approved')
                                            <span class="right badge badge-success">Approved</span>
                                        @elseif($leaveapplication->status == 'pending')
                                            <span class="right badge badge-success">Pending</span>
                                        @elseif($leaveapplication->status == 'disapproved')
                                            <span class="right badge badge-secondary">Disapproved</span>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
						</tbody>
              </table>
            </div>
        </div>
    </div>
</div>
<div class="row">
	<div class="col-md-4">
        <div class="card card-primary" style="height: 300px;">
            <div class="card-header bg-secondary">
                <h3 class="card-title">SETUP/CONFIGURATION</h3>
            </div>
            <div class="card-body p-1" style="overflow: scroll;">
					<a href="/departments/dashboard" class="btn btn-light btn-block">Departments</a>
					<a href="/designations/dashboard" class="btn btn-light btn-block">Designations</a>
					<a href="/holidays" class="btn btn-light btn-block">Holidays</a>
					<a href="/standarddeductions/{{Crypt::encrypt('dashboard')}}" class="btn btn-light btn-block">Deductions</a>
					<a href="/standardallowances/{{Crypt::encrypt('dashboard')}}" class="btn btn-light btn-block">Allowances</a>
					<a href="/leavesettings" class="btn btn-light btn-block">Leaves</a>
            </div>
        </div>
	</div>
</div>
<!-- <div class="col-lg-4">
    <div class="col-md-12">
        <div class="card dash-widget" style="height: 100px;">
            <div class="card-body">
                <span class="dash-widget-icon  p-3"><i class="fa fa-user"></i></span>
                <div class="dash-widget-info">
                    <h3></h3>
                    <span>Employees</span>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-12">
        <div class="card flex-fill dash-statistics" style="height: 200px;">
          <div class="card-header bg-success">
            <h3 class="card-title"><i style="color: #ffc107" class="fas fa-bars"></i> <b>Statistics</b></h3>
          </div>
					<div class="card-body">
							<div class="stats-list">
									<div class="stats-info">
											<p>Today Leave <strong>4 <small>/ 65</small></strong></p>
											<div class="progress">
													<div class="progress-bar bg-primary" role="progressbar" style="width: 31%" aria-valuenow="31" aria-valuemin="0" aria-valuemax="100"></div>
											</div>
									</div>
							</div>
					</div>
			</div>
    </div> 
</div>   
<div class="col-lg-4">
<div class="col-md-12">
        <div class="card flex-fill" style="height: 315px;">
            <div class="card-body" style="overflow-y: scroll">
                <h4 class="card-title">Today Absent <span class="badge bg-inverse-danger ml-2">5</span></h4>
                <div class="leave-info-box">
                    <div class="media align-items-center">
                        <a href="profile.html" class="avatar"><img alt="" src="assets/img/user.jpg"></a>
                        <div class="media-body">
                            <div class="text-sm my-0">Martin Lewis</div>
                        </div>
                    </div>
                    <div class="row align-items-center mt-3">
                        <div class="col-6">
                            <h6 class="mb-0">4 Sep 2019</h6>
                            <span class="text-sm text-muted">Leave Date</span>
                        </div>
                        <div class="col-6 text-right">
                            <span class="badge bg-inverse-danger">Pending</span>
                        </div>
                    </div>
                </div>
                <div class="leave-info-box">
                    <div class="media align-items-center">
                        <a href="profile.html" class="avatar"><img alt="" src="assets/img/user.jpg"></a>
                        <div class="media-body">
                            <div class="text-sm my-0">Martin Lewis</div>
                        </div>
                    </div>
                    <div class="row align-items-center mt-3">
                        <div class="col-6">
                            <h6 class="mb-0">4 Sep 2019</h6>
                            <span class="text-sm text-muted">Leave Date</span>
                        </div>
                        <div class="col-6 text-right">
                            <span class="badge bg-inverse-success">Approved</span>
                        </div>
                    </div>
                    <div class="row align-items-center mt-3">
                        <div class="col-6">
                            <h6 class="mb-0">4 Sep 2019</h6>
                            <span class="text-sm text-muted">Leave Date</span>
                        </div>
                        <div class="col-6 text-right">
                            <span class="badge bg-inverse-success">Approved</span>
                        </div>
                    </div>
                    <div class="row align-items-center mt-3">
                        <div class="col-6">
                            <h6 class="mb-0">4 Sep 2019</h6>
                            <span class="text-sm text-muted">Leave Date</span>
                        </div>
                        <div class="col-6 text-right">
                            <span class="badge bg-inverse-success">Approved</span>
                        </div>
                    </div>
                    <div class="row align-items-center mt-3">
                        <div class="col-6">
                            <h6 class="mb-0">4 Sep 2019</h6>
                            <span class="text-sm text-muted">Leave Date</span>
                        </div>
                        <div class="col-6 text-right">
                            <span class="badge bg-inverse-success">Approved</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="col-lg-4">
<div class="col-md-12">
        <div class="card flex-fill" style="height: 315px;">
            <div class="card-header bg-primary">
              <h3 class="card-title"><i style="color: #ffc107" class="fas fa-users"></i> <b>Employees</b></h3>
            </div>
            <div class="card-body pt-0" style="overflow-y: scroll">
              <table class="table responsive">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Department</th>
                  </tr>
                </thead>
                <tbody>
                    @foreach($employees as $employee)
                  <tr>
                    <td>{{$employee->lastname}}, {{$employee->firstname}} </td>
                    <td>{{$employee->department}}</td>
                  </tr>
                  @endforeach
                </tbody>
              </table>
            </div>
        </div>
    </div>
</div>
</div>
<div class="row">
<div class="col-lg-4">
<div class="col-md-12">
        <div class="card flex-fill" style="height: 220px;">
            <div class="card-header bg-danger">
              <h3 class="card-title"><i style="color: #ffc107" class="fas fa-circle"></i> <b>Departments</b></h3>
            </div>
            <div class="card-body pt-0" style="overflow-y: scroll">
              <table class="table responsive">
                <thead>
                  <tr>
                    <th>Departments</th>
                  </tr>
                </thead>
                <tbody>
                    @foreach($departments as $department)
                  <tr>
                    <td>{{$department->department}}</td>
                  </tr>
                  @endforeach
                </tbody>
              </table>
            </div>
        </div>
    </div>
</div>
<div class="col-lg-4">
<div class="col-md-12">
        <div class="card flex-fill" style="height: 220px;">
            <div class="card-header bg-info">
              <h3 class="card-title"><i style="color: #ffc107" class="fas fa-circle"></i> <b>Designations</b></h3>
            </div>
            <div class="card-body pt-0" style="overflow-y: scroll">
              <table class="table responsive">
                <thead>
                  <tr>
                    <th>Designation</th>
                  </tr>
                </thead>
                <tbody>
                    @foreach($designations as $designation)
                  <tr>
                    <td>{{$designation->designation}}</td>
                  </tr>
                  @endforeach
                </tbody>
              </table>
            </div>
        </div>
    </div>
</div>
<div class="col-lg-4">
<div class="col-md-12">
        <div class="card flex-fill" style="height: 220px;">
            <div class="card-header bg-gray">
              <h3 class="card-title"><i style="color: #ffc107" class="fas fa-circle"></i> <b>Holidays</b></h3>
            </div>
            <div class="card-body pt-0" style="overflow-y: scroll">
              <table class="table responsive">
                <thead>
                  <tr>
                    <th>Holiday</th>
                  </tr>
                </thead>
                <tbody>
                    @foreach($holidays as $holiday)
                  <tr>
                    <td>{{$holiday->description}}</td>
                  </tr>
                  @endforeach
                </tbody>
              </table>
            </div>
        </div>
    </div>
</div>
</div>
  <div class="row">
    
    
</div> -->
 
<script src="{{asset('plugins/jquery/jquery.min.js')}}"></script>
<script src="{{asset('plugins/moment/moment.min.js')}}"></script>
<script src="{{asset('plugins/fullcalendar/main.min.js')}}"></script>
<script src="{{asset('plugins/fullcalendar-daygrid/main.min.js')}}"></script>
<script src="{{asset('plugins/fullcalendar-timegrid/main.min.js')}}"></script>
<script src="{{asset('plugins/fullcalendar-interaction/main.min.js')}}"></script>
<script src="{{asset('plugins/fullcalendar-bootstrap/main.min.js')}}"></script>
<script src="{{asset('plugins/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
<script src="{{asset('plugins/datatables/jquery.dataTables.js')}}"></script>
<script src="{{asset('plugins/datatables-bs4/js/dataTables.bootstrap4.js')}}"></script>
<script>
    $(function () {
		// var table =  $("#example1").DataTable({
		// 	pageLength : 10,
		// 	lengthMenu: [[5, 10, 20, -1], [5, 10, 20, 'Show All']],
		// 	// scrollY:        "500px",
		// 	// scrollX:        true,
		// 	scrollCollapse: true,
		// 	paging:         false,
		// 	fixedColumns:   true,
		// 	bFilter: false
      // });
      /* ChartJS
       * -------
       * Here we will create a few charts using ChartJS
       */
  
      //--------------
      //- AREA CHART -
      //--------------
  
      // Get context with jQuery - using jQuery's .get() method.
   
  
    
      //-------------
      //- DONUT CHART -
      //-------------
     
  
      //-------------
      //- BAR CHART -
      //-------------
        var barChartCanvas = $('#barChart').get(0).getContext('2d')

        var areaChartData = {
            labels  : ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
            datasets: [
                {
                label               : 'Total Income',
                backgroundColor     : 'rgba(60,141,188,0.9)',
                borderColor         : 'rgba(60,141,188,0.8)',
                pointRadius          : false,
                pointColor          : '#3b8bba',
                pointStrokeColor    : 'rgba(60,141,188,1)',
                pointHighlightFill  : '#fff',
                pointHighlightStroke: 'rgba(60,141,188,1)',
                data                : [28, 48, 40, 19, 86, 27, 90]
                },
                {
                label               : 'Total Outcome',
                backgroundColor     : 'rgba(210, 214, 222, 1)',
                borderColor         : 'rgba(210, 214, 222, 1)',
                pointRadius         : false,
                pointColor          : 'rgba(210, 214, 222, 1)',
                pointStrokeColor    : '#c1c7d1',
                pointHighlightFill  : '#fff',
                pointHighlightStroke: 'rgba(220,220,220,1)',
                data                : [65, 59, 80, 81, 56, 55, 40]
                },
            ]
            }

        var barChartData = jQuery.extend(true, {}, areaChartData)
        var temp0 = areaChartData.datasets[0]
        var temp1 = areaChartData.datasets[1]
        barChartData.datasets[0] = temp1
        barChartData.datasets[1] = temp0

        var barChartOptions = {
        responsive              : true,
        maintainAspectRatio     : false,
        datasetFill             : false
        }

        var barChart = new Chart(barChartCanvas, {
        type: 'bar', 
        data: barChartData,
        options: barChartOptions
        })

  
      //---------------------
      //- STACKED BAR CHART -
      //---------------------
      
    });
	 
    $( document ).ready(function() {

		if($(window).width()<500){

			$('.fc-prev-button').addClass('btn-sm')
			$('.fc-next-button').addClass('btn-sm')
			$('.fc-today-button').addClass('btn-sm')
			$('.fc-left').css('font-size','13px')
			$('.fc-toolbar').css('margin','0')
			$('.fc-toolbar').css('padding-top','0')

			var header = {
				left:   'title',
				center: '',
				right:  'today prev,next'
			}
			console.log(header)


			}
			else{
			var header = {
				left  : 'prev,next today',
				center: 'title',
				right : 'dayGridMonth,timeGridWeek,timeGridDay'
			}
			console.log(header)
			}

			var date = new Date()
			var d    = date.getDate(),
			m    = date.getMonth(),
			y    = date.getFullYear()

			var schedule = [];

			@foreach($schoolcalendar as $item)

				@if($item->noclass == 1)
					var backgroundcolor = '#dc3545';
				@else
					var backgroundcolor = '#00a65a';
				@endif

				schedule.push({
					title          : '{{$item->description}}',
					start          : '{{$item->datefrom}}',
					end            : '{{$item->dateto}}',
					backgroundColor: backgroundcolor,
					borderColor    : backgroundcolor,
					allDay         : true,
					id: '{{$item->id}}'
				})

			@endforeach


			var Calendar = FullCalendar.Calendar;

			console.log(schedule);

			var calendarEl = document.getElementById('newcal');

			var calendar = new Calendar(calendarEl, {
				plugins: [ 'bootstrap', 'interaction', 'dayGrid', 'timeGrid' ],
				header    : header,
				events    : schedule,
				height : 'auto',
				themeSystem: 'bootstrap',
				eventStartEditable: false
			});

			calendar.render();
			});
			$(function () {
			$("#example1").DataTable({
				pageLength : 10,
				lengthMenu: [[5, 10, 20, -1], [5, 10, 20, 'Show All']]
			});
			});
			$(".notification").click(function () {
			var notification_id = $(this).attr("name");
			var parent_class = $(this).parent().parent();
			parent_class.css('border','solid','#218838');
			$.ajax({
				url: '/teacherNotification/'+notification_id,
				type:"GET",
				dataType:"json",
				data:{
					getStudents:'getGradeLevel'
				},
				success:function(data) {
					$(".badge-notify").text(data[0]);
					if(data[0]==0){
							$(".badge-notify").hide();
							$(".card"+data[2]).css('color','#218838');
					}
					$.each(data[1], function(key, value){
							if(value.status){
								$(".notification").click(function () {
									$(".notif"+value.id).css('color','black');
									$(".card"+data[2]).css('color','white');
									// #218838
								});
							}
					});
				}
			});
			});
  </script>
@endsection