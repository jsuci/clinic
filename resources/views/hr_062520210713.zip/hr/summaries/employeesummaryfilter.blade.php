
              <div class="col-md-12">
                  <button type="button" class="btn btn-info btn-sm">Employees ({{count($employees)}})</button>
                  <button type="button" class="btn btn-default btn-sm exportsummary" exporttype="pdf"><i class="fa fa-download"></i> PDF</button>
              </div>
              <div class="col-md-12">
                <table id="example1" class="table table-bordered table-hover">
                  <thead>
                      <tr>
                          <th>#</th>
                          <th class="no-sort">ID</th>
                          <th>Name</th>
                          <th>Gender</th>
                          <th>Department</th>
                          <th>Designation</th>
                          <th>Employment Status</th>
                          
                      </tr>
                  </thead>
                  <tbody id="resultscontainer" class="text-uppercase">
                      @if(count($employees)>0)
                          @foreach($employees as $employee)
                              <tr>
                                  <td></td>
                                  <td class="text-center">{{$employee->teacherid}}</td>
                                  <td>{{$employee->lastname}}, {{$employee->firstname}} {{$employee->middlename}} {{$employee->suffix}}</td>
                                  <td class="text-center">{{$employee->gender}}</td>
                                  <td class="text-center">{{$employee->department}}</td>
                                  <td class="text-center">{{$employee->designation}}</td>
                                  <td class="text-center">
                                      
                                      {{-- // 1 = casual; 2 = prov; 3 = regu;4 = parttime; 5 = substitute --}}
                                      @if($employee->employmentstatus == 1)
                                      CASUAL
                                      @elseif($employee->employmentstatus == 2)
                                      PROVISIONARY
                                      @elseif($employee->employmentstatus == 3)
                                      REGULAR
                                      @elseif($employee->employmentstatus == 4)
                                      PART-TIME
                                      @elseif($employee->employmentstatus == 5)
                                      SUBSTITUTE
                                      @endif
                                  </td>
                              </tr>
                          @endforeach
                      @endif
                  </tbody>
                </table>
              </div>
              <script>
                  $('.exportsummary').on('click', function(){
                        var exporttype          = $(this).attr('exporttype');
                        var selecteddepartment  = $('#selecteddepartment').val();
                        var selecteddesignation = $('#selecteddesignation').val();
                        var selectedstatus      = $('#selectedstatus').val();
                        var selectedgender      = $('#selectedgender').val();
                        var paramet = {
                                exporttype          :   exporttype,
                                selecteddepartment  :   selecteddepartment,
                                selecteddesignation :   selecteddesignation,
                                selectedstatus      :   selectedstatus,
                                selectedgender      :   selectedgender
                        }
                        window.open("/hrreports/summaryofemployees/export?"+$.param(paramet));
                  })
              </script>