@extends('finance.layouts.app')

@section('content')
<!-- DataTables -->
<link rel="stylesheet" href="{{asset('plugins/datatables-bs4/css/dataTables.bootstrap4.css')}}">
<!-- daterange picker -->
<link rel="stylesheet" href="{{asset('plugins/daterangepicker/daterangepicker.css')}}">
<style>
    table{
        font-size: 12px;
    }
</style>
<br>
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Statement of Account</h1>
                <!-- <h4 class="text-warning" style="text-shadow: 1px 1px 1px #000000">
                    <i class="fa fa-file-invoice nav-icon"></i> 
                    <b>STUDENT LEDGER</b></h4> -->
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="/">Home</a></li>
                    <li class="breadcrumb-item active">Statement of Account</li>
                </ol>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>
<div class="row m-2">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3">
                        <div class="input-group input-group-sm ">
                            <div class="input-group-prepend">
                                <span class="input-group-text form-control form-control-sm">
                                    Schoolyear
                                </span>
                            </div>
                            <select class="form-control form-control-sm" id="selectedschoolyear">
                                @foreach($schoolyears as $schoolyear)
                                    <option value="{{$schoolyear->id}}" {{$schoolyear->isactive == 1 ? 'selected' : ''}}>{{$schoolyear->sydesc}}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="input-group input-group-sm ">
                            <div class="input-group-prepend">
                                <span class="input-group-text form-control form-control-sm">
                                    Semester
                                </span>
                            </div>
                            <select class="form-control form-control-sm" id="selectedsemester">
                                @foreach($semesters as $semester)
                                    <option value="{{$semester->id}}" {{$semester->isactive == 1 ? 'selected' : ''}}>{{$semester->semester}}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="input-group input-group-sm ">
                            <div class="input-group-prepend">
                                <span class="input-group-text form-control form-control-sm">
                                    Month Setup
                                </span>
                            </div>
                            <select class="form-control form-control-sm" id="selectedmonth">
                                <option value="" >All</option>
                                @foreach($monthsetups as $monthsetup)
                                    <option value="{{$monthsetup->description}}">{{$monthsetup->description}}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-md-2">
                        @if($status == 0)
                            <button type="button" id="viewnote" class="btn btn-sm btn-default float-right btn-block" data-toggle="tooltip" data-placement="left" title="No notes available"> <span style="height: 10px;width: 10px;background-color: red;border-radius: 50%;display: inline-block;"></span> Note (Inactive)</button>
                        @else
                            <button type="button" id="viewnote" class="btn btn-sm btn-default float-right btn-block" data-toggle="tooltip" data-placement="left" title="Active"> <span style="height: 10px;width: 10px;background-color: green;border-radius: 50%;display: inline-block;"></span> Note (Active)</button>
                        @endif
                    </div>
                </div>
                <div class="row mt-2">
                    <div class="col-md-12">
                        <button class="btn btn-sm btn-warning" ><strong>{{count($students)}}</strong> Students</button>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <div class="row">
                    <div class="col-12" id="selectedoptionscontainer"></div>
                </div>
                <div class="row">
                    <div class="col-12" id="resultscontainer">
                        <table id="example1" class="table">
                            <thead>
                                <tr>
                                    <th style="width: 5%;">#</th>
                                    <th>Student</th>
                                </tr>
                            </thead>
                            <tbody>
                                @if(count($students)>0)
                                    @foreach($students as $student)
                                        <tr>
                                            <td></td>
                                            <td class="p-0">
                                                <div class="card collapsed-card p-0 mb-0" style="border: none !important; background-color: unset !important;box-shadow: none !important;">
                                                <div class="card-header">
                                                  <h3 class="card-title">{{$student->lastname}}, {{$student->firstname}} {{$student->middlename}} {{$student->suffix}}</h3>
                                  
                                                  <div class="card-tools">
                                                    <button type="button" class="btn btn-tool viewdetails" data-card-widget="collapse" id="{{$student->id}}">View
                                                    </button>
                                                    <button type="button" class="btn btn-tool printstatementofacct"  exporttype="excel" studid="{{$student->id}}">Excel
                                                    </button>
                                                    <button type="button" class="btn btn-tool printstatementofacct"  exporttype="pdf" studid="{{$student->id}}">PDF
                                                    </button>
                                                  </div>
                                                  <!-- /.card-tools -->
                                                </div>
                                                <!-- /.card-header -->
                                                <div class="card-body" style="display: none;" id="stud{{$student->id}}">
                                                </div>
                                                <!-- /.card-body -->
                                              </div>
                                            </td>
                                        </tr>
                                    @endforeach
                                @endif
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="viewnotemodal" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title"></h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">
            {{-- <div class="col-sm-12">
                <div class="alert alert-warning alert-dismissible">
                    <h5><i class="icon fas fa-exclamation-triangle"></i> Alert!</h5>
                    Currently working on this feature.
                  </div>
            </div> --}}
          <p><em>This note will be added at the bottom of the report to be followed by the signatories.</em></p>
          <div class="row" id="notecontainer"></div>
        </div>
        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" id="submitnotes">Save changes</button>
        </div>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- jQuery -->
<script src="{{asset('plugins/jquery/jquery.min.js')}}"></script>
<!-- Bootstrap 4 -->
<script src="{{asset('plugins/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
<!-- DataTables -->
<script src="{{asset('plugins/datatables/jquery.dataTables.js')}}"></script>
<script src="{{asset('plugins/datatables-bs4/js/dataTables.bootstrap4.js')}}"></script>
<!-- InputMask -->
<script src="{{asset('plugins/moment/moment.min.js')}}"></script>
<script src="{{asset('plugins/inputmask/min/jquery.inputmask.bundle.min.js')}}"></script>
<!-- date-range-picker -->
<script src="{{asset('plugins/daterangepicker/daterangepicker.js')}}"></script>
<script>
    $(document).ready(function(){
        $('[data-toggle="tooltip"]').tooltip()
        $('#selecteddaterange').daterangepicker({
            autoUpdateInput: false,
            locale: {
                cancelLabel: 'Clear',
                format: 'YYYY-MM-DD'
            }
        })
        var tablecontainer = $("#example1").DataTable({
            // pageLength : 10,
            // lengthMenu: [[5, 10, 20, -1], [5, 10, 20, 'Show All']]
            aLengthMenu: [
                [25, 50, 100, 200, -1],
                [25, 50, 100, 200, "All"]
            ],
            iDisplayLength: -1,
            "order": [[ 1, 'asc' ]],
            paging: false,
            "bInfo": false,
        });
        tablecontainer.on( 'order.dt search.dt', function () {
            tablecontainer.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
                cell.innerHTML = i+1;
            } );
        } ).draw();
        $(document).on('click','.viewdetails', function(){
            if($(this).closest('.card').hasClass('collapsed-card'))
            {
                var selectedschoolyear = $('#selectedschoolyear').val();
                var selectedsemester = $('#selectedsemester').val();
                var selectedmonth = $('#selectedmonth').val();
                var studid = $(this).attr('id');
                $.ajax({
                    url: '{{ route('statementofacctgetaccount')}}',
                    type: 'GET',
                    data: {
                        studid: studid,
                        selectedschoolyear: selectedschoolyear,
                        selectedsemester: selectedsemester,
                        selectedmonth: selectedmonth
                    },
                    success:function(data){
                        console.log(data)
                        $('#stud'+studid).empty();
                        $('#stud'+studid).append(data);
                    }
                })
            }else{
                $('#stud'+$(this).attr('id')).empty()
            }
        })
        $(document).on('click','.printstatementofacct', function(){
                var selectedschoolyear = $('#selectedschoolyear').val();
                var selectedsemester = $('#selectedsemester').val();
                var selectedmonth = $('#selectedmonth').val();
                var studid = $(this).attr('studid');
                var exporttype = $(this).attr('exporttype')
                var paramet = {
                    selectedschoolyear  : selectedschoolyear,
                    selectedsemester    : selectedsemester, 
                    selectedmonth       : selectedmonth, 
                    studid              : studid
                }
				window.open("/statementofacctexport?exporttype="+exporttype+"&"+$.param(paramet));
        })
        $(document).on('click','#viewnote', function(){
            $.ajax({
                url: '/statementofacctgetnote',
                type: 'GET',
                data: {
                    type: 1
                },
                success:function(data)
                {
                    $('#notecontainer').empty();
                    $('#notecontainer').append(data)
                }
            })
            $('#viewnotemodal').addClass('show')
            $('#viewnotemodal').css({'padding-right':'10px','display':'block'})
            $('#viewnotemodal').modal('show');
            $('body').addClass('modal-open')
            $('.modal-backdrop').addClass('show')
            $('.modal-backdrop').show()
        })
        $(document).on('click','#submitnotes', function()
        {
            
            var submit = 4;
            var notes = [];
            $('textarea').each(function(){
                if($(this).val().replace(/^\s+|\s+$/g, "").length == 0)
                {
                    submit -= 1;
                }else{
                    notes.push(
                        {
                            'id':$(this).attr('id'),
                            'content':$(this).val()
                        }
                    )
                }
            })
            if(submit>0)
            {
                if($('input[name="notestatus"]').length == 0)
                {
                    var notestatus = 1;
                }else{
                    var notestatus = $('input[name="notestatus"]:checked').val();
                }
                $.ajax({
                    url: '/statementofacctsubmitnotes',
                    type: 'GET',
                    dataType: 'json',
                    data: {
                        notes: JSON.stringify(notes),
                        notestatus : notestatus
                    },
                    success:function(data)
                    {
                        if(data == '1')
                        {
                            
                            $('#viewnotemodal').removeClass('show')
                            $('#viewnotemodal').removeAttr('style')
                            $('#viewnotemodal').css('display','none;')
                            $('body').removeClass('modal-open')
                            $('.modal-backdrop').removeClass('show')
                            $('.modal-backdrop').hide()
                        }
                    }
                })
            }

        })
    })

</script>
@endsection