
<div class="col-md-12">
    <div class="callout callout-info">
        <div class="row">
            <div class="col-md-6"><h4>Details</h4></div>
            <div class="col-md-6 text-right">
                <button type="button" class="btn btn-default btn-sm" id="btn-details-save"><i class="fa fa-share"></i> Save Changes</button>
            </div>
        </div>
        <div class="row">
            <div class="col-md-3">
                <label>Parent or Guardian</label>
            </div>
            <div class="col-md-3">
                <input type="text" class="form-control form-control-sm" value="{{$details->parentguardian}}" id="input-parentguardian" style="border: none; border-bottom: 1px solid #ddd;"/>
            </div>
            <div class="col-md-3">
                <label>Address</label>
            </div>
            <div class="col-md-3">
                <input type="text" class="form-control form-control-sm" value="{{$details->address}}" id="input-address" style="border: none; border-bottom: 1px solid #ddd;"/>
            </div>
        </div>
        <div class="row">
            <div class="col-md-3">
                <label>Elementary Course</label>
            </div>
            <div class="col-md-3">
                <input type="text" class="form-control form-control-sm" value="{{$details->elemcourse}}" id="input-elemcourse" style="border: none; border-bottom: 1px solid #ddd;"/>
            </div>
            <div class="col-md-3">
                <label>Date Completed</label>
            </div>
            <div class="col-md-3">
                <input type="date" class="form-control form-control-sm" value="{{$details->elemdatecomp}}" id="input-elemdatecomp" style="border: none; border-bottom: 1px solid #ddd;"/>
            </div>
        </div>
        <div class="row">
            <div class="col-md-3">
                <label>Secondary Course</label>
            </div>
            <div class="col-md-3">
                <input type="text" class="form-control form-control-sm" value="{{$details->secondcourse}}" id="input-secondcourse" style="border: none; border-bottom: 1px solid #ddd;"/>
            </div>
            <div class="col-md-3">
                <label>Date Completed</label>
            </div>
            <div class="col-md-3">
                <input type="date" class="form-control form-control-sm" value="{{$details->seconddatecomp}}" id="input-seconddatecomp" style="border: none; border-bottom: 1px solid #ddd;"/>
            </div>
        </div>
        <div class="row">
            <div class="col-md-3">
                <label>Admission Date</label>
            </div>
            <div class="col-md-3">
                <input type="date" class="form-control form-control-sm" value="{{$details->admissiondate}}" id="input-admissiondate" style="border: none; border-bottom: 1px solid #ddd;"/>
            </div>
            <div class="col-md-3">
                <label>Degree</label>
            </div>
            <div class="col-md-3">
                <input type="text" class="form-control form-control-sm" value="{{$details->degree}}" id="input-degree" style="border: none; border-bottom: 1px solid #ddd;"/>
            </div>
        </div>
        <div class="row">
            <div class="col-md-3">
                <label>Basis of Admission</label>
            </div>
            <div class="col-md-3">
                <input type="text" class="form-control form-control-sm" value="{{$details->basisofadmission}}" id="input-basisofadmission" style="border: none; border-bottom: 1px solid #ddd;"/>
            </div>
            <div class="col-md-3">
                <label>Major</label>
            </div>
            <div class="col-md-3">
                <input type="text" class="form-control form-control-sm" value="{{$details->major}}" id="input-major" style="border: none; border-bottom: 1px solid #ddd;"/>
            </div>
        </div>
        <div class="row">
            <div class="col-md-3">
                <label>Special Order</label>
            </div>
            <div class="col-md-3">
                <input type="text" class="form-control form-control-sm" value="{{$details->specialorder}}" id="input-specialorder" style="border: none; border-bottom: 1px solid #ddd;"/>
            </div>
            <div class="col-md-3">
                <label>Graduation Date</label>
            </div>
            <div class="col-md-3">
                <input type="date" class="form-control form-control-sm" value="{{$details->graduationdate}}" id="input-graduationdate" style="border: none; border-bottom: 1px solid #ddd;"/>
            </div>
        </div>
    </div>
</div>
<div class="col-md-12 text-left mb-2">
    <button type="button" class="btn btn-info btn-sm" id="btn-addnewrecord" data-toggle="modal" data-target="#modal-newrecord"><i class="fa fa-plus"></i> Add new record</button>
    <button type="button" class="btn btn-secondary btn-sm" id="btn-exporttopdf"><i class="fa fa-file-pdf"></i> PDF</button>
</div>
@if(count($records)>0)
    @foreach($records as $record)
        <div class="col-md-12 @if($record->type == 'auto') auto-disabled @endif" >
            <div class="card">
                <div class="card-header">
                    <div class="row mb-2">
                        <div class="col-md-4">
                            <h6><strong>{{$record->sydesc}} / {{$record->semid}}@if($record->semid == 1)st @else nd @endif Semester </strong></h6>
                        </div>
                        <div class="col-md-8">
                            <h6><strong>{{$record->coursename}}</strong></h6>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 mb-2">
                            <div class="row">
                                <div class="col-2">
                                    <label>School ID</label>
                                    <input type="text" class="form-control form-control-sm" value="{{$record->schoolid}}" style="border: none;" readonly/>
                                </div>
                                <div class="col-4">
                                    <label>School Name</label>
                                    <input type="text" class="form-control form-control-sm" value="{{$record->schoolname}}" style="border: none;" readonly/>
                                </div>
                                <div class="col-6">
                                    <label>School Address</label>
                                    <input type="text" class="form-control form-control-sm" value="{{$record->schooladdress}}" style="border: none;" readonly/>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 text-right mb-2">
                            <button type="button" class="btn btn-sm btn-default btn-adddata text-success" data-torid="{{$record->id}}"><i class="fa fa-plus"></i> Add Data</button>
                            <button type="button" class="btn btn-sm btn-default btn-editrecord" data-torid="{{$record->id}}"><i class="fa fa-edit text-warning"></i> Edit Record Info</button>
                            <button type="button" class="btn btn-default btn-sm text-danger btn-deleterecord" data-torid="{{$record->id}}"><i class="fa fa-trash"></i> Delete this records</button>
                        </div>
                    </div>
                </div>
                @if(count($record->subjdata)>0)
                    <div class="card-body p-0">
                        <div class="row mb-2">
                            <div class="col-md-12">
                                <table class="table" style="font-size: 14px;">
                                    <thead class="text-center">
                                        <tr>
                                            <th style="width: 15%;">Subject Code</th>
                                            <th style="width: 10%;">Units</th>
                                            <th>Description</th>
                                            <th style="width: 11%;">Grade</th>
                                            <th style="width: 11%;">Credits</th>
                                            <th style="width: 15%;"></th>
                                        </tr>
                                    </thead>
                                    <tbody id="">
                                        @foreach($record->subjdata as $subj)
                                            <tr>
                                                <td class="p-0"><input type="text" class="form-control form-control-sm input-subjcode" placeholder="Code" value="{{$subj->subjcode}}" disabled/></td>
                                                <td class="p-0"><input type="number" class="form-control form-control-sm input-subjunit" placeholder="Units" value="{{$subj->subjunit}}" disabled/></td>
                                                <td class="p-0"><input type="text" class="form-control form-control-sm input-subjdesc" placeholder="Description" value="{{$subj->subjdesc}}" disabled/></td>
                                                <td class="p-0"><input type="number" class="form-control form-control-sm input-subjgrade" placeholder="Grade" value="{{$subj->subjgrade}}" disabled/></td>
                                                <td class="p-0"><input type="number" class="form-control form-control-sm input-subjcredit" placeholder="Credit" value="{{$subj->subjcredit}}" disabled/></td>
                                                <td class="p-0 text-right"><button type="button" class="btn btn-default btn-sm btn-editdata" data-subjgradeid="{{$subj->id}}"><i class="fa fa-edit text-warning"></i></button><button type="button" class="btn btn-default btn-sm btn-editdata-save" data-subjgradeid="{{$subj->id}}" disabled><i class="fa fa-share text-success"></i></button><button type="button" class="btn btn-default btn-sm btn-delete-subjdata" data-subjgradeid="{{$subj->id}}" disabled><i class="fa fa-trash text-danger"></i></button></td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                @endif
            </div>
        </div>
    @endforeach
@endif


<div class="modal fade"  id="modal-newrecord" aria-hidden="true" style="display: none;">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">New Record</h4>
                <button type="button" id="closeremarks" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row mb-2">
                    <div class="col-md-12">
                        <label>School ID</label>
                        <input type="number" class="form-control" id="input-schoolid"/>
                    </div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-12">
                        <label>School Name</label>
                        <input type="text" class="form-control" id="input-schoolname"/>
                    </div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-12">
                        <label>School Address</label>
                        <input type="text" class="form-control" id="input-schooladdress"/>
                    </div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-6">
                        <label>Select School Year</label>
                        <select class="form-control select2" id="select-sy">
                            <option value="0">Not on this selection</option>
                            @foreach($schoolyears as $schoolyear)
                                <option value="{{$schoolyear->id}}">{{$schoolyear->sydesc}}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-6" id="div-customsy">
                        <label>Custom School Year</label>
                        <input type="text" class="form-control" id="input-sy"/>
                        <small id="small-inputsy" class="text-danger">*Please fill in custom school year</small>
                    </div>
                    <small id="small-selectsy" class="text-danger col-md-12">*Please select school year. If not on the selection, please specify in the next highlighted field</small>
                </div>
                <div class="row mb-2">
                    <div class="col-md-6">
                        <label>Select Semester</label>
                        <select class="form-control select2" id="select-sem">
                            @foreach(DB::table('semester')->where('deleted','0')->get() as $semester)
                                <option value="{{$semester->id}}">{{$semester->semester}}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-12">
                        <label>Select Course</label>
                        <select class="form-control select2" id="select-course">
                            <option value="0">Not on this selection</option>
                            @foreach($courses as $course)
                                <option value="{{$course->id}}">{{$course->courseDesc}}</option>
                            @endforeach
                        </select>
                        <small id="small-selectcourse" class="text-danger">*Please select course. If not on the selection, please specify in the next highlighted field </small>
                    </div>
                </div>
                <div class="row mb-2" id="div-customcourse">
                    <div class="col-md-12">
                        <label>Custom Course</label>
                        <input type="text" class="form-control" id="input-coursename"/>
                        <small id="small-inputcoursename">*Please fill in custom course</small>
                    </div>
                </div>
            </div>
            <div class="modal-footer justify-content-between">
                <button type="button" class="btn btn-default" id="btn-close-addnewrecord" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="btn-submit-addnewrecord">Submit</button>
            </div>
        </div>            
    </div>
<!-- /.modal-content -->
</div>
<!-- /.modal-dialog -->