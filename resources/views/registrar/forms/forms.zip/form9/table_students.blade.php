
                <div id="example1_wrapper" class="dataTables_wrapper dt-bootstrap4" style="overflow: scroll">
                    <div class="row">
                        <div class="col-sm-12">
                            <table id="example2" class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        {{-- <th>#</th> --}}
                                        <th style="width:10%">#</th>
                                        <th>Name</th>
                                        <th>Strand</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @php
                                        $count = 1;   
                                    @endphp
                                    @foreach($students as $student)
                                        <tr>
                                            <td>{{$count}}</td>
                                            <td>
                                                {{$student->lastname}}, {{$student->firstname}} {{$student->middlename}}
                                                <br/>
                                                <small class="text-muted">{{$student->levelname}} / {{$student->sectionname}}</small>
                                            </td>
                                            <td>{{$student->strandname}}</td>
                                            <td>
                                                <button type="button" class="btn btn-sm btn-info btn-block btn-view-record" data-id="{{$student->id}}" data-levelid="{{$student->levelid}}" data-sectionid="{{$student->sectionid}}">View Record</button>
                                            </td>
                                        </tr>
                                        @php
                                            $count += 1;   
                                        @endphp
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>