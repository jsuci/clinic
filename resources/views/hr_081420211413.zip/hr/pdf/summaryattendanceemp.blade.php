@if(strtolower(DB::table('schoolinfo')->first()->abbreviation) == 'ck')
    <style>
        @page{
            size: 3.5in 7in;
            padding: 0px;
            margin: 5px;
        }
        * {
            font-family: Arial, Helvetica, sans-serif;
        }
        table{
            border-collapse: collapse;
        }
    </style>
    <table style="width: 100%; margin: 5px;">
        <thead>
            <tr>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <th>{{DB::table('schoolinfo')->first()->schoolname}}</th>
            </tr>
            <tr>
                <td style="font-size: 10px; text-align: center;">{{DB::table('schoolinfo')->first()->address}}</td>
            </tr>
            <tr>
                <td></td>
            </tr>
        </thead>
        <tr>
            <td style="background-color: #eb9bb1; text-align: center; font-size: 25px">Daily Time Record</td>
        </tr>
        <tr>
            <td>&nbsp;</td>
        </tr>
        <tr style="font-size: 12px;">
            <td>Name: <u>{{$info->lastname}}, {{$info->firstname}} {{$info->middlename[0]}}. {{$info->suffix}}</u></td>
        </tr>
        <tr style="font-size: 12px;">
            <td>Address: </td>
        </tr>
        <tr>
            <td></td>
        </tr>
        <tr style="font-size: 12px; font-weight: bold;">
            <td>{{date('M d', strtotime($datefrom))}} - {{date('d, Y', strtotime($dateto))}}</td>
        </tr>
    </table>
    <table style="width: 100%; font-size: 12px;margin: 5px;" border="1" >
        <thead>
            <tr>
                <th style="background-color: #e5f095;" rowspan="2">{{substr(date('M', strtotime($datefrom)), 0, 3)}}</th>
                <th colspan="2">AM</th>
                <th colspan="2">PM</th>
                <th rowspan="2">Hours<br/>Worked</th>
            </tr>
            <tr>
                <th style="width: 15%;">In</th>
                <th style="width: 15%;">Out</th>
                <th style="width: 15%;">In</th>
                <th style="width: 15%;">Out</th>
            </tr>
        </thead>
        @foreach($summarylogs as $summarylog)
            <tr>
                <td>&nbsp; {{date('d', strtotime($summarylog->date))}} <span style="opacity: 0.4;">{{substr(date('l', strtotime($summarylog->date)),0,3)}}</span></td>
                <td style="text-align: center;">
                    @if(collect($summarylog->logs)->where('tapstate','IN')->where('ttime','<','12:00:00')->count() > 0)
                    <span style="opacity: 0.5;">{{date('h:i', strtotime(collect($summarylog->logs)->where('tapstate','IN')->where('ttime','<','12:00:00')->first()->ttime))}}</span>
                    @endif
                </td>
                <td style="text-align: center;">
                    @if(collect($summarylog->logs)->where('tapstate','OUT')->where('ttime','<','12:00:00')->count() > 0)
                    <span style="opacity: 0.5;">{{date('h:i', strtotime(collect($summarylog->logs)->where('tapstate','OUT')->where('ttime','<','12:00:00')->first()->ttime))}}</span>
                    @endif
                </td>
                <td style="text-align: center;">
                    @if(collect($summarylog->logs)->where('tapstate','IN')->where('ttime','>','11:59:00')->count() > 0)
                    <span style="opacity: 0.5;">{{date('h:i', strtotime(collect($summarylog->logs)->where('tapstate','IN')->where('ttime','>','11:59:00')->first()->ttime))}}</span>
                    @endif
                </td>
                <td style="text-align: center;">
                    @if(collect($summarylog->logs)->where('tapstate','OUT')->where('ttime','>','11:59:00')->count() > 0)
                    <span style="opacity: 0.5;">{{date('h:i', strtotime(collect($summarylog->logs)->where('tapstate','OUT')->where('ttime','>','11:59:00')->last()->ttime))}}</span>
                    @endif
                </td>
                <td style="text-align: center;">
					<span style="opacity: 0.4;">{{$summarylog->hours}}h {{$summarylog->minutes}}m</span>
                </td>
            </tr>
        @endforeach
        <tr>
            <td>&nbsp;</td>
            <td colspan="4" style="text-align: right;">Total Working Hours: </td>
            <td style="text-align: center;">
                @php
                    $totalhours = collect($summarylogs)->sum('hours');
                    $totalminutes = collect($summarylogs)->sum('minutes');

                    while($totalminutes>=60)
                    {
                        $totalhours+=1;
                        $totalminutes-=60;
                    }
                @endphp
                    <span style="opacity: 0.4;">{{$totalhours}}h {{$totalminutes}}m</span>
            </td>
        </tr>
        <tr>
            <td colspan="6" style="padding-top: 20px; padding-bottom: 20px;">Signature: </td>
        </tr>
    </table>
@endif