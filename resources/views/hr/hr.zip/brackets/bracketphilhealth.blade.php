@extends('hr.layouts.app')
@section('content')

<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6 text-uppercase">
                <!-- <h1>Standard Deductions Setup</h1> -->
                <h4 class="text-warning" style="text-shadow: 1px 1px 1px #000000">
                <!-- <i class="fa fa-chart-line nav-icon"></i>  -->
                {{$type}} Computation Setup</h4>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="/home">Home</a></li>
                    <li class="breadcrumb-item active">Bracket</li>
                </ol>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>
<section class="content-body">
    <div class="row">
        <div class="col-md-12">
            <table class="table">
                <thead class="bg-info text-center">
                    <tr>
                        <th style="width: 50%">Monthly Salary</th>
                        <th>Premium rate(%)</th>
                        <th><i class="fa fa-cogs"></i></th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($brackets as $bracket)
                        <form action="/bracketedit" method="get">
                            <tr>
                                <td>
                                    <div class="row">
                                        <input type="hidden" name="id" step="any" class="form-control" value="{{$bracket->id}}"/>
                                        <input type="hidden" name="type" step="any" class="form-control" value="philhealth"/>
                                        <div class="col-5">
                                            <input type="number" name="rangefrom" step="any" class="form-control" value="{{$bracket->rangefrom}}" disabled/>
                                        </div>
                                        <div class="col-2 text-center">-</div>
                                        <div class="col-5">
                                            <input type="number" name="rangeto" step="any" class="form-control" value="{{$bracket->rangeto}}" disabled/>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="row">
                                        <input type="number" name="premiumrate" step="any" class="form-control" value="{{$bracket->premiumrate}}" disabled/>
                                    </div>
                                </td>
                                <td>
                                    <button type="button" class="btn btn-warning editrowfields">
                                        <i class="fa fa-edit"></i>
                                    </button>
                                </td>
                            </tr>
                        </form>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</section>
<script src="{{asset('plugins/jquery/jquery.min.js')}}"></script>
<!-- Bootstrap 4 -->
<script src="{{asset('plugins/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
<script>
    $(document).on('click','.editrowfields[type=button]', function(event){
        // console.log($(this).find('i'))
        event.preventDefault();
        $('.editrowfields').removeClass('btn-primary');
        $('.editrowfields').addClass('btn-warning');
        $('.editrowfields').prop('type','button');
        $('.editrowfields').find('i').removeClass('fa-upload');
        $('.editrowfields').find('i').addClass('fa-edit');
        $('input[type=number]').prop('disabled', true);
        $(this).removeClass('btn-warning');
        $(this).addClass('btn-primary');
        $(this).find('i').removeClass('fa-edit');
        $(this).find('i').addClass('fa-upload');
        $(this).prop('type','submit')
        $(this).closest('tr').find('input').attr('disabled',false);
    })
</script>
@endsection

