

@extends('hr.layouts.app')
@section('content')
<!-- DataTables -->
<link rel="stylesheet" href="{{asset('plugins/datatables-bs4/css/dataTables.bootstrap4.css')}}">
<script src="{{asset('plugins/jquery/jquery.min.js')}}"></script>
<!-- Toastr -->
<link rel="stylesheet" href="{{asset('plugins/toastr/toastr.min.css')}}">

<script>
    var $ = jQuery;
    $(document).ready(function(){
        $(".filter").on("keyup", function() {
            var input = $(this).val().toUpperCase();
            var visibleCards = 0;
            var hiddenCards = 0;

            $(".container").append($("<div class='card-group card-group-filter'></div>"));


            $(".card").each(function() {
                if ($(this).data("string").toUpperCase().indexOf(input) < 0) {

                $(".card-group.card-group-filter:first-of-type").append($(this));
                $(this).hide();
                hiddenCards++;

                } else {

                $(".card-group.card-group-filter:last-of-type").prepend($(this));
                $(this).show();
                visibleCards++;

                if (((visibleCards % 4) == 0)) {
                    $(".container").append($("<div class='card-group card-group-filter'></div>"));
                }
                }
            });

        });
    })
</script>
<style>
    table.table td h2.table-avatar {
    align-items: center;
    display: inline-flex;
    font-size: inherit;
    font-weight: 400;
    margin: 0;
    padding: 0;
    vertical-align: middle;
    white-space: nowrap;
}
.avatar {
    background-color: #aaa;
    border-radius: 50%;
    color: #fff;
    display: inline-block;
    font-weight: 500;
    height: 38px;
    line-height: 38px;
    margin: 0 10px 0 0;
    text-align: center;
    text-decoration: none;
    text-transform: uppercase;
    vertical-align: middle;
    width: 38px;
    position: relative;
    white-space: nowrap;
}
table.table td h2 span {
    color: #888;
    display: block;
    font-size: 12px;
    margin-top: 3px;
}
.avatar > img {
    border-radius: 50%;
    display: block;
    overflow: hidden;
    width: 100%;
}
img {
    vertical-align: middle;
    border-style: none;
}
.dataTables_filter, .dataTables_info { display: none; }
@media screen and (max-width : 1920px){
  .div-only-mobile{
  visibility:hidden;
  display: none;
  }
}
@media screen and (max-width : 906px){
 .desk{
  visibility:hidden;
  }
 .div-only-mobile{
  visibility:visible;
  display: block;
  }
  .viewtime{
      width: 200px !important;
  }
}
.timepickerinputs{cursor: pointer;}
</style>

<section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
        <h4 class="text-warning" style="text-shadow: 1px 1px 1px #000000"><i class="fa fa-chart-line nav-icon"></i> ATTENDANCE</h4>
          <!-- <h1>Attendance</h1> -->
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="/home">Home</a></li>
            <li class="breadcrumb-item active">Attendance</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>
{{-- <form name="changeattendance" action="/changeattendance" method="get"> --}}
    <div class="row">
        <div class="col-md-4 col-12" id="dateDiv">
            <label><small>Date:</small></label>
            {{-- <form name="changedate" action="/attendance/{{Crypt::encrypt('dashboard')}}" method="get"> --}}
                <input type="text" id="currentDate" name="currentDate" width="176" />
            {{-- </form> --}}
        </div>
    </div>
{{-- </form> --}}
<br>
{{-- <div class="card">
    <div class="card-body"> --}}
        <div class="row">
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                  <span class="input-group-text"><i class="fa fa-search"></i></span>
                </div>
                <input class="filter form-control col-md-4" placeholder="Search employee" />
            </div>
        </div>
        <div class="row pt-3  mb-2" style=" position: -webkit-sticky;
        position: sticky;
        top: 5%;
        background-color: #63ade8;
        font-size: 20px;z-index: 999; width: 100%;">
            <div class="col-md-3 ">&nbsp;</div>
            <div class="col-md-2 text-center">
                <label>AM IN</label>
            </div>
            <div class="col-md-2 text-center">
                <label>AM OUT</label>
            </div>
            <div class="col-md-2 text-center">
                <label>PM IN</label>
            </div>
            <div class="col-md-2 text-center">
                <label>PM OUT</label>
            </div>
            <div class="col-md-1">
                &nbsp;
            </div>
            {{-- <div class="col-md-12 bg-warning p-2" style="font-size: 11px;">
                <em><strong>New Update!</strong></em>
            </div> --}}
        </div>
        <div class="row d-flex align-items-stretch text-uppercase" id="attendancecontainer">
            @foreach($attendance as $att)
                <div class="card col-md-12 " style="border: none !important;box-shadow: none !important;" data-string="{{$att->employeeinfo->lastname}}, {{$att->employeeinfo->firstname}} {{$att->employeeinfo->middlename}}  {{$att->employeeinfo->suffix}} {{$att->employeeinfo->utype}}<">
                    <div class="card-body p-0" >
                        <div class="row" id="{{$att->employeeinfo->id}}" usertypeid="{{$att->employeeinfo->usertypeid}}">
                            @php
                            
                                if($att->attendance->taphistorystatus== 0)
                                {
                                    $attrdisabled = '';
                                }else{
                                    $attrdisabled = 'disabled';
                                }
                            @endphp
                            <div class="col-md-3">
                                {{-- @php
                                    $number = rand(1,3);
                                    if(strtoupper($att->employeeinfo->gender) == 'FEMALE'){
                                        $avatar = 'avatar/T(F) '.$number.'.png';
                                    }
                                    elseif(strtoupper($att->employeeinfo->gender) == 'MALE'){
                                        $avatar = 'avatar/T(M) '.$number.'.png';
                                    }else{
                                        
                                        $avatar = 'assets/images/avatars/unknown.png';
                                    }
                                @endphp --}}
                                {{-- <a href="#" class="avatar"> --}}
                                        {{-- <img src="{{asset($att->employeeinfo->picurl)}}" alt="" onerror="this.onerror = null, this.src='{{asset($avatar)}}'"/> --}}
                                        <a href="/employeeprofile/{{$att->employeeinfo->id}}">
                                            <strong>{{$att->employeeinfo->lastname}}</strong>, {{$att->employeeinfo->firstname}} {{$att->employeeinfo->middlename}} {{$att->employeeinfo->suffix}} <br/><span class="text-muted pl-5"><sup>{{$att->employeeinfo->utype}}</sup></span>
                                        </a>
                                    {{-- </a> --}}
                            </div>
                            <div class="col-md-2">
                                {{-- <label>AM IN</label> --}}
                                
                                @if($att->attendance->taphistorystatus == 0)
                                    <input id="timepickeramin{{$att->employeeinfo->id}}"  datevalue="{{$currentdate}}" value="{{$att->attendance->in_am}}" class="timepick timepickerinputs" name="am_in" />
                                    <script>
                                        $(document).ready(function(){
                                            $('#timepickeramin{{$att->employeeinfo->id}}').timepicker({ modal: false, header: false, footer: false, mode: 'ampm', format: 'HH:MM'});
                                            $('#timepickeramin{{$att->employeeinfo->id}}').on('change', function(){
                                                $(this).closest('.row').find('button').attr('disabled',false);
                                                var timepickeramin = $(this).val().split(':');
                                                if(timepickeramin[0] == '00'){
                                                    $(this).val('12:'+timepickeramin[1])
                                                }
                                            })
                                        })
                                    </script>
                                @else
                                    <input id="timepickeramin{{$att->employeeinfo->id}}"  datevalue="{{$currentdate}}" value="{{$att->attendance->in_am}}" class="timepick timepickerinputs form-control form-control-sm" name="am_in" disabled/>
                                @endif
                                {{-- <script>
                                    $(document).ready(function(){
                                        if('{{$att->attendance->taphistorystatus}}' == 0)
                                        {
                                            $('#timepickeramin{{$att->employeeinfo->id}}').timepicker({ modal: false, header: false, footer: false, mode: 'ampm', format: 'HH:MM'});
                                            $('#timepickeramin{{$att->employeeinfo->id}}').on('change', function(){
                                                $(this).closest('.row').find('button').attr('disabled',false);
                                                var timepickeramin = $(this).val().split(':');
                                                if(timepickeramin[0] == '00'){
                                                    $(this).val('12:'+timepickeramin[1])
                                                }
                                            })
                                        }else{
                                            $('#timepickeramin{{$att->employeeinfo->id}}').timepicker({ modal: false});
                                            $('#timepickeramin{{$att->employeeinfo->id}}').timepicker('disable');
                                            $('.clock').on('click', function(e){
                                                e.preventDefault();
                                            })
                                        }
                                    })
                                </script> --}}
                            </div>
                            <div class="col-md-2">
                                {{-- <label>AM OUT</label> --}}
                                @if($att->attendance->taphistorystatus == 0)
                                    <input id="timepickeramout{{$att->employeeinfo->id}}"  datevalue="{{$currentdate}}" value="{{$att->attendance->out_am}}" class="timepick timepickerinputs" name="am_out"/>
                                    <script>
                                        $(document).ready(function(){
                                            if('{{$att->attendance->taphistorystatus}}' == 0)
                                            {
                                                $('#timepickeramout{{$att->employeeinfo->id}}').timepicker({ modal: false, header: false, footer: false, mode: 'ampm', format: 'HH:MM'});
                                                $('#timepickeramout{{$att->employeeinfo->id}}').on('change', function(){
                                                    $(this).closest('.row').find('button').attr('disabled',false);
                                                    var timepickeramout = $(this).val().split(':');
                                                    if(timepickeramout[0] == '00'){
                                                        $(this).val('12:'+timepickeramout[1])
                                                    }
                                                })
                                            }else{

                                            }
                                        })
                                    </script>
                                @else
                                    <input id="timepickeramout{{$att->employeeinfo->id}}"  datevalue="{{$currentdate}}" value="{{$att->attendance->out_am}}" class="timepick timepickerinputs form-control form-control-sm" name="am_out" disabled/>
                                @endif
                            </div>
                            <div class="col-md-2">
                                {{-- <label>PM IN</label> --}}
                                @if($att->attendance->taphistorystatus == 0)
                                    <input id="timepickerpmin{{$att->employeeinfo->id}}"   datevalue="{{$currentdate}}"value="{{$att->attendance->in_pm}}" class="timepick timepickerinputs" name="pm_in"/>
                                    <script>
                                        $(document).ready(function(){
                                            if('{{$att->attendance->taphistorystatus}}' == 0)
                                            {
                                                $('#timepickerpmin{{$att->employeeinfo->id}}').timepicker({ modal: false, header: false, footer: false, mode: 'ampm', format: 'HH:MM'});
                                                $('#timepickerpmin{{$att->employeeinfo->id}}').on('change', function(){
                                                    $(this).closest('.row').find('button').attr('disabled',false);
                                                    var timepickerpmin = $(this).val().split(':');
                                                    if(timepickerpmin[0] == '00'){
                                                        $(this).val('12:'+timepickerpmin[1])
                                                    }
                                                })
                                            }else{
                                                $('.gj-modal').css('display','none')
                                            }
                                        })
                                    </script>
                                @else
                                    <input id="timepickerpmin{{$att->employeeinfo->id}}"  datevalue="{{$currentdate}}" value="{{$att->attendance->in_pm}}" class="timepick timepickerinputs form-control form-control-sm" name="pm_in" disabled/>
                                @endif
                            </div>
                            <div class="col-md-2">
                                {{-- <label>PM OUT</label> --}}
                                @if($att->attendance->taphistorystatus == 0)
                                    <input id="timepickerpmout{{$att->employeeinfo->id}}"   datevalue="{{$currentdate}}"value="{{$att->attendance->out_pm}}" class="timepick timepickerinputs" name="pm_out"/>
                                    <script>
                                        $(document).ready(function(){
                                            if('{{$att->attendance->taphistorystatus}}' == 0)
                                            {
                                                $('#timepickerpmout{{$att->employeeinfo->id}}').timepicker({ modal: false, header: false, footer: false, mode: 'ampm', format: 'HH:MM'});
                                                $('#timepickerpmout{{$att->employeeinfo->id}}').on('change', function(){
                                                    $(this).closest('.row').find('button').attr('disabled',false);
                                                    var timepickerpmout = $(this).val().split(':');
                                                    if(timepickerpmout[0] == '00'){
                                                        $(this).val('12:'+timepickerpmout[1])
                                                    }
                                                })
                                            }else{
                                                $('.gj-modal').css('display','none')

                                            }
                                        })
                                    </script>
                                @else
                                    <input id="timepickerpmout{{$att->employeeinfo->id}}"  datevalue="{{$currentdate}}" value="{{$att->attendance->out_pm}}" class="timepick timepickerinputs form-control form-control-sm" name="pm_out" disabled/>
                                @endif
                            </div>
                            <div class="col-md-1 col-sm-1">
                                <button type="button" class="btn btn-sm btn-default {{--updatetimeatt--}} timelogs"  id="timelogbutton{{$att->employeeinfo->id}}"> <i class="fa fa-clock"></i> Logs</button>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
        <div class="modal fade" id="modal-timelogs" aria-hidden="true" style="display: none;">
            <div class="modal-dialog modal-lg">
              <div class="modal-content" id="timelogsdetails">

              </div>
              <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
          </div>
<!-- Bootstrap 4 -->
<script src="{{asset('plugins/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
<!-- ChartJS -->
<script src="{{asset('plugins/chart.js/Chart.min.js')}}"></script>
<!-- DataTables -->
<script src="{{asset('plugins/datatables/jquery.dataTables.js')}}"></script>
<script src="{{asset('plugins/datatables-bs4/js/dataTables.bootstrap4.js')}}"></script>
<script src="{{asset('assets/scripts/gijgo.min.js')}}" ></script>
<script src="{{asset('plugins/moment/moment.min.js')}}"></script>
<!-- Toastr -->
<script src="{{asset('plugins/toastr/toastr.min.js')}}"></script>
<!-- Bootstrap Switch -->
<script src="{{asset('plugins/bootstrap-switch/js/bootstrap-switch.min.js')}}"></script>
<script>
   $(function () {
    var table =  $("#example1").DataTable({
            pageLength : 10,
            lengthMenu: [[5, 10, 20, -1], [5, 10, 20, 'Show All']],
        // scrollY:        "500px",
        // scrollX:        true,
        scrollCollapse: true,
        paging:         false,
        fixedColumns:   true
        });
        // / #myInput is a <input type="text"> element
        $('#myInput').on( 'keyup', function () {
            table.search( this.value ).draw();
        } );
    });
    
    $(document).ready(function(){

        const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 1000
        });

        $('#currentDate').datepicker({
            format: 'mm-dd-yyyy',
            value: '{{$currentdate}}'
        });
        $('select[name=monthselection]').on('change', function(){
            // var monthid = $(this).val();
            // var yearid = $('select[name=yearselection]').val();
            $('form[name=changeattendance]').submit();
        })
        $('[data-dismiss=modal]').on('click', function (e) {
            var $t = $(this),
                target = $t[0].href || $t.data("target") || $t.parents('.modal') || [];

            $(target)
                .find("input,textarea,select")
                .val('')
                .end()
                .find("input[type=checkbox], input[type=radio]")
                .prop("checked", "")
                .end();
        });
        $('#currentDate').on('change', function(){
                $.ajax({
                    url: '/hr/attendance/index',
                    type:"GET",
                    data:{
                        changedate:$(this).val()
                    },
                    success:function(data) {
                    $('#attendancecontainer').empty();
                    $('#attendancecontainer').append(data);
                }
            });
        })
        $(document).on('click','.timelogs', function(){
            $('#modal-timelogs').modal('show')
            var thisrow = $(this).closest('.row')
            var employeeid = thisrow.attr('id');
            var usertypeid = thisrow.attr('usertypeid');
            var selecteddate =  $('input[name=currentDate]').val()
            $.ajax({
                url: '/hr/attendance/gettimelogs',
                type:"GET",
                data:{
                    employeeid: employeeid,
                    usertypeid: usertypeid,
                    selecteddate: selecteddate
                },
                success:function(data) {
                    $('#timelogsdetails').empty()
                    $('#timelogsdetails').append(data)
                }
            });
        })
        var newlogscounter = 1;
        $(document).on('click','#buttonaddnewlog', function(){
            $('#newlogscontainer').append(
                '<div class="row mb-2">'+
                    '<div class="col-1">'+
                        '<button type="button" class="btn btn-sm btn-default p-0 mt-1 btn-block savenewtimelog'+newlogscounter+'">&nbsp;<i class="fa fa-check"></i>&nbsp;</button>'+
                    '</div>'+
                    '<div class="col-6">'+
                        '<input id="newtimepick'+newlogscounter+'" class="timepick timepickerinputs form-control form-control-sm" name="newtimelog" readonly/>'+
                    '</div>'+
                    '<div class="col-2  p-0 text-center">'+
                    
                        '<input type="checkbox" id="newlogstate'+newlogscounter+'" name="logstate" checked data-bootstrap-switch data-off-color="warning" data-on-text="IN"  data-off-text="OUT" data-on-color="success" data-size="sm">'+
                    '</div>'+
                    '<div class="col-2  p-0 text-center">'+
                    
                        '<input type="checkbox" id="newlog'+newlogscounter+'" name="dayshift" checked data-bootstrap-switch data-off-color="warning" data-on-text="AM"  data-off-text="PM" data-on-color="success" data-size="sm">'+
                    '</div>'+
                    '<div class="col-1">'+
                        '<button type="button" class="btn btn-sm btn-default p-0 mt-1 btn-block removenewtimelog">&nbsp;<i class="fa fa-times"></i>&nbsp;</button>'+
                    '</div>'+
                '</div>'
            )
            $('#newtimepick'+newlogscounter).timepicker({ modal: false, header: false, footer: false, mode: 'ampm', format: 'hh:MM'});
            $('#newtimepick'+newlogscounter).on('change', function(){
                var newlogscounter = $(this).val().split(':');
                if(newlogscounter[0] == '00'){
                    $(this).val('12:'+newlogscounter[1])
                }
            })
            var timeshift = 'am';
            $('#newlog'+newlogscounter).bootstrapSwitch('state', true);
            $('#newlog'+newlogscounter).on('switchChange.bootstrapSwitch',function () {
                var check = $(this).closest('.bootstrap-switch-on')
                if (check.length > 0) {
                    timeshift = 'pm';
                } else {
                    timeshift = 'am';
                }
            });
            var logstate = 'in';
            $('#newlogstate'+newlogscounter).bootstrapSwitch('state', true);
            $('#newlogstate'+newlogscounter).on('switchChange.bootstrapSwitch',function () {
                var check = $(this).closest('.bootstrap-switch-on')
                if (check.length > 0) {
                    logstate = 'out';
                } else {
                    logstate = 'in';
                }
            });
            $(document).on('click','.savenewtimelog'+newlogscounter, function(){
                var thisrow = $(this).closest('.row');
                var thissavebutton = $(this);
                var timelog = thisrow.find('input[name="newtimelog"]').val();
                var employeeid = $('#newlogscontainer').attr('employeeid');
                var usertypeid = $('#newlogscontainer').attr('usertypeid');
                var selecteddate =  $('input[name=currentDate]').val()
                if(timelog.replace(/^\s+|\s+$/g, "").length == 0){

                    toastr.warning('Please set a time first!','Time Logs')

                }else{
                    $.ajax({
                        url: '/hr/attendance/addtimelog',
                        type:"GET",
                        data:{
                            employeeid  : employeeid,
                            usertypeid  : usertypeid,
                            timelog     : timelog,
                            timeshift   : timeshift,
                            tapstate    : logstate,
                            selecteddate: selecteddate
                        },
                        success:function(data) {
                            if(data == '1')
                            {
                                toastr.success('Added successfully!','Time Logs')
                                thissavebutton.attr('disabled',true)
                                thisrow.find('.clock').remove()
                                thisrow.find('.removenewtimelog').remove()
                                thisrow.find("[name='dayshift']").bootstrapSwitch('disabled',true);
                            }else{
                                toastr.danger('Something went wrong!','Time Logs')
                            }
                        }
                    });
                }
            })
            newlogscounter+=1;

            $('.removenewtimelog').on('click', function(){
                $(this).closest('.row').remove()
            })
        })
        $(document).on('click', '.deletelog', function(){
            var thisrow = $(this).closest('.row');
            var logid   = $(this).attr('id');
            Swal.fire({
                title: 'Are you sure you want to delete this log?',
                type: 'warning',
                confirmButtonColor: '#3085d6',
                confirmButtonText: 'Delete',
                showCancelButton: true,
                allowOutsideClick: false
            }).then((confirm) => {
                if (confirm.value) {

                    $.ajax({
                        url: '/hr/attendance/deletetimelog',
                        type: 'get',
                        dataType: 'json',
                        data: {
                            id          :   logid
                        },
                        complete: function(data){
                            thisrow.remove()
                            toastr.success('Time log deleted successfully!','Time Logs')
                        }
                    })
                }
            })
        })
        // $(document).on('click','.updatetimeatt', function(){
        //     var thisrow = $(this).closest('.row')
        //     var employeeid = $(this).closest('.row').attr('id');
        //     var amin = thisrow.find('#timepickeramin'+employeeid).val();
        //     var amout = thisrow.find('#timepickeramout'+employeeid).val();
        //     var pmin = thisrow.find('#timepickerpmin'+employeeid).val();
        //     var pmout = thisrow.find('#timepickerpmout'+employeeid).val();
        //     var selecteddate =  $('input[name=currentDate]').val()
        //         $.ajax({
        //             url: '/hr/attendance/updatetime',
        //             type:"GET",
        //             data:{
        //                 employeeid: employeeid,
        //                 amin        :   amin,
        //                 amout       :   amout,
        //                 pmin        :   pmin,
        //                 pmout       :   pmout,
        //                 selecteddate: selecteddate
        //             },
        //             dataType: 'json',
        //             success:function(data) {
        //                 if(data == 1)
        //                 {
                            
        //                 toastr.success('Updated successfully!')
        //                 thisrow.find('button').attr('disabled', true)
        //                 }   
        //             }
        //         });
        // })
        
    })
  </script>
@endsection

