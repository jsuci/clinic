

@extends('hr.layouts.app')
@section('content')
<!-- DataTables -->
<link rel="stylesheet" href="{{asset('plugins/datatables-bs4/css/dataTables.bootstrap4.css')}}">
<link rel="stylesheet" href="{{asset('plugins/summernote/summernote-bs4.css')}}">
<div class="page-header">
    <div class="row align-items-center">
        <div class="col-md-12">
            <h3 class="page-title">Overtime</h3>
            <ul class="breadcrumb col-md-12">
                <li class="breadcrumb-item"><a href="/home">Dashboard</a></li>
                <li class="breadcrumb-item active">Overtime</li>
            </ul>
            {{-- <div class="col-md-2 float-right ml-auto">
                <a href="#" class="btn btn-block" data-toggle="modal" data-target="#add_leave"><i class="fa fa-plus"></i> Add Overtime</a>
            </div> --}}
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
        <div class="stats-info">
            <h6>Overtime Employee</h6>
            <h4>12 <span>this month</span></h4>
        </div>
    </div>
    <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
        <div class="stats-info">
            <h6>Overtime Hours</h6>
            <h4>118 <span>this month</span></h4>
        </div>
    </div>
    <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
        <div class="stats-info">
            <h6>Pending Request</h6>
            <h4>23</h4>
        </div>
    </div>
    <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
        <div class="stats-info">
            <h6>Rejected</h6>
            <h4>5</h4>
        </div>
    </div>
</div>
@if(session()->has('updated'))
    <div class="alert alert-success alert-dismissible col-12">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <h5><i class="icon fas fa-check"></i> Alert!</h5>
        {{ session()->get('updated') }}
    </div>
@endif
@if(session()->has('messageDispproved'))
    <div class="alert alert-success alert-dismissible col-12">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <h5><i class="icon fas fa-check"></i> Alert!</h5>
        {{ session()->get('messageDispproved') }}
    </div>
@endif
@if(isset($message))
    <div class="alert alert-light alert-dismissible col-12">
        {{-- <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button> --}}
        <h5><i class="icon fas fa-ban"></i> Alert!</h5>
        {{ $message }}<br>
        Posibble reason/s:
        <ul>
            <li>
                @if(isset($payrolldateexists))
                    @if($payrolldateexists == 0)
                        Payroll date not set
                        <br>
                        <a href="/employeesalary/dashboard">Click to set payroll date</a>
                    @else
                        <strike>Payroll date not set</strike>
                    @endif
                @endif
            </li>
            <li>
                @if(isset($rateexists))
                    @if($rateexists == 0)
                        Payroll Items: Designation rates not set
                        <br>
                        <a href="/payrollitems/dashboard">Click to set payroll items</a>
                    @endif
                @endif
            </li>
        </ul>
    </div>
@endif
@if(isset($overtimerates))
<div class="card">
    <div class="card-header">
        <div class="float-right">
            <p class="text-muted"  >Settings
                <button class="btn btn-sm btn-light"  data-toggle="modal" data-target="#settings">
                    <i class="fa fa-cogs text-muted"></i>
                </button>
                <div class="modal fade" id="settings" style="display: none;" aria-hidden="true">
                    <div class="modal-dialog modal-md">
                        <form action="/overtime/overtimesettings" method="get">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Overtime Settings</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <span class="text-muted">Rate per hour</span>
                                    <br>
                                    &nbsp;
                                    @foreach ($overtimerates as $overtime)
                                        <div class="form-group">
                                            <div class="input-group">
                                                <div class="input-group-prepend" style="width: 50%;">
                                                    <span class="input-group-text " style="width: 100%;">{{$overtime->description}}</span>
                                                </div>
                                                <input type="hidden" name="usertypeid[]" class="form-control"style="width: 50%;" value="{{$overtime->id}}">
                                                <input type="text" name="overtime_rate[]" class="form-control"style="width: 50%;" value="{{$overtime->overtimerate}}">
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                                <div class="modal-footer justify-content-between">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-Success">Save Changes</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </p>
        </div>
    </div>
    <div class="card-body">
        <div id="example1_wrapper" class="dataTables_wrapper dt-bootstrap4" style="overflow: scroll">
            <div class="row">
                <div class="col-sm-12">
                    <table id="example1" style="font-size: 12px" class="table table-bordered table-striped dataTable" role="grid" aria-describedby="example1_info">
                        <thead>
                            <tr>
                                {{-- <th>#</th> --}}
                                <th>Employee</th>
                                <th>OT Date</th>
                                <th>Time range</th>
                                <th>Description</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if(isset($overtimes))
                                @foreach ($overtimes as $overtime)
                                    <tr>
                                        <td>{{$overtime->lastname}}, {{$overtime->firstname}}</td>
                                        <td>{{$overtime->date_request}}</td>
                                        <td>{{$overtime->time_from}} - {{$overtime->time_to}}</td>
                                        <td>{{$overtime->reason}}</td>
                                        <td>
                                            @if($overtime->status == 'pending')
                                                <button class="btn btn-sm btn-block btn-warning" data-toggle="modal" data-target="#pending{{$overtime->id}}"><strong>Pending</strong></button>
                                                <div class="modal fade" id="pending{{$overtime->id}}" style="display: none;" aria-hidden="true">
                                                    <div class="modal-dialog modal-sm">
                                                        <form action="/overtime/changestatus" method="get" id="{{$overtime->id}}" name="changestatus">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h4 class="modal-title">{{$overtime->lastname}}, {{$overtime->firstname}}</h4>
                                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                        <span aria-hidden="true">×</span>
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <input id="{{$overtime->id}}" type="hidden" value="{{$overtime->id}}" name="overtimeid"/>
                                                                    {{-- <h4><strong>{{$leave->leave_type}} Leave</strong></h4> --}}
                                                                    <br>
                                                                    Date: {{$overtime->date_request}}
                                                                    <br>
                                                                    <br>
                                                                    Time: {{$overtime->time_from}} - {{$overtime->time_to}}
                                                                    <br>
                                                                    <br>
                                                                    <strong>Reason</strong>
                                                                    <textarea id="compose-textarea{{$overtime->id}}" class="form-control" name="reason" style="height: 100px" readonly>
                                                                        {{$overtime->reason}}
                                                                    </textarea>
                                                                </div>
                                                                <div class="modal-footer justify-content-between">
                                                                    <input id="{{$overtime->id}}" type="hidden" value="" name="status"/>
                                                                    <button type="button" class="btn btn-danger disapproved" id="disapproved{{$overtime->id}}">Reject</button>
                                                                    <input id="{{$overtime->id}}" type="hidden" value="" name="status"/>
                                                                    <button type="button" class="btn btn-primary approved" id="approved{{$overtime->id}}">Approve</button>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            @elseif($overtime->status == 'disapproved')
                                                <button class="btn btn-sm btn-block btn-danger">Disapproved</button>
                                            @elseif($overtime->status == 'approved')
                                                <button class="btn btn-sm btn-block btn-success">Approved</button>
                                            @endif
                                        </td>
                                        {{-- <td class="p-0">
                                            <textarea id="compose-textarea{{$leave->id}}" class="form-control compose-textarea" name="content" style="height: 300px">{{$leave->reason}}</textarea>
                                        </td>
                                        <td> --}}
                                            {{-- @if($leave->status == 'pending')
                                                <button class="btn btn-sm btn-block btn-warning" data-toggle="modal" data-target="#pending{{$leave->id}}"><strong>Pending</strong></button>
                                                <div class="modal fade" id="pending{{$leave->id}}" style="display: none;" aria-hidden="true">
                                                    <div class="modal-dialog modal-sm">
                                                        <form action="/leaves/changestatus" method="get" id="{{$leave->id}}" name="changestatus">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h4 class="modal-title">{{$leave->lastname}}, {{$leave->firstname}}</h4>
                                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                        <span aria-hidden="true">×</span>
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <input id="{{$leave->id}}" type="hidden" value="{{$leave->id}}" name="leaveid"/>
                                                                    <h4><strong>{{$leave->leave_type}} Leave</strong></h4>
                                                                    <br>
                                                                    Days: {{$leave->numdays}}
                                                                    <br>
                                                                    <br>
                                                                    From: {{$leave->date_from}}
                                                                    <br>
                                                                    <br>
                                                                    To: {{$leave->date_to}}
                                                                    <br>
                                                                    <br>
                                                                    <strong>Reason</strong>
                                                                    <textarea id="compose-textarea{{$leave->id}}" class="form-control compose-textarea" name="content" style="height: 300px">
                                                                        {{$leave->reason}}
                                                                    </textarea>
                                                                </div>
                                                                <div class="modal-footer justify-content-between">
                                                                    <input id="{{$leave->id}}" type="hidden" value="sad" name="status"/>
                                                                    <button type="button" class="btn btn-warning disapproved" id="disapproved{{$leave->id}}">Disapprove</button>
                                                                    <button type="button" class="btn btn-primary approves" id="approved{{$leave->id}}">Approve</button>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            @elseif($leave->status == 'disapproved')
                                                <button class="btn btn-sm btn-block btn-danger">Disapproved</button>
                                            @elseif($leave->status == 'approved')
                                                <button class="btn btn-sm btn-block btn-success">Approved</button>
                                            @endif --}}
                                        {{-- </td> --}}
                                    </tr>
                                @endforeach
                            @endif
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endif
<script src="{{asset('plugins/jquery/jquery.min.js')}}"></script>
<!-- Bootstrap 4 -->
<script src="{{asset('plugins/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
<!-- ChartJS -->
<script src="{{asset('plugins/chart.js/Chart.min.js')}}"></script>
<!-- DataTables -->
<script src="{{asset('plugins/datatables/jquery.dataTables.js')}}"></script>
<script src="{{asset('plugins/datatables-bs4/js/dataTables.bootstrap4.js')}}"></script>
<script>
    $(function () {
        $("#example1").DataTable({
            pageLength : 10,
            lengthMenu: [[5, 10, 20, -1], [5, 10, 20, 'Show All']]
        });
    })
    $(document).ready(function(){
        window.setTimeout(function () {
            $(".alert-success").fadeTo(500, 0).slideUp(500, function () {
                $(this).remove();
            });
        }, 5000);
        window.setTimeout(function () {
            $(".alert-danger").fadeTo(500, 0).slideUp(500, function () {
                $(this).remove();
            });
        }, 5000);
        $(document).on('click', '.disapproved', function(){
            //    console.log($(this).closest('form[name=changestatus]'));
            $(this).prev('input').val($(this)[0].innerText);
            $(this).closest('form[name=changestatus]').submit();

        })
        $(document).on('click', '.approved', function(){
            //    console.log($(this).closest('form[name=changestatus]'));
            $(this).prev('input').val($(this)[0].innerText);
            $(this).closest('form[name=changestatus]').submit();

        })
   })
  </script>
@endsection

