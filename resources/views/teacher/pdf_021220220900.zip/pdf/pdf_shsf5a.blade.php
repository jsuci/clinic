<style>
    @page{
        size: 13in 8.5in;
    }
    *{
        
        font-family: Arial, Helvetica, sans-serif;
    }
</style>
@php
    $countMale = 0;
    $countFemale = 0;
    $init = 21;
    $firstsemcompletemale = 0;
    $firstsemcompletefemale = 0;
    $firstsemincompletemale = 0;   
    $firstsemincompletefemale = 0;   
    $secondsemcompletemale = 0;
    $secondsemcompletefemale = 0;
    $secondsemincompletemale = 0;  
    $secondsemincompletefemale = 0;  
    
    $signatories = DB::table('signatory')
        ->where('form','form5a')
        ->where('syid', $sy->id)
        ->where('deleted','0')
        ->where('acadprogid',5)
        ->get();

    $signatory_name1 = '';
    $signatory_name2 = '';
    if(count($signatories) == 0)
    {
        $signatories = DB::table('signatory')
            ->where('form','form5a')
            ->where('syid', $sy->id)
            ->where('deleted','0')
            ->where('acadprogid',0)
            ->get();

        if(count($signatories) == 0)
        {
                
            $signatory_name1 = DB::table('schoolinfo')->first()->authorized;
        }
        elseif(count($signatories) == 1)
        {
            $signatory_name1 = $signatories[0]->name;
        }else{
            $signatory_name1 = collect($signatories)->first()->name;
            $signatory_name2 = collect($signatories)->last()->name;
        }

    }
    elseif(count($signatories) == 1)
    {
        $signatory_name1 = $signatories[0]->name;
    }else{
        if(collect($signatories)->where('levelid',$getSectionAndLevel[0]->levelid)->count() == 1)
        {
            $signatory_name1 = collect($signatories)->where('levelid',$getSectionAndLevel[0]->levelid)->first()->name;
        }
        if(collect($signatories)->where('levelid',$getSectionAndLevel[0]->levelid)->count() >=2)
        {
            $signatory_name1 = collect($signatories)->where('levelid',$getSectionAndLevel[0]->levelid)->first()->name;
            $signatory_name2 = collect($signatories)->where('levelid',$getSectionAndLevel[0]->levelid)->last()->name;
        }
    }
@endphp
<table style="width: 100%; table-layout: fixed;">
    <tr style="font-size: 12px;">
        <th colspan="10" style="text-align: center; font-weight: bold;">School Form 5A<br>End of Semester and School Year Status of Learners for Senior High School<br>(SF5A-SHS)
        </th>
    </tr>
</table>
<div style="line-height: 15px;">&nbsp;</div>
<table style="width: 100%; font-size: 9px;">
    <thead>
        <tr>
            <td style="text-align: right; width: 10%;">School Name</td>
            <td style="border: 1px solid black; width: 25%; text-align: center:">{{$schoolinfo->schoolname}}</td>
            <td style="text-align: right; width: 7%;">School ID</td>
            <td style="border: 1px solid black; width: 8%;; text-align: center:">{{$schoolinfo->schoolid}}</td>
            <td style="text-align: right; width: 6%;">District</td>
            <td style="width: 12%; border: 1px solid black;; text-align: center:">{{DB::table('schoolinfo')->first()->district}}</td>
            <td style="text-align: right; width: 6%;">Division</td>
            <td style="width: 15%; border: 1px solid black; text-align: center:">{{DB::table('schoolinfo')->first()->division}}</td>
            <td style="width: 6%; text-align: right;">Region</td>
            <td style="width: 5%; border: 1px solid black; text-align: center:">{{DB::table('schoolinfo')->first()->region}}</td>
        </tr>
    </thead>
</table>
<div style="line-height: 10px;">&nbsp;</div>
<table style="width: 100%; font-size: 9px;">
    <thead>
        <tr>
            <td style="text-align: right; width: 10%;">Semester</td>
            <td style="text-align: center; border: 1px solid black; width: 13%;">{{$sem->semester}}</td>
            <td style="text-align: right; width: 10%;">School Year</td>
            <td style="text-align: center; border: 1px solid black; width: 13%;">{{$sy->sydesc}}</td>
            <td style="text-align: right; width: 10%;">Grade Level</td>
            <td style="text-align: center; border: 1px solid black; width: 13%;">{{$getSectionAndLevel[0]->levelname}}</td>
            <td style="text-align: right; width: 10%;">Section</td>
            <td style="text-align: center; border: 1px solid black; width: 21%;">{{$getSectionAndLevel[0]->sectionname}}</td>
        </tr>
    </thead>
</table>
<div style="line-height: 10px;">&nbsp;</div>
<table style="width: 100%; font-size: 9px;">
    <thead>
        <tr>
            <td style="text-align: right;">Track and  Strand</td>
            <td style="border: 1px solid black; text-align: center;">
                @if(count($strandinfo)>0)
                    {{$strandinfo[0]->trackname}} - {{$strandinfo[0]->strand}}
                @endif
            </td>
            <td style="text-align: right;">Course/s (only for TVL)</td>
            <td style="border: 1px solid black;">
                {{$courses}}
            </td>
        </tr>
    </thead>
</table>
<div style="line-height: 10px;">&nbsp;</div>
<table style="width: 100%;">
    <tr>
        <td style="width: 70%; padding: 0px;"><table style="width: 100%; font-size: 10px;" border="1">
                <thead>
                    <tr>
                        <th style="width: 5%">No</th>
                        <th style="width: 17%">LRN</th>
                        <th style="width: 29%; text-align: center;">LEARNER'S NAME<br>(Last Name, First Name, Name Extension, Middle Name)</th>
                        <th style="width: 19%; text-align: center;">BACK SUBJECTS<br>List down subjects where learner obtain a rating below 75%</th>
                        <th style="width: 15%; text-align: center;">END OF<br>SEMESTER STATUS<br>Complete/Incomplete</th>
                        <th style="width: 15%; text-align: center;">END OF<br>SCHOOL YEAR<br>STATUS<br>(Regular/Irregular)</th>
                    </tr>
                </thead>
                <tr>
                    <td colspan="6" style="text-align: none;background-color:lightgrey;padding-left:5px;">MALE</td>
                </tr>
                @if(count($students)>0)
                    @foreach ($students as $student)
                        @if (strtoupper($student->gender)=='MALE')
                            @php
                                $countMale+=1;   
                            @endphp
                            <tr style="font-size: 9px !important;" nobr="true">
                                <td class="p-0">{{$countMale}}</td>
                                <td>{{$student->lrn}}</td>
                                <td style="text-align: left;">{{ucwords(strtolower($student->lastname.', '.$student->firstname.' '.$student->middlename.' '.$student->suffix))}}</td>
                                <td style="text-align: left; margin: 0px;">
                                    @if(collect($student->backsubjects)->where('semid',$sem->id)->count()>0)
                                        @foreach (collect($student->backsubjects)->where('semid',$sem->id)->values() as $backsubjectskey => $backsubjects)
                                            {{$backsubjectskey+1}}. {{ucwords(strtolower($backsubjects->subjectcode))}}
                                            <div style="line-height: 5px;">&nbsp;</div>
                                        @endforeach
                                    @endif
                                </td>
                                <td>
                                    @if (collect($student->backsubjects)->where('semid',$sem->id)->count() == 0)
                                        COMPLETE
                                    @else
                                        INCOMPLETE
                                    @endif
                                </td>
                                <td>
                                    @if (collect($student->backsubjects)->where('semid',$sem->id)->count() == 0)
                                        REGULAR
                                    @else
                                        IRREGULAR
                                    @endif
                                </td>
                            </tr>
                        @endif
                    @endforeach
                @endif
                @for($x = $countMale; $x<$init; $x++)
                    <tr style="font-size: 9px !important;" nobr="true">
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                @endfor
                <tr>
                    <td colspan="6" style="text-align: none;background-color:lightgrey;padding-left:5px;">FEMALE</td>
                </tr>
                @if(count($students)>0)
                    @foreach ($students as $student)
                        @if (strtoupper($student->gender)=='FEMALE')
                            @php
                                $countFemale+=1;   
                            @endphp
                            <tr style="font-size: 9px !important;" nobr="true">
                                <td class="p-0">{{$countFemale}}</td>
                                <td>{{$student->lrn}}</td>
                                <td style="text-align: left;">{{ucwords(strtolower($student->lastname.', '.$student->firstname.' '.$student->middlename.' '.$student->suffix))}}</td>
                                <td style="text-align: left; margin: 0px;">
                                    @if(collect($student->backsubjects)->where('semid',$sem->id)->count()>0)
                                        @foreach (collect($student->backsubjects)->where('semid',$sem->id)->values() as $backsubjectskey => $backsubjects)
                                        {{$backsubjectskey+1}}. {{ucwords(strtolower($backsubjects->subjectcode))}}
                                            <div style="line-height: 5px;">&nbsp;</div>
                                        @endforeach
                                    @endif
                                </td>
                                <td>
                                    @if (collect($student->backsubjects)->where('semid',$sem->id)->count() == 0)
                                        COMPLETE
                                    @else
                                        INCOMPLETE
                                    @endif
                                </td>
                                <td>
                                    @if (collect($student->backsubjects)->where('semid',$sem->id)->count() == 0)
                                        REGULAR
                                    @else
                                        IRREGULAR
                                    @endif
                                </td>
                            </tr>
                        @endif
                    @endforeach
                @endif
                @for($x = $countFemale; $x<$init; $x++)
                    <tr style="font-size: 9px !important;" nobr="true">
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                @endfor
            </table>
        </td>
        <td style="width: 30%;">
            <div style="line-height: 50px;">&nbsp;</div><table style="width: 100%; font-size: 9px;" border="1">
                <thead style="text-align: center;">
                    <tr>
                        <th colspan="4" style="text-align: center;">SUMMARY TABLE 1ST SEM</th>
                    </tr>
                    <tr>
                        <th style="width: 35%;">STATUS</th>
                        <th style="width: 20%;">MALE</th>
                        <th style="width: 25%;">FEMALE</th>
                        <th style="width: 20%;">TOTAL</th>
                    </tr>
                </thead>
                <tbody style="vertical-align: top;">
                    <tr>
                        <td>COMPLETE</td>
                        <td style="text-align: center;">{{collect($students)->where('gender','male')->where('sem1status','1')->count()}}</td>
                        <td style="text-align: center;">{{collect($students)->where('gender','female')->where('sem1status','1')->count()}}</td>
                        <td style="text-align: center;">{{collect($students)->where('sem1status','1')->count()}}</td>
                    </tr>
                    <tr>
                        <td>INCOMPLETE</td>
                        <td style="text-align: center;">{{collect($students)->where('gender','male')->where('sem1status','0')->count()}}</td>
                        <td style="text-align: center;">{{collect($students)->where('gender','female')->where('sem1status','0')->count()}}</td>
                        <td style="text-align: center;">{{collect($students)->where('sem1status','0')->count()}}</td>
                    </tr>
                    <tr>
                        <td>TOTAL</td>
                        <td style="text-align: center;">{{collect($students)->where('gender','male')->count()}}</td>
                        <td style="text-align: center;">{{collect($students)->where('gender','female')->count()}}</td>
                        <td style="text-align: center;">{{collect($students)->where('sem1status','0')->count()+collect($students)->where('sem1status','1')->count()}}</td>
                    </tr>
                    {{-- <tr>
                        <th>COMPLETE</th>
                        <th style="text-align: center;">
                            @php
                                $firstsemcompletemale = 0;
                            @endphp
                            @foreach ($students as $student)
                                @if (strtoupper($student->gender)=='MALE')
                                    @if(collect($student->backsubjects)->where('semid',1)->count() == 0)
                                        @php
                                            $firstsemcompletemale+=1;
                                        @endphp
                                    @endif
                                @endif
                            @endforeach
                            {{$firstsemcompletemale}}
                        </th>
                        <th style="text-align: center;">
                            @php
                                $firstsemcompletefemale = 0;
                            @endphp
                            @foreach ($students as $student)
                                @if (strtoupper($student->gender)=='FEMALE')
                                    @if(collect($student->backsubjects)->where('semid',1)->count() == 0)
                                        @php
                                            $firstsemcompletefemale+=1;
                                        @endphp
                                    @endif
                                @endif
                            @endforeach
                            {{$firstsemcompletefemale}}
                        </th>
                        <th style="text-align: center;">{{$firstsemcompletemale + $firstsemcompletefemale}}</th>
                    </tr>
                    <tr>
                        <th>INCOMPLETE</th>
                        <th style="text-align: center;">
                            @php
                                $firstsemincompletemale = 0;
                            @endphp
                            @foreach ($students as $student)
                                @if (strtoupper($student->gender)=='MALE')
                                    @if(collect($student->backsubjects)->where('semid',1)->count() > 0)
                                        @php
                                            $firstsemincompletemale+=1;
                                        @endphp
                                    @endif
                                @endif
                            @endforeach
                            {{$firstsemincompletemale}}
                        </th>
                        <th style="text-align: center;">
                            @php
                                $firstsemincompletefemale = 0;
                            @endphp
                            @foreach ($students as $student)
                                @if (strtoupper($student->gender)=='FEMALE')
                                    @if(collect($student->backsubjects)->where('semid',1)->count() > 0)
                                        @php
                                            $firstsemincompletefemale+=1;
                                        @endphp
                                    @endif
                                @endif
                            @endforeach
                            {{$firstsemincompletefemale}}
                        </th>
                        <th style="text-align: center;">{{$firstsemincompletemale + $firstsemincompletefemale}}</th>
                    </tr>
                    <tr>
                        <th>TOTAL</th>
                        <th style="text-align: center;">{{$firstsemcompletemale + $firstsemincompletemale}}</th>
                        <th style="text-align: center;">{{$firstsemcompletefemale + $firstsemincompletefemale}}</th>
                        <th style="text-align: center;">{{($firstsemcompletemale + $firstsemcompletefemale) + ($firstsemincompletemale + $firstsemincompletefemale)}}</th>
                    </tr> --}}
                </tbody>
            </table>
            <div style="line-height: 10px;">&nbsp;</div>
            <table style="width: 100%; font-size: 9px;" border="1">
                <thead style="text-align: center;">
                    <tr>
                        <th colspan="4" style="text-align: center;">SUMMARY TABLE 2ND SEM</th>
                    </tr>
                    <tr>
                        <th style="width: 35%;">STATUS</th>
                        <th style="width: 20%;">MALE</th>
                        <th style="width: 25%;">FEMALE</th>
                        <th style="width: 20%;">TOTAL</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>COMPLETE</td>
                        <td style="text-align: center;">{{collect($students)->where('gender','male')->where('sem2status','1')->count()}}</td>
                        <td style="text-align: center;">{{collect($students)->where('gender','female')->where('sem2status','1')->count()}}</td>
                        <td style="text-align: center;">{{collect($students)->where('sem2status','1')->count()}}</td>
                    </tr>
                    <tr>
                        <td>INCOMPLETE</td>
                        <td style="text-align: center;">{{collect($students)->where('gender','male')->where('sem2status','0')->count()}}</td>
                        <td style="text-align: center;">{{collect($students)->where('gender','female')->where('sem2status','0')->count()}}</td>
                        <td style="text-align: center;">{{collect($students)->where('sem2status','0')->count()}}</td>
                    </tr>
                    <tr>
                        <td>TOTAL</td>
                        <td style="text-align: center;">{{collect($students)->where('sem2status','0')->where('gender','male')->count()+collect($students)->where('sem2status','1')->where('gender','male')->count()}}</td>
                        <td style="text-align: center;">{{collect($students)->where('sem2status','0')->where('gender','female')->count()+collect($students)->where('sem2status','1')->where('gender','female')->count()}}</td>
                        <td style="text-align: center;">{{collect($students)->where('sem2status','0')->count()+collect($students)->where('sem2status','1')->count()}}</td>
                    </tr>
                    {{-- <tr>
                        <th>COMPLETE</th>
                        <th style="text-align: center;">
                            @php
                                $secondsemcompletemale = 0;
                            @endphp
                            @foreach ($students as $student)
                                @if (strtoupper($student->gender)=='MALE')
                                    @if(collect($student->backsubjects)->where('semid',2)->count() == 0)
                                            @php
                                                $secondsemcompletemale+=1;
                                            @endphp
                                        @endif
                                    @endif
                                @endforeach
                            {{$secondsemcompletemale}}
                        </th>
                        <th style="text-align: center;">
                            @php
                                $secondsemcompletefemale = 0;
                            @endphp
                            @foreach ($students as $student)
                                @if (strtoupper($student->gender)=='FEMALE')
                                    @if(collect($student->backsubjects)->where('semid',2)->count() == 0)
                                            @php
                                                $secondsemcompletefemale+=1;
                                            @endphp
                                        @endif
                                    @endif
                                @endforeach
                            {{$secondsemcompletefemale}}
                        </th>
                        <th style="text-align: center;">{{$secondsemcompletemale + $secondsemcompletefemale}}</th>
                    </tr>
                    <tr>
                        <th>INCOMPLETE</th>
                        <th style="text-align: center;">
                            @php
                                $secondsemincompletemale = 0;
                            @endphp
                            @foreach ($students as $student)
                                @if (strtoupper($student->gender)=='MALE')
                                    @if(collect($student->backsubjects)->where('semid',2)->count() > 0)
                                            @php
                                                $secondsemincompletemale+=1;
                                            @endphp
                                        @endif
                                    @endif
                                @endforeach
                            {{$secondsemincompletemale}}
                        </th>
                        <th style="text-align: center;">
                            @php
                                $secondsemincompletefemale = 0;
                            @endphp
                            @foreach ($students as $student)
                                @if (strtoupper($student->gender)=='FEMALE')
                                    @if(collect($student->backsubjects)->where('semid',2)->count() > 0)
                                            @php
                                                $secondsemincompletefemale+=1;
                                            @endphp
                                        @endif
                                    @endif
                                @endforeach
                            {{$secondsemincompletefemale}}
                        </th>
                        <th style="text-align: center;">{{$secondsemincompletemale + $secondsemincompletefemale}}</th>
                    </tr>
                    <tr>
                        <th>TOTAL</th>
                        <th style="text-align: center;">{{$secondsemcompletemale + $secondsemincompletemale}}</th>
                        <th style="text-align: center;">{{$secondsemcompletefemale + $secondsemincompletefemale}}</th>
                        <th style="text-align: center;">{{($secondsemcompletemale + $secondsemcompletefemale) + ($secondsemincompletemale + $secondsemincompletefemale)}}</th>
                    </tr> --}}
                </tbody>
            </table>
            <div style="line-height: 10px;">&nbsp;</div>
            <table style="width: 100%; font-size: 9px;" border="1">
                <thead style="text-align: center;">
                    <tr>
                        <th colspan="4">SUMMARY TABLE (End of School Year Only)</th>
                    </tr>
                    <tr>
                        <th style="width: 35%;">STATUS</th>
                        <th style="width: 20%;">MALE</th>
                        <th style="width: 25%;">FEMALE</th>
                        <th style="width: 20%;">TOTAL</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th>REGULAR</th>
                        <th style="text-align: center;">
                            @if($sem->id == 2)
                                {{$firstsemcompletemale + $secondsemcompletemale}}
                            @endif
                        </th>
                        <th style="text-align: center;">
                            @if($sem->id == 2)
                                {{$firstsemcompletefemale + $secondsemcompletefemale}}
                            @endif
                        </th>
                        <th style="text-align: center;">
                            @if($sem->id == 2)
                                {{($firstsemcompletemale + $secondsemcompletemale) + ($firstsemcompletefemale + $secondsemcompletefemale)}}
                            @endif
                        </th>
                    </tr>
                    <tr>
                        <th>IRREGULAR</th>
                        <th style="text-align: center;">
                            @if($sem->id == 2)
                                {{$firstsemincompletemale + $secondsemincompletemale}}
                            @endif
                        </th>
                        <th style="text-align: center;">
                            @if($sem->id == 2)
                                {{$firstsemincompletefemale + $secondsemincompletefemale}}
                            @endif
                        </th>
                        <th style="text-align: center;">
                            @if($sem->id == 2)
                                {{($firstsemincompletemale + $secondsemincompletemale) + ($firstsemincompletefemale + $secondsemincompletefemale)}}
                            @endif
                        </th>
                    </tr>
                    <tr>
                        <th>TOTAL</th>
                        <th style="text-align: center;">
                            @if($sem->id == 2)
                                {{($firstsemcompletemale + $secondsemcompletemale) + ($firstsemincompletemale + $secondsemincompletemale)}}
                            @endif
                        </th>
                        <th style="text-align: center;">
                            @if($sem->id == 2)
                                {{($firstsemcompletefemale + $secondsemcompletefemale) + ($firstsemincompletefemale + $secondsemincompletefemale)}}
                            @endif
                        </th>
                        <th style="text-align: center;">
                            @if($sem->id == 2)
                                {{(($firstsemcompletemale + $secondsemcompletemale) + ($firstsemincompletemale + $secondsemincompletemale)) + (($firstsemcompletefemale + $secondsemcompletefemale) + ($firstsemincompletefemale + $secondsemincompletefemale))}}
                            @endif
                        </th>
                    </tr>
                </tbody>
            </table>
            <div style="line-height: 50px;">&nbsp;</div>
            <div style="padding-top:15%;width: 100%; font-size: 10px;">
                Prepared by:
                <br>
                &nbsp;
                <div style="width:100%;border-bottom: 1px solid black; text-align: center;">
                    {{strtoupper($getTeacherName->firstname.' '.$getTeacherName->middlename.' '.$getTeacherName->lastname.' '.$getTeacherName->suffix)}}
                </div>
                <br/>
                <sup style="text-align: center; font-size: 9px; line-height: 10px;">
                    Signature of Class Adviser over Printed Name
                </sup>
                <br>
                <br>
                Certified Correct by:
                <br>
                &nbsp;
                <div style="width:100%;border-bottom: 1px solid black; text-align: center;">
                    {{$signatory_name1}}
                </div>
                <br/>
                <sup style="text-align: center; font-size: 9px; line-height: 10px;">
                    Signature of School Head over Printed Name
                </sup>
                <br>
                <br>
                Reviewed by:
                <br>
                &nbsp;
                <div style="width:100%;border-bottom: 1px solid black; text-align: center;">{{$signatory_name2}}</div>
                <br/>
                <sup style="text-align: center; font-size: 9px; line-height: 10px;">
                    Signature of Division Representative over Printed Name
                </sup>
            </div>
        </td>
    </tr>
    <tr>
        <td colspan="2" style="font-size: 10px;">
            <div style="line-height: 10px;">&nbsp;</div><span id="guidelines"><strong>GUIDELINES:</strong>
                <br><em>This form shall be accomplished after each semester in a school year,  leaving the End of School Year Status Column and Summary Table for End of School Year Status blank/unfilled at the end of the 1st Semester.  These data elements shall be filled up only after the 2nd semester or at the end of the School Year. 
                </em>
            <br>
            <br><strong>INDICATORS:</strong>
                <br><em><strong>End of Semester Status</strong></em>
                <br>
                <span style="padding-left:5%"> 
                    <strong>Complete</strong> - number of learners who completed/satisfied the requirements in all subject areas (with grade of at least 75%)
                </span>
                <br>
                <span style="padding-left:5%"> 
                    <strong>Incomplete</strong> - number of learners who did not meet expectations in one or more subject areas, regardless of number of subjects failed (with grade less than 75%)
                </span>
                <br>
                <span style="padding-left:5%"> 
                    <em>
                        <strong>Note:</strong> Do not include learners who are No Longer in School (<strong>NLS</strong>)
                    </em>
                </span>
                <br>
                <br><em><strong>End of School Year Status</strong></em>
                <br>
                <span style="padding-left:5%"> 
                    <strong>Regular</strong> - number of learners who completed/satisfied requirements in all subject areas  both in the 1st and 2nd semester
                </span>
                <br>
                <span style="padding-left:5%"> 
                    <strong>Irregular</strong> - number of learners who were not able to satisfy/complete requirements in one or both semesters
                </span>
            </span>
        </td>
    </tr>
</table>
    {{--  <table style="width: 100%; vertical-align: top;">
        <tr>
            <td style="width: 70%; vertical-align: top;">
                <table class="studentsTable">
                    <thead>
                        <tr>
                            <th style="width: 5%">No</th>
                            <th style="width: 15%">LRN</th>
                            <th style="width: 30%">LEARNER'S NAME<br>(Last Name, First Name, Name Extension, Middle Name)</sup></th>
                            <th style="width: 30%">BACK SUBJECTS<br>List down subjects where learner obtain a rating below 75%</sup></th>
                            <th style="width: 15%">END OF<br>SEMESTER STATUS<br>Complete/Incomplete</th>
                            <th style="width: 15%">END OF<br>SCHOOL YEAR<br>STATUS<br>(Regular/Irregular)</th>
                        </tr>
                    </thead>
                    <tbody style="vertical-align: top;">
                        <tr>
                            <td colspan="6" style="text-align: none;background-color:lightgrey;padding-left:5px;">male</td>
                        </tr>
                        @if(count($students)>0)
                            @foreach ($students as $student)
                                @if (strtoupper($student->gender)=='MALE')
                                    @php
                                        $countMale+=1;   
                                    @endphp
                                    <tr>
                                        <td class="p-0">{{$countMale}}</td>
                                        <td>{{$student->lrn}}</td>
                                        <td style="text-align: left;">{{$student->lastname.', '.$student->firstname.' '.$student->middlename.' '.$student->suffix}}</td>
                                        <td style="text-align: left; margin: 0px;">
                                            <ol style="text-align: left; margin: 0px;">
                                            @if(collect($student->backsubjects)->where('semid',$sem->id)->count()>0)
                                                @foreach (collect($student->backsubjects)->where('semid',$sem->id) as $backsubjects)
                                                    <li style="text-align: left; margin: 0px;">{{$backsubjects->subjectcode}}</li>
                                                @endforeach
                                            @endif
                                            </ol>
                                        </td>
                                        <td>
                                            @if (collect($student->backsubjects)->where('semid',$sem->id)->count() == 0)
                                                COMPLETE
                                            @else
                                                INCOMPLETE
                                            @endif
                                        </td>
                                        <td>
                                            @if (collect($student->backsubjects)->where('semid',$sem->id)->count() == 0)
                                                REGULAR
                                            @else
                                                IRREGULAR
                                            @endif
                                        </td>
                                    </tr>
                                @endif
                            @endforeach
                        @endif
                        @for($x = $countMale; $x<$init; $x++)
                            <tr>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                        @endfor
                    </tbody>
                </table>
            </td>
            <td style="width: 30%; vertical-align: top;">
                <table class="tableLeft1" >
                    <thead>
                        <tr>
                            <th colspan="4">SUMMARY TABLE 1ST SEM</th>
                        </tr>
                        <tr>
                            <th>STATUS</th>
                            <th>MALE</th>
                            <th>FEMALE</th>
                            <th>TOTAL</th>
                        </tr>
                    </thead>
                    <tbody style="vertical-align: top;">
                        <tr>
                            <th>COMPLETE</th>
                            <th>
                                @php
                                    $firstsemcompletemale = 0;
                                @endphp
                                @foreach ($students as $student)
                                    @if (strtoupper($student->gender)=='MALE')
                                        @if(collect($student->backsubjects)->where('semid',1)->count() == 0)
                                            @php
                                                $firstsemcompletemale+=1;
                                            @endphp
                                        @endif
                                    @endif
                                @endforeach
                                {{$firstsemcompletemale}}
                            </th>
                            <th>
                                @php
                                    $firstsemcompletefemale = 0;
                                @endphp
                                @foreach ($students as $student)
                                    @if (strtoupper($student->gender)=='FEMALE')
                                        @if(collect($student->backsubjects)->where('semid',1)->count() == 0)
                                            @php
                                                $firstsemcompletefemale+=1;
                                            @endphp
                                        @endif
                                    @endif
                                @endforeach
                                {{$firstsemcompletefemale}}
                            </th>
                            <th>{{$firstsemcompletemale + $firstsemcompletefemale}}</th>
                        </tr>
                        <tr>
                            <th>INCOMPLETE</th>
                            <th>
                                @php
                                    $firstsemincompletemale = 0;
                                @endphp
                                @foreach ($students as $student)
                                    @if (strtoupper($student->gender)=='MALE')
                                        @if(collect($student->backsubjects)->where('semid',1)->count() > 0)
                                            @php
                                                $firstsemincompletemale+=1;
                                            @endphp
                                        @endif
                                    @endif
                                @endforeach
                                {{$firstsemincompletemale}}
                            </th>
                            <th>
                                @php
                                    $firstsemincompletefemale = 0;
                                @endphp
                                @foreach ($students as $student)
                                    @if (strtoupper($student->gender)=='FEMALE')
                                        @if(collect($student->backsubjects)->where('semid',1)->count() > 0)
                                            @php
                                                $firstsemincompletefemale+=1;
                                            @endphp
                                        @endif
                                    @endif
                                @endforeach
                                {{$firstsemincompletefemale}}
                            </th>
                            <th>{{$firstsemincompletemale + $firstsemincompletefemale}}</th>
                        </tr>
                        <tr>
                            <th>TOTAL</th>
                            <th>{{$firstsemcompletemale + $firstsemincompletemale}}</th>
                            <th>{{$firstsemcompletefemale + $firstsemincompletefemale}}</th>
                            <th>{{($firstsemcompletemale + $firstsemcompletefemale) + ($firstsemincompletemale + $firstsemincompletefemale)}}</th>
                        </tr>
                    </tbody>
                </table>
                <br>
                <table class="tableLeft1" >
                    <thead>
                        <tr>
                            <th colspan="4">SUMMARY TABLE 2ND SEM</th>
                        </tr>
                        <tr>
                            <th>STATUS</th>
                            <th>MALE</th>
                            <th>FEMALE</th>
                            <th>TOTAL</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th colspan="4">SUMMARY TABLE 2ND SEM</th>
                        </tr>
                        <tr>
                            <th>STATUS</th>
                            <th>MALE</th>
                            <th>FEMALE</th>
                            <th>TOTAL</th>
                        </tr>
                        <tr>
                            <th>COMPLETE</th>
                            <th>
                                @php
                                    $secondsemcompletemale = 0;
                                @endphp
                                @foreach ($students as $student)
                                    @if (strtoupper($student->gender)=='MALE')
                                        @if(collect($student->backsubjects)->where('semid',2)->count() == 0)
                                                @php
                                                    $secondsemcompletemale+=1;
                                                @endphp
                                            @endif
                                        @endif
                                    @endforeach
                                {{$secondsemcompletemale}}
                            </th>
                            <th>
                                @php
                                    $secondsemcompletefemale = 0;
                                @endphp
                                @foreach ($students as $student)
                                    @if (strtoupper($student->gender)=='FEMALE')
                                        @if(collect($student->backsubjects)->where('semid',2)->count() == 0)
                                                @php
                                                    $secondsemcompletefemale+=1;
                                                @endphp
                                            @endif
                                        @endif
                                    @endforeach
                                {{$secondsemcompletefemale}}
                            </th>
                            <th>{{$secondsemcompletemale + $secondsemcompletefemale}}</th>
                        </tr>
                        <tr>
                            <th>INCOMPLETE</th>
                            <th>
                                @php
                                    $secondsemincompletemale = 0;
                                @endphp
                                @foreach ($students as $student)
                                    @if (strtoupper($student->gender)=='MALE')
                                        @if(collect($student->backsubjects)->where('semid',2)->count() > 0)
                                                @php
                                                    $secondsemincompletemale+=1;
                                                @endphp
                                            @endif
                                        @endif
                                    @endforeach
                                {{$secondsemincompletemale}}
                            </th>
                            <th>
                                @php
                                    $secondsemincompletefemale = 0;
                                @endphp
                                @foreach ($students as $student)
                                    @if (strtoupper($student->gender)=='FEMALE')
                                        @if(collect($student->backsubjects)->where('semid',2)->count() > 0)
                                                @php
                                                    $secondsemincompletefemale+=1;
                                                @endphp
                                            @endif
                                        @endif
                                    @endforeach
                                {{$secondsemincompletefemale}}
                            </th>
                            <th>{{$secondsemincompletemale + $secondsemincompletefemale}}</th>
                        </tr>
                        <tr>
                            <th>TOTAL</th>
                            <th>{{$secondsemcompletemale + $secondsemincompletemale}}</th>
                            <th>{{$secondsemcompletefemale + $secondsemincompletefemale}}</th>
                            <th>{{($secondsemcompletemale + $secondsemcompletefemale) + ($secondsemincompletemale + $secondsemincompletefemale)}}</th>
                        </tr>
                    </tbody>
                </table>
                <br>
                <table class="tableLeft1" >
                    <thead>
                        <tr>
                            <th colspan="4">SUMMARY TABLE (End of School Year Only)</th>
                        </tr>
                        <tr>
                            <th>STATUS</th>
                            <th>MALE</th>
                            <th>FEMALE</th>
                            <th>TOTAL</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th>REGULAR</th>
                            <th>
                                @if($sem->id == 2)
                                    {{$firstsemcompletemale + $secondsemcompletemale}}
                                @endif
                            </th>
                            <th>
                                @if($sem->id == 2)
                                    {{$firstsemcompletefemale + $secondsemcompletefemale}}
                                @endif
                            </th>
                            <th>
                                @if($sem->id == 2)
                                    {{($firstsemcompletemale + $secondsemcompletemale) + ($firstsemcompletefemale + $secondsemcompletefemale)}}
                                @endif
                            </th>
                        </tr>
                        <tr>
                            <th>IRREGULAR</th>
                            <th>
                                @if($sem->id == 2)
                                    {{$firstsemincompletemale + $secondsemincompletemale}}
                                @endif
                            </th>
                            <th>
                                @if($sem->id == 2)
                                    {{$firstsemincompletefemale + $secondsemincompletefemale}}
                                @endif
                            </th>
                            <th>
                                @if($sem->id == 2)
                                    {{($firstsemincompletemale + $secondsemincompletemale) + ($firstsemincompletefemale + $secondsemincompletefemale)}}
                                @endif
                            </th>
                        </tr>
                        <tr>
                            <th>TOTAL</th>
                            <th>
                                @if($sem->id == 2)
                                    {{($firstsemcompletemale + $secondsemcompletemale) + ($firstsemincompletemale + $secondsemincompletemale)}}
                                @endif
                            </th>
                            <th>
                                @if($sem->id == 2)
                                    {{($firstsemcompletefemale + $secondsemcompletefemale) + ($firstsemincompletefemale + $secondsemincompletefemale)}}
                                @endif
                            </th>
                            <th>
                                @if($sem->id == 2)
                                    {{(($firstsemcompletemale + $secondsemcompletemale) + ($firstsemincompletemale + $secondsemincompletemale)) + (($firstsemcompletefemale + $secondsemcompletefemale) + ($firstsemincompletefemale + $secondsemincompletefemale))}}
                                @endif
                            </th>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </table>
    <div class="page_break"></div>
    <table style="width: 100%; vertical-align: top;">
        <tr>
            <td style="width: 70%; vertical-align: top;">
                <table class="studentsTable">
                    <thead>
                        <tr>
                            <th style="width: 5%">No</th>
                            <th style="width: 15%">LRN</th>
                            <th style="width: 30%">LEARNER'S NAME<br>(Last Name, First Name, Name Extension, Middle Name)</sup></th>
                            <th style="width: 30%">BACK SUBJECTS<br>List down subjects where learner obtain a rating below 75%</sup></th>
                            <th style="width: 15%">END OF<br>SEMESTER STATUS<br>Complete/Incomplete</th>
                            <th style="width: 15%">END OF<br>SCHOOL YEAR<br>STATUS<br>(Regular/Irregular)</th>
                        </tr>
                    </thead>
                    <tbody style="vertical-align: top;">
                        <tr>
                            <td colspan="6" style="text-align: none;background-color:lightgrey;padding-left:5px;">FEMALE</td>
                        </tr>
                        @if(count($students)>0)
                            @foreach ($students as $student)
                                @if (strtoupper($student->gender)=='FEMALE')
                                    @php
                                        $countFemale+=1;   
                                    @endphp
                                    <tr>
                                        <td class="p-0">{{$countFemale}}</td>
                                        <td>{{$student->lrn}}</td>
                                        <td style="text-align: left;">{{$student->lastname.', '.$student->firstname.' '.$student->middlename.' '.$student->suffix}}</td>
                                        <td style="text-align: left; margin: 0px;">
                                            <ol style="text-align: left; margin: 0px;">
                                            @if(collect($student->backsubjects)->where('semid',$sem->id)->count()>0)
                                                @foreach (collect($student->backsubjects)->where('semid',$sem->id) as $backsubjects)
                                                    <li style="text-align: left; margin: 0px;">{{$backsubjects->subjectcode}}</li>
                                                @endforeach
                                            @endif
                                            </ol>
                                        </td>
                                        <td>
                                            @if (collect($student->backsubjects)->where('semid',$sem->id)->count() == 0)
                                                COMPLETE
                                            @else
                                                INCOMPLETE
                                            @endif
                                        </td>
                                        <td>
                                            @if (collect($student->backsubjects)->where('semid',$sem->id)->count() == 0)
                                                REGULAR
                                            @else
                                                IRREGULAR
                                            @endif
                                        </td>
                                    </tr>
                                @endif
                            @endforeach
                        @endif
                        @for($x = $countFemale; $x<$init; $x++)
                            <tr>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                        @endfor
                    </tbody>
                </table>
            </td>
            <td style="width: 30%; vertical-align: top;">
                <div style="padding-top:15%;width: 100%;">
                    <small>Prepared by:</small>
                    <br>
                    &nbsp;
                    <div style="width:100%;border-bottom: 1px solid;">
                        {{strtoupper($getTeacherName->firstname.' '.$getTeacherName->middlename.' '.$getTeacherName->lastname.' '.$getTeacherName->suffix)}}
                    </div>
                    <small>Signature of Class Adviser over Printed Name</small>
                    <br>
                    <br>
                    <small>Certified Correct by:</small>
                    <br>
                    &nbsp;
                    <div style="width:100%;border-bottom: 1px solid;">
                        {{strtoupper($schoolinfo->authorized)}}
                    </div>
                    <small>Signature of School Head over Printed Name</small>
                    <br>
                    <br>
                    <small>Reviewed by:</small>
                    <br>
                    &nbsp;
                    <div style="width:100%;border-bottom: 1px solid;">{{strtoupper($divisionrep)}}</div>
                    <small>Signature of Division Representative over Printed Name</small>
                </div>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <span id="guidelines">
                    <strong>
                        GUIDELINES:
                    </strong>
                    <br>
                    <em>
                        This form shall be accomplished after each semester in a school year,  leaving the End of School Year Status Column and Summary Table for End of School Year Status blank/unfilled at the end of the 1st Semester.  These data elements shall be filled up only after the 2nd semester or at the end of the School Year. 
                    </em>
                <br>
                <br>
                    <strong>
                        INDICATORS:
                    </strong>
                    <br>
                    <em>
                        <strong>
                            End of Semester Status
                        </strong>
                    </em>
                    <br>
                    <span style="padding-left:5%"> 
                        <strong>Complete</strong> - number of learners who completed/satisfied the requirements in all subject areas (with grade of at least 75%)
                    </span>
                    <br>
                    <span style="padding-left:5%"> 
                        <strong>Incomplete</strong> - number of learners who did not meet expectations in one or more subject areas, regardless of number of subjects failed (with grade less than 75%)
                    </span>
                    <br>
                    <span style="padding-left:5%"> 
                        <em>
                            <strong>Note:</strong> Do not include learners who are No Longer in School (<strong>NLS</strong>)
                        </em>
                    </span>
                    <br>
                    <br>
                    <em>
                        <strong>
                            End of School Year Status
                        </strong>
                    </em>
                    <br>
                    <span style="padding-left:5%"> 
                        <strong>Regular</strong> - number of learners who completed/satisfied requirements in all subject areas  both in the 1st and 2nd semester
                    </span>
                    <br>
                    <span style="padding-left:5%"> 
                        <strong>Irregular</strong> - number of learners who were not able to satisfy/complete requirements in one or both semesters
                    </span>
                </span>
            </td>
        </tr>
    </table> --}}