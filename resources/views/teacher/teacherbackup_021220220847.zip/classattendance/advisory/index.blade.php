
@extends('teacher.layouts.app')

@section('content')
<div>
    <nav class="" aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/home">Home</a></li>
            <li class="active breadcrumb-item">Attendance</li>
            <li class="active breadcrumb-item" aria-current="page">Advisory</li>
        </ol>
    </nav>
</div>
<div class="row">
    {{-- <div class="" --}}
    @if(count($sections) == 0)
    @else
        @foreach($sections as $section)
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-success">
                <div class="inner">
                    <span style="font-size: 15px"><strong>{{$section->numberofstudents}}</strong></span>  Students<br/>
                    <p>{{$section->levelname}} - {{$section->sectionname}}</p>
                    <div class="row">
                        <div class="col-6">
                            <small>Enrolled: {{$section->numberofenrolled}}</small><br/>
                            <small>Late Enrolled: {{$section->numberoflateenrolled}}</small><br/>
                            <small>Transferred In: {{$section->numberoftransferredin}}</small><br/>
                        </div>
                        <div class="col-6">
                            <small>Transferred Out: {{$section->numberoftransferredout}}</small><br/>
                            <small>Dropped Out: {{$section->numberofdroppedout}}</small><br/>
                            <small>Withdrawn: {{$section->numberofwithdraw}}</small>
                        </div>
                    </div>
                </div>
                <div class="icon">
                    <i class="ion ion-bag"></i>
                </div>
                {{-- <form action="/classattendance/viewsection_v1" method="get" class="small-box-footer"> --}}
                {{-- <form action="/classattendance/viewsection_v2" method="get" class="small-box-footer"> --}}
                <form action="/classattendance/viewsection_v3" method="get" class="small-box-footer">
                    @csrf
                    <input type="hidden" name="sectionid" value="{{$section->sectionid}}"/>
                    <input type="hidden" name="levelid" value="{{$section->levelid}}"/>
                    <button type="submit" class=" btn btn-sm btn-block">More info <i class="fas fa-arrow-circle-right"></i></button>
                </form>
                </div>
            </div>
        @endforeach
    @endif

</div>
<script src="{{asset('plugins/jquery/jquery.min.js')}}"></script>
@endsection
