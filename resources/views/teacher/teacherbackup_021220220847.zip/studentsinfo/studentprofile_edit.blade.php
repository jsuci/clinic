
          
        <input type="hidden" class="form-control" id="edit-studentid" hidden>
        <div class="row">
            @if(strtolower(DB::table('schoolinfo')->first()->abbreviation) == 'mac' || strtolower(DB::table('schoolinfo')->first()->abbreviation) == 'sjhsti')
                <div class="col-md-12">
                <div class="profile">
                    <div class="p-2">
                        <div class="">
                            <center>
                                @php
                                    $number = rand(1,3);
                                    if($data->info->gender == null){
                                        $avatar = 'assets/images/avatars/unknown.png';
                                    }
                                    else{
                                        if(strtoupper($data->info->gender) == 'FEMALE'){
                                            $avatar = 'avatar/T(F) '.$number.'.png';
                                        }
                                        else{
                                            $avatar = 'avatar/T(M) '.$number.'.png';
                                        }
                                    }
                                @endphp
                                <div id="upload-demo-i" class="bg-white " style="width:200px;height:200px;">
                                        <img class="elevation-2" src="{{asset($data->info->picurl)}}" id="profilepic" style="width:200px;height:200px;"  onerror="this.onerror = null, this.src='{{asset($avatar)}}'" alt="User Avatar">
                                </div>
                            </center>
                        </div>
                    </div>
                </div>
                <br>
                <center>
                    <a href="#" class="edit-pic-icon" data-toggle="modal" data-target="#edit_profile_pic" style="color: black !important">
                        <i class="fas fa-edit" style="color: black !important"></i> Change profile picture
                    </a>
                </center>
                <br>
                </div>
            @endif
            <div class="col-12">
              <div class="form-group row">
                <label for="inputEmail3" class="col-sm-2 col-form-label">LRN</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" id="edit-lrn" value="{{$data->info->lrn}}" placeholder="LRN">
                </div>
              </div>
            </div>
        </div>
          <div class="row">
              <div class="col-12">
                <div class="form-group row">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">First Name</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="edit-firstname" value="{{$data->info->firstname}}" placeholder="First Name">
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">Middle Name</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="edit-middlename" value="{{$data->info->middlename}}" placeholder="Middle Name">
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">Last Name</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="edit-lastname" value="{{$data->info->lastname}}" placeholder="Last Name">
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">Suffix</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="edit-suffix" value="{{$data->info->suffix}}" placeholder="Suffix">
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">Gender</label>
                  <div class="col-sm-10">
                      <select class="form-control" id="edit-gender">
                        <option value="">Unspecified</option>
                        <option value="MALE" @if(strtolower($data->info->gender) == 'male') selected @endif>MALE</option>
                        <option value="FEMALE" @if(strtolower($data->info->gender) == 'female') selected @endif>FEMALE</option>
                      </select>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">Birth Date</label>
                  <div class="col-sm-10">
                    <input type="date" class="form-control" id="edit-birthdate" value="{{$data->info->dob}}" placeholder="Birth Date">
                  </div>
                </div>
              </div>
          </div>
          <hr/>
          <div class="row">
              <div class="col-4">
                <label>Mother Tongue</label>
                <select class="form-control" id="edit-mothertongue">
                    <option value="">Select Mother Tongue</option>
                    @foreach($data->mothertongues as $mothertongue)
                        <option value="{{$mothertongue->id}}" @if($data->info->mtid == $mothertongue->id) selected @endif>{{$mothertongue->mtname}}</option>
                    @endforeach
                </select>
              </div>
              <div class="col-4">
                <label>IP</label>
                <select class="form-control" id="edit-ethnicgroup">
                    <option value="">Select Ethnic Group</option>
                    @foreach($data->ethnicgroups as $ethnicgroup)
                        <option value="{{$ethnicgroup->id}}" @if($data->info->egid == $mothertongue->id) selected @endif>{{$ethnicgroup->egname}}</option>
                    @endforeach
                </select>
              </div>
              <div class="col-4">
                <label>Religion</label>
                <select class="form-control" id="edit-religion">
                    <option value="">Select Religion</option>
                    @foreach($data->religions as $religion)
                        <option value="{{$religion->id}}"@if($data->info->religionid == $religion->id) selected @endif>{{$religion->religionname}}</option>
                    @endforeach
                </select>
              </div>
          </div>
          <hr/>
          <div class="row">
              <div class="col-12">
                    <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">House #/Street/Sitio/Purok</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="edit-street" value="{{$data->info->street}}" placeholder="House #/Street/Sitio/Purok">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Barangay</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="edit-barangay" value="{{$data->info->barangay}}" placeholder="Barangay">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Municipality/City</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="edit-city" value="{{$data->info->city}}" placeholder="Municipality/City">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Province</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="edit-province" value="{{$data->info->province}}" placeholder="Province">
                        </div>
                    </div>
              </div>
          </div>
          <hr/>
          <div class="row">
              <div class="col-12">
                    <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Father's Name</label>
                        <div class="col-sm-5">
                            <input type="text" class="form-control" id="edit-fathername" value="{{$data->info->fathername}}" placeholder="Father's Name">
                        </div>
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Mobile #</label>
                        <div class="col-sm-3">
                            <input type="text" class="form-control" id="edit-fathermobilenum" value="{{$data->info->fcontactno}}" placeholder="Mobile #">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Mother's Maiden Name</label>
                        <div class="col-sm-5">
                            <input type="text" class="form-control" id="edit-mothername" value="{{$data->info->mothername}}" placeholder="Mother's Maiden Name">
                        </div>
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Mobile #</label>
                        <div class="col-sm-3">
                            <input type="text" class="form-control" id="edit-mothermobilenum" value="{{$data->info->mcontactno}}" placeholder="Mobile #">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Guardian Name</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="edit-guardianname" value="{{$data->info->guardianname}}" placeholder="Guardian Name">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Relationship</label>
                        <div class="col-sm-5">
                            <input type="text" class="form-control" id="edit-guardianrelationship" value="{{$data->info->guardianrelation}}" placeholder="Relationship">
                        </div>
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Mobile #</label>
                        <div class="col-sm-3">
                            <input type="text" class="form-control" id="edit-guardianmobilenum" value="{{$data->info->gcontactno}}" placeholder="Mobile #">
                        </div>
                    </div>
              </div>
          </div>