
@php
$totalmale          = 0;
$totalfemale        = 0;
$totalunspecified   = 0;
if(count($students) > 0)
{
    foreach($students as $student)
    {
        if(strtolower($student->gender) == 'female'){
            $totalfemale += 1;
        }
        elseif(strtolower($student->gender) == 'male'){
            $totalmale += 1;
        }else{
            
            $totalunspecified += 1;
        }
    }
}
$quarters = array();
if(strtolower(Db::table('schoolinfo')->first()->abbreviation) == 'sait')
{
    $quarters = DB::table('quarter_setup')
        ->where('deleted','0')
        ->get();
}
elseif(strtolower(DB::table('schoolinfo')->first()->abbreviation) == 'gbbc')
{
    $quarters = DB::table('quarter_setup')
        ->where('id',$setupid)
        ->where('deleted','0')
        ->where('isactive','1')
        ->where('acadprogid',$acadprogid)
        ->get();
}
elseif(strtolower(DB::table('schoolinfo')->first()->abbreviation) == 'hchs')
{
    $quarters = DB::table('quarter_setup')
        ->where('deleted','0')
        ->where('isactive','1')
        ->where('acadprogid',$acadprogid)
        ->get();
}
     
     
$avatar = 'assets/images/avatars/unknown.jpg';               
@endphp
<div class="row mb-2">
    <div class="col-md-12">
        <button type="button" class="btn btn-sm btn-warning" id="totalmale">Male : {{$totalmale}}</button>
        <button type="button" class="btn btn-sm btn-warning" id="totalfemale">Female : {{$totalfemale}}</button>
        <button type="button" class="btn btn-sm btn-warning" id="totalunspecified">Unspecified : {{$totalunspecified}}</button>
        <button type="button" class="btn btn-sm btn-warning" id="totalstudent">Total Number of Students : {{count($students)}}</button>

    </div>
</div>
<div class="row mb-2">
    <div class="col-md-6">
        <input class="form-control" id="input-search" placeholder="Search student" />
    </div>
    <div class="col-md-6 text-right">
        
    </div>
</div>
<div class="row">
    <div class="col-md-6">
        <label>MALE</label>
        @if(count($students) > 0)
            @foreach($students as $student)
                @if(strtolower($student->gender) == 'male')
                    <!-- small box -->
                    
                        
            <div class="card card-primary collapsed-card card-student" style="border: none; box-shadow: 0 .125rem .25rem rgba(0,0,0,.075)!important;
        }"  data-string="{{$student->lastname}}, {{$student->firstname}}<">
                <div class="card-header ">
                  <h3 class="card-title">
                      <div class="row">
                          <div class="col-3">
                            <img src="{{asset($student->picurl)}}"   onerror="this.onerror = null, this.src='{{asset($avatar)}}'" width="70px">
                          </div>
                          <div class="col-9" style="font-size: 13px;">
                            <div class="row">
                                <div class="col-12">
                                    <span data-studid="{{$student->id}}"><strong>{{$student->lastname}}</strong>, {{$student->firstname}}</span>
                                </div>
                                <div class="col-8">
                                    <span class="badge badge-light border">{{$student->description}}</span>
                                    <span class="badge badge-light border">{{$student->moldesc}}</span>
                                </div>
                                <div class="col-4 text-right">
                                    <span class="text-muted">{{$student->sid}}</span>
                                </div>
                            </div>
                            <div class="card-tools mt-2">
                              <button type="button"  class="btn btn-sm btn-default toModal mb-2" id="{{$student->id}}"  data-toggle="modal" data-target="#studentmodal{{$student->id}}">View Info</button>
                              @if(strtolower(Db::table('schoolinfo')->first()->abbreviation) == 'sait' || strtolower(DB::table('schoolinfo')->first()->abbreviation) == 'hchs')
                                            <button type="button" class="btn btn-tool text-secondary" data-card-widget="collapse"><i class="fas fa-plus"></i> Permit Details
                                            </button>
                            @elseif(strtolower(Db::table('schoolinfo')->first()->abbreviation) == 'gbbc' )
                                @foreach ($quarters as $quarter)
                                <button type="button" class="btn btn-sm btn-default text-bold getpermitstatus" data-studid="{{$student->id}}">{{$quarter->monthname}} : <span class="quarterpermit{{$quarter->id}}"></span></button>
                                @endforeach
                            @endif
                            </div>
                          </div>
                      </div>
                  </h3>
  
                  <!-- /.card-tools -->
                </div>
                <!-- /.card-header -->
                @if(strtolower(Db::table('schoolinfo')->first()->abbreviation) == 'sait')
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12 getpermitstatus" data-studid="{{$student->id}}">
                                <table class="table">
                                    <tr  style="font-size: 10px;">
                                        @foreach ($quarters as $quarter)
                                        <th class="text-center p-0">{{$quarter->description}}</th>
                                        @endforeach
                                    </tr>
                                    <tr>
                                        @foreach ($quarters as $quarter)
                                            <td class="quarterpermit{{$quarter->id}} p-0 text-center" style="font-size: 10px;">
    
                                            </td>
                                        @endforeach
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                    @elseif(strtolower(Db::table('schoolinfo')->first()->abbreviation) == 'gbbc' || strtolower(DB::table('schoolinfo')->first()->abbreviation) == 'hchs')
                    <div class="card-body p-0">
                        <div class="row">
                        <div class="col-md-12 getpermitstatus pr-2 pl-2" data-studid="{{$student->id}}">
                            <table class="table ml-2">
                                    @foreach ($quarters as $quarter)
                                    <tr>
                                        <th class="text-left p-0">{{$quarter->description}}</th>
                                        <td class="quarterpermit{{$quarter->id}} p-0 text-center"></td>
                                    </tr>
                                    @endforeach
                                </table>
                            </div>
                        </div>
                    </div>
                @endif

                <!-- /.card-body -->
              </div>
                    <div class="modal fade studentmodal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" id="studentmodal{{$student->id}}">
                        <div class="modal-dialog modal-md">
                            <div class="modal-content">
                                <div class="modal-header bg-info">
                                    <h5 class="modal-title" id="exampleModalLongTitle">Profile</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <div class="card-header p-0 border-bottom-0">
                                        <ul class="nav nav-tabs" id="custom-tabs-three-tab" role="tablist">
                                            <li class="nav-item">
                                                <a class="nav-link active" id="studentProfile-tab{{$student->id}}" data-toggle="pill" href="#studentProfile{{$student->id}}" role="tab" aria-controls="studentProfile{{$student->id}}" aria-selected="false">Profile</a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" id="parents-tab{{$student->id}}" data-toggle="pill" href="#parents{{$student->id}}" role="tab" aria-controls="parents{{$student->id}}" aria-selected="false">Parents/Guardian</a>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="card-body">
                                        <div class="tab-content" id="custom-tabs-three-tabContent{{$student->id}}">
                                            <div class="tab-pane fade show active" id="studentProfile{{$student->id}}" role="tabpanel" aria-labelledby="studentProfile-tab{{$student->id}}">
                                                <p><span style="width: 30%">SID:</span> <strong>{{$student->sid}}</strong></p>
                                                <p><span style="width: 30%">LRN:</span> <strong>{{$student->lrn}}</strong></p>
                                                <p>Full name: <strong>{{$student->firstname}} {{$student->middlename}} {{$student->lastname}} {{$student->suffix}}</strong></p> 
                                                <p>Date of Birth: <strong>{{$student->dob}}</strong></p>
                                                <p>Gender: <strong>{{$student->gender}}</strong></p>
                                                <p>Contact No.: <strong>{{$student->contactno}}</strong></p>
                                                <p>Home Address: <strong>{{$student->street}}, {{$student->barangay}} {{$student->city}} {{$student->province}}</strong></p>
                                                <hr style="border:1px solid #ddd">
                                                <p>Blood Type: <strong>{{$student->bloodtype}}</strong></p>
                                                <p>Allergies: <strong>{{$student->allergy}}</strong></p>
                                            </div>
                                            <div class="tab-pane fade" id="parents{{$student->id}}" role="tabpanel" aria-labelledby="parents-tab{{$student->id}}">
                                                <em>In case of emergency, contact:</em>
                                                <hr style="border:1px solid #ddd">
                                                <p>Mother's Name: <strong>{{$student->mothername}}</strong></p>
                                                <p>Contact No.: <strong>{{$student->mcontactno}}</strong></p>
                                                <p>Occupation: <strong>{{$student->moccupation}}</strong></p>
                                                <hr style="border:1px solid #ddd">
                                                <p>Father's Name: <strong>{{$student->fathername}}</strong></p>
                                                <p>Contact No.: <strong>{{$student->fcontactno}}</strong></p>
                                                <p>Occupation: <strong>{{$student->foccupation}}</strong></p>
                                                <hr style="border:1px solid #ddd">
                                                <p>Guardian's Name: <strong>{{$student->guardianname}}</strong></p>
                                                <p>Contact No.: <strong>{{$student->gcontactno}}</strong></p>
                                                <p>Relation: <strong>{{$student->guardianrelation}}</strong></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer justify-content-between">
                                    <button type="button" class="btn btn-secondary btn-view-close" data-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>
                @endif

            @endforeach
        @endif
    </div>
    <div class="col-md-6">
        <label>FEMALE</label>
        @if(count($students) > 0)
            @foreach($students as $student)
                @if(strtolower($student->gender) == 'female')
                        
                <div class="card card-primary collapsed-card card-student" style="border: none; box-shadow: 0 .125rem .25rem rgba(0,0,0,.075)!important;
            }"  data-string="{{$student->lastname}}, {{$student->firstname}}<">
                    <div class="card-header ">
                      <h3 class="card-title">
                          <div class="row">
                              <div class="col-3">
                                <img src="{{asset($student->picurl)}}"   onerror="this.onerror = null, this.src='{{asset($avatar)}}'" width="70px">
                              </div>
                              <div class="col-9" style="font-size: 13px;">
                                <div class="row">
                                    <div class="col-12">
                                        <span data-studid="{{$student->id}}"><strong>{{$student->lastname}}</strong>, {{$student->firstname}}</span>
                                    </div>
                                    <div class="col-8">
                                        <span class="badge badge-light border">{{$student->description}}</span>
                                        <span class="badge badge-light border">{{$student->moldesc}}</span>
                                    </div>
                                    <div class="col-4 text-right">
                                        <span class="text-muted">{{$student->sid}}</span>
                                    </div>
                                </div>
                                <div class="card-tools mt-2">
                                    <button type="button"  class="btn btn-sm btn-default toModal mb-2" id="{{$student->id}}"  data-toggle="modal" data-target="#studentmodal{{$student->id}}">View Info</button>
                                    @if(strtolower(Db::table('schoolinfo')->first()->abbreviation) == 'sait' || strtolower(DB::table('schoolinfo')->first()->abbreviation) == 'hchs')
                                                  <button type="button" class="btn btn-tool text-secondary" data-card-widget="collapse"><i class="fas fa-plus"></i> Permit Details
                                                  </button>
                                  @elseif(strtolower(Db::table('schoolinfo')->first()->abbreviation) == 'gbbc')
                                      @foreach ($quarters as $quarter)
                                      <button type="button" class="btn btn-sm btn-default text-bold getpermitstatus" data-studid="{{$student->id}}">{{$quarter->monthname}} : <span class="quarterpermit{{$quarter->id}}"></span></button>
                                      @endforeach
                                  @endif
                                </div>
                              </div>
                          </div>
                      </h3>
      
                      <!-- /.card-tools -->
                    </div>
                    <!-- /.card-header -->
                    @if(strtolower(Db::table('schoolinfo')->first()->abbreviation) == 'sait')
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12 getpermitstatus" data-studid="{{$student->id}}">
                                <table class="table">
                                    <tr  style="font-size: 10px;">
                                        @foreach ($quarters as $quarter)
                                        <th class="text-center p-0">{{$quarter->description}}</th>
                                        @endforeach
                                    </tr>
                                    <tr>
                                        @foreach ($quarters as $quarter)
                                            <td class="quarterpermit{{$quarter->id}} p-0 text-center" style="font-size: 10px;">
    
                                            </td>
                                        @endforeach
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                    @elseif(strtolower(Db::table('schoolinfo')->first()->abbreviation) == 'gbbc' || strtolower(DB::table('schoolinfo')->first()->abbreviation) == 'hchs')
                    <div class="card-body p-0">
                        <div class="row">
                        <div class="col-md-12 getpermitstatus pr-2 pl-2" data-studid="{{$student->id}}">
                            <table class="table ml-2">
                                    @foreach ($quarters as $quarter)
                                    <tr>
                                        <th class="text-left p-0">{{$quarter->description}}</th>
                                        <td class="quarterpermit{{$quarter->id}} p-0 text-center"></td>
                                    </tr>
                                    @endforeach
                                </table>
                            </div>
                        </div>
                    </div>
                    @endif
    
                    <!-- /.card-body -->
                  </div>
                    <div class="modal fade studentmodal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" id="studentmodal{{$student->id}}">
                        <div class="modal-dialog modal-md">
                            <div class="modal-content">
                                <div class="modal-header bg-info">
                                    <h5 class="modal-title" id="exampleModalLongTitle">Profile</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <div class="card-header p-0 border-bottom-0">
                                        <ul class="nav nav-tabs" id="custom-tabs-three-tab" role="tablist">
                                            <li class="nav-item">
                                                <a class="nav-link" id="studentProfile-tab{{$student->id}}" data-toggle="pill" href="#studentProfile{{$student->id}}" role="tab" aria-controls="studentProfile{{$student->id}}" aria-selected="false">Profile</a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" id="parents-tab{{$student->id}}" data-toggle="pill" href="#parents{{$student->id}}" role="tab" aria-controls="parents{{$student->id}}" aria-selected="false">Parents/Guardian</a>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="card-body">
                                        <div class="tab-content" id="custom-tabs-three-tabContent{{$student->id}}">
                                            <div class="tab-pane fade show active" id="studentProfile{{$student->id}}" role="tabpanel" aria-labelledby="studentProfile-tab{{$student->id}}">
                                                <p><span style="width: 30%">SID:</span> <strong>{{$student->sid}}</strong></p>
                                                <p><span style="width: 30%">LRN:</span> <strong>{{$student->lrn}}</strong></p>
                                                <p>Full name: <strong>{{$student->firstname}} {{$student->middlename}} {{$student->lastname}} {{$student->suffix}}</strong></p> 
                                                <p>Date of Birth: <strong>{{$student->dob}}</strong></p>
                                                <p>Gender: <strong>{{$student->gender}}</strong></p>
                                                <p>Contact No.: <strong>{{$student->contactno}}</strong></p>
                                                <p>Home Address: <strong>{{$student->street}}, {{$student->barangay}} {{$student->city}} {{$student->province}}</strong></p>
                                                <hr style="border:1px solid #ddd">
                                                <p>Blood Type: <strong>{{$student->bloodtype}}</strong></p>
                                                <p>Allergies: <strong>{{$student->allergy}}</strong></p>
                                            </div>
                                            <div class="tab-pane fade" id="parents{{$student->id}}" role="tabpanel" aria-labelledby="parents-tab{{$student->id}}">
                                                <em>In case of emergency, contact:</em>
                                                <hr style="border:1px solid #ddd">
                                                <p>Mother's Name: <strong>{{$student->mothername}}</strong></p>
                                                <p>Contact No.: <strong>{{$student->mcontactno}}</strong></p>
                                                <p>Occupation: <strong>{{$student->moccupation}}</strong></p>
                                                <hr style="border:1px solid #ddd">
                                                <p>Father's Name: <strong>{{$student->fathername}}</strong></p>
                                                <p>Contact No.: <strong>{{$student->fcontactno}}</strong></p>
                                                <p>Occupation: <strong>{{$student->foccupation}}</strong></p>
                                                <hr style="border:1px solid #ddd">
                                                <p>Guardian's Name: <strong>{{$student->guardianname}}</strong></p>
                                                <p>Contact No.: <strong>{{$student->gcontactno}}</strong></p>
                                                <p>Relation: <strong>{{$student->guardianrelation}}</strong></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer justify-content-between">
                                    <button type="button" class="btn btn-secondary btn-view-close" data-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>
                @endif

            @endforeach
        @endif
    </div>
</div>
<div class="modal fade" id="modal-edit-view">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Edit student information</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="resultscontainer">
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        {{-- <button type="button" class="btn btn-primary" id="btn-edit-submit" disabled>We're still working on this page!</button> --}}
        <button type="button" class="btn btn-primary" id="btn-edit-submit">Save changes</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>

<script>
    $(document).ready(function(){
        @if(strtolower(DB::table('schoolinfo')->first()->abbreviation) == 'sait' )
            @php
                $quarters = DB::table('quarter_setup')
                    ->where('deleted','0')
                    ->get();
            @endphp
            @if(count($quarters)>0)
                    @foreach($quarters as $quarter)
                        $('.getpermitstatus').each(function(){
                            var thiscontainer = $(this).find('.quarterpermit{{$quarter->id}}');
                            var studid  = $(this).attr('data-studid');
                            var quarterid = '{{$quarter->id}}';
                            $.ajax({
                                url: '{{route('api_exampermit_flag')}}',
                                type: 'GET',
                                dataType: '',
                                data: {
                                    studid:studid,
                                    qid:'{{$quarter->id}}'
                                },
                                success:function(data)
                                {
                                    if(data == 'allowed')
                                    {
                                        thiscontainer.append(
                                            '<span class="badge badge-success">Permitted</span>'
                                        )
                                    }else{
                                        thiscontainer.append(
                                            '<span class="badge badge-secondary">With Balance</span>'
                                        )
                                    }
                                }
                            }); 
                        })
                    @endforeach
                @endif
        @elseif(strtolower(DB::table('schoolinfo')->first()->abbreviation) == 'gbbc' || strtolower(Db::table('schoolinfo')->first()->abbreviation) == 'hchs')
            // Swal.fire({
            //     title: 'Loading students...',
            //     allowOutsideClick: false,
            //     closeOnClickOutside: false,
            //     onBeforeOpen: () => {
            //         Swal.showLoading()
            //     }
            // }) 
            @php
            if(strtolower(DB::table('schoolinfo')->first()->abbreviation) == 'gbbc')
            {
                $quarters = DB::table('quarter_setup')
                    ->where('id',$setupid)
                    ->where('deleted','0')
                    ->where('isactive','1')
                    ->where('acadprogid',$acadprogid)
                    ->get();
            }else{
                $quarters = DB::table('quarter_setup')
                    ->where('deleted','0')
                    ->where('isactive','1')
                    ->where('acadprogid',$acadprogid)
                    ->get();
            }
            @endphp
            @if(count($quarters)>0)
                @foreach($quarters as $quarter)
                    $('.getpermitstatus').each(function(){
                        var thiscontainer = $(this).find('.quarterpermit{{$quarter->id}}');
                        var studid  = $(this).attr('data-studid');
                        var quarterid = '{{$quarter->id}}';
                        $.ajax({
                            url: '{{route('api_exampermit_flag')}}',
                            type: 'GET',
                            data: {
                                studid:studid,
                                qid:'{{$quarter->id}}'
                            },
                            success:function(data)
                            {
                                console.log(thiscontainer)
                                if(data == 'allowed')
                                {
                                    thiscontainer.append(
                                        '<span class="badge badge-success">Permitted</span>'
                                    )
                                }else{
                                    thiscontainer.append(
                                        '<span class="badge badge-secondary">With Balance</span>'
                                    )
                                }
                                //return - allowed or not_allowed
                            }
                        }); 
                    })
                @endforeach
            @endif
        @endif
    })
</script>