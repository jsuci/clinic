@extends('teacher.layouts.app')

@section('headerjavascript')
    <link rel="stylesheet" href="{{ asset('plugins/select2/css/select2.min.css') }}">
    <link rel="stylesheet" href="{{ asset('plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css') }}">
    <link rel="stylesheet" href="{{ asset('plugins/datatables-bs4/css/dataTables.bootstrap4.css') }}">
    <style>
        /* div.dataTables_wrapper {
            width: 800px;
            margin: 0 auto;
        } */
        /* .subj_tr td{
            vertical-align: middle!important;
            cursor: pointer;
        }
        .stud_subj_tr td{
            vertical-align: middle!important;
            cursor: pointer;
        } */
        .select2-container .select2-selection--single {
            height: 40px;
        }
    </style>
@endsection

@section('content')

    <div class="modal fade" id="grade_info" style="display: none;" aria-hidden="true" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary">
                    <h4 class="modal-title">Student Grade Detail</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>   
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-4 form-group">
                            <label for="">Student</label>
                            <input class="form-control form-control-sm" readonly id="student_name_modal">
                        </div>
                    </div>
                   
                    <div class="row mt-3 border-1 p-0">
                        <div class="col-md-12 table-responsive" style="height: 450px">
                            <table class="table table-head-fixed table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th width="80%">Subject</th>
                                        <th width="10%" class="text-center">Grade</th>
                                        <th width="10%" class="text-center">Status</th>
                                    </tr>
                                </thead>
                                <tbody id="grade_holder">

                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="row mt-2">
                        <div class="col-md-6"></div>
                        <div class="col-md-3">
                            <button class="btn btn-info btn-block btn-sm" id="post_grade" >POST ALL GRADES</button>
                        </div>
                        <div class="col-md-3">
                            <button class="btn btn-danger btn-block  btn-sm" id="unpost_grade" >UNPOST ALL GRADES</button>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>


    <div class="modal fade" id="subject_list" style="display: none;" aria-hidden="true" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary">
                    <h4 class="modal-title">SUBJECT LIST</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>   
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-4 form-group">
                            <label for="">Grade Level</label>
                            <input class="form-control form-control-sm" readonly id="sl_grade_level">
                        </div>
                        <div class="col-md-4 form-group">
                            <label for="">Section</label>
                            <input class="form-control form-control-sm" readonly id="sl_section">
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-md-12 table-responsive" style="height: 368px">
                            <table class="table table-head-fixed table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th width="15%">Code</th>
                                        <th width="70%">Title</th>
                                        <th width="15%" class="text-center">Status</th>
                                    </tr>
                                </thead>
                                <tbody id="subject_holder">

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="subject_option" style="display: none;" aria-hidden="true" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header bg-success p-2">
                    {{-- <h4 class="modal-title">&nbsp;</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>    --}}
                </div>
                <div class="modal-body">
                    <div class="row">
                        <button class="btn btn-info col-md-12" id="subj_post">POST SUBJECT</button>
                    </div>
                    <div class="row mt-2">
                        <button class="btn btn-danger col-md-12" id="subj_unpost">UNPOST SUBJECT</button>
                    </div>
                     <hr>
                    <div class="row">
                        <button class="btn btn-warning col-md-12" id="subj_pending">ADD SUBJECT TO PENDING</button>
                    </div>
                    <div class="row mt-2">
                        <button class="btn btn-primary col-md-12" id="subj_approve">APPROVE SUBJECT</button>
                    </div>
                    <hr>
                    <div class="row ">
                        <button class="btn btn-danger col-md-12" data-dismiss="modal">CLOSE</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="student_subject_option" style="display: none;" aria-hidden="true" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header bg-success p-2">
                    {{-- <h4 class="modal-title">&nbsp;</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>    --}}
                </div>
                <div class="modal-body">
                    <div class="row">
                        <button class="btn btn-info col-md-12" id="stud_subj_post">POST SUBJECT</button>
                    </div>
                    <div class="row mt-2">
                        <button class="btn btn-danger col-md-12" id="stud_subj_unpost">UNPOST SUBJECT</button>
                    </div>
                     <hr>
                    <div class="row">
                        <button class="btn btn-warning col-md-12" id="stud_subj_pending">ADD SUBJECT TO PENDING</button>
                    </div>
                    {{-- <div class="row mt-2">
                        <button class="btn btn-primary col-md-12" id="stud_subj_approve">APPROVE SUBJECT</button>
                    </div> --}}
                    <hr>
                    <div class="row ">
                        <button class="btn btn-danger col-md-12" data-dismiss="modal">CLOSE</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="proccess_count_modal" style="display: none;" aria-hidden="true" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header bg-success p-2">
                    <h4 class="modal-title" id="proccess_message"></h4>
                </div>
                <div class="modal-body">
                    <div class="progress">
                        <div class="progress-bar bg-primary progress-bar-striped" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 0%" id="progress_bar">
                        </div>
                    </div>
                    <p class="mb-1"><code id="percentage">0%</code></p>
                    <div class="text-right">
                        <button type="button" class="btn btn-primary btn-sm" data-dismiss="modal" id="proccess_done" hidden>Done</button>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>


    <section class="content-header">
        <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
            <h4 class="text-warning" style="text-shadow: 1px 1px 1px #000000"><i class="fas fa-user-graduate nav-icon"></i> GRADE SUMMARY</h4>
            </div>
            <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="/home">Home</a></li>
                <li class="breadcrumb-item"><a href="/principalPortalSchedule">Grade Summary</a></li>
            </ol>
            </div>
        </div>
        </div>
    </section>
    <section class="content">
        <div class="container-fluid">
            <div class="row ">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header bg-primary p-1">
                            <div class="row">
                            </div>
                        </div>
                        <div class="card-body" >
                            <div class="row">
                                <div class="col-md-3">
                                    <label for="">SCHOOL YEAR</label>
                                    <select name="syid" id="syid" class="form-control select2">
                                        @foreach(DB::table('sy')->select('id','sydesc','isactive')->get() as $item)
                                            @if($item->isactive == 1)
                                                <option value="{{$item->id}}" selected="selected">{{$item->sydesc}}</option>
                                            @else
                                                <option value="{{$item->id}}">{{$item->sydesc}}</option>
                                            @endif
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label for="">SEMESTER</label>
                                    <select name="semester" id="semester" class="form-control select2">
                                        @foreach(DB::table('semester')->select('id','semester','isactive')->get() as $item)
                                            @if($item->isactive == 1)
                                                <option value="{{$item->id}}" selected="selected">{{$item->semester}}</option>
                                            @else
                                                <option value="{{$item->id}}">{{$item->semester}}</option>
                                            @endif
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="">Grade Level</label>
                                        @php
                                            $allsections = array();
                                        @endphp
                                        <select class="form-control select2" id="gradelevel">
                                            <option selected value="" >SELECT GRADE LEVEL</option>
                                        </select>
                                    </div>

                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="">Section</label>
                                        <select name="section" id="section" class="form-control select2">
                                            <option selected value="" >SELECT SECTION</option>
                                        </select>
                                    </div>
                                </div>
                                
                            </div>
                            {{-- <hr> --}}
                            {{-- <div class="row master_sheet_option">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="">Grade Level</label>
                                        @php
                                            $allsections = array();
                                        @endphp
                                        <select class="form-control select2" id="gradelevel">
                                            <option selected value="" >SELECT GRADE LEVEL</option>
                                        </select>
                                    </div>

                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="">Section</label>
                                        <select name="section" id="section" class="form-control select2">
                                            <option selected value="" >SELECT SECTION</option>
                                        </select>
                                    </div>
                                </div>

                            <div class="row grading_sheet_option" hidden="hidden">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="">Grade Level</label>
                                        @php
                                            $allsections = array();
                                        @endphp
                                        <select class="form-control select2" id="grading_sheet_gradelevel">
                                            <option selected value="" >SELECT GRADE LEVEL</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="">Section</label>
                                        <select name="grading_sheet_section" id="grading_sheet_section" class="form-control select2">
                                            <option selected value="" >SELECT SECTION</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row grading_sheet_option" hidden="hidden">
                                <div class="col-md-2">
                                </div>
                                <div class="col-md-2">
                                    <button class="btn btn-primary btn-block btn-sm" id="grading_sheet_print"> <i class="fas fa-print"></i></i> PRINT</button>
                                </div>
                            </div> --}}
                          

                            <div class="row sf9_sheet_option" hidden="hiddens">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="">Grade Level</label>
                                        @php
                                            $allsections = array();
                                        @endphp
                                        <select class="form-control select2" id="sf9_sheet_gradelevel">
                                            <option selected value="" >SELECT GRADE LEVEL</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="">Section</label>
                                        <select name="section" id="sf9_sheet_section" class="form-control select2">
                                            <option selected value="" >SELECT SECTION</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                          
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header p-1 bg-primary">
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-3"><h5 class="mb-0 pt-1">FINAL GRADE</h5></div>
                                <div class="col-md-1"></div>
                                <div class="col-md-4">
                                   
                                </div>
                                <div class="col-md-4">
                                    <button class="btn btn-primary btn-block" id="sf9_sheet_filter">VIEW FINAL GRADE</button>
                                </div>
                            </div>
                            <hr>
                            <table class="table table-bordered table-head-fixed nowrap display table-sm p-0" id="sf9_sheet_table_list" style="width:100%" >
                                <thead>
                                    <th>Student Name</th>
                                    {{-- <th class="text-center">Q1</th>
                                    <th class="text-center">Q2</th>
                                    <th class="text-center for_gs">Q3</th>
                                    <th class="text-center for_gs">Q4</th> --}}
                                    <th class="text-center">Gen. Ave.</th>
                                    <th class="text-center">REMARK</th>
                                </thead>
                            </table>
                            <hr>
                            <div class="row">
                                  <div class="col-md-4 form-group">
                                        <select name="sf9_student_name" id="sf9_student_name" class="select2 form-control">
                                                <option selected value="" >SELECT STUDENT</option>
                                        </select>
                                  </div>
                                  <div class="col-md-4">
                                        <button class="btn btn-primary" id="sf9_report_button" disabled="disabled">VIEW SF9 REPORT</button>
                                  </div>
                            </div>
                            <div class="row mt-2">

                              <table class="mb-0 table table-bordered" style="min-width:330px">
                                    <thead>
                                        <tr>

                                            <td class="p-1 align-middle text-center" rowspan="2" width="55%"><small>SUBJECTS</small></td>
                                            <td class="p-1 align-middle pr" align="center" colspan="4" width="20%"><small>PERIODIC RATINGS</small></td>
                                            <td class="p-1 align-middle" align="center" rowspan="2" width="10%"><small>Final<br>Rating</small></td>
                                            <td class="p-1 align-middle" align="center" rowspan="2" width="15%"><small>Action<br>Taken</small></td>
            
                                        </tr>
                                        <tr align="center">
                                          <td class="p-1 "><small>1</small></td>
                                          <td class="p-1"><small>2</small></td>
                                          <td class="p-1 for_gs"><small>3</small></td>
                                          <td class="p-1 for_gs"><small>4</small></td>
                                        </tr>
                                    </thead>
                                    <tbody id="sf9_grade_table">
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header p-1 bg-primary">
                        </div>
                        <div class="card-body">
                              <div class="row">
                                    <div class="col-md-2"><h5 class="mb-0 pt-1">Master Sheet</h5></div>
                                    <div class="col-md-3">
                                          <button class="btn btn-primary btn-block btn-success" id="view_subjects" disabled="disabled">VIEW SUBJECTS</button>
                                    </div>
                                    <div class="col-md-3">
                                          <select name="quarter" id="quarter" class="form-control select2 ">
                                                <option selected value="" >SELECT QUARTER</option>
                                                <option value="1">1ST QUARTER</option>
                                                <option value="2">2ND QUARTER</option>
                                                <option value="3">3RD QUARTER</option>
                                                <option value="4">4TH QUARTER</option>
                                          </select>
                                    </div>
                                    <div class="col-md-4">
                                          <button class="btn btn-primary btn-block" id="filter" >VIEW MASTER SHEET</button>
                                    </div>
                              </div>
                              <hr>
                              <table class="table table-bordered table-head-fixed nowrap display table-sm p-0" id="student_list" style="width:100%">
                                    <thead>
                                          <tr>
                                          <th>Student Name</th>
                                          <th class="text-center">S1</th>
                                          <th class="text-center">S2</th>
                                          <th class="text-center">S3</th>
                                          <th class="text-center">S4</th>
                                          <th class="text-center">S5</th>
                                          <th class="text-center">S6</th>
                                          <th class="text-center">S7</th>
                                          <th class="text-center">S8</th>
                                          <th class="text-center">S9</th>
                                          <th class="text-center">S10</th>
                                          <th class="text-center">S11</th>
                                          <th class="text-center">S12</th>
                                          <th class="text-center">S13</th>
                                          <th class="text-center">S14</th>
                                          <th class="text-center">S15</th>
                                          </tr>
                                    </thead>
                              </table>
                              <div class=" master_sheet_option">
                                    <span class="badge badge-danger">UNPOSTED</span>
                                    <span class="badge badge-primary">APPROVED</span>
                                    <span class="badge badge-info">POSTED</span>
                                    <span class="badge badge-success">SUBMITTED</span>
                                    <span class="badge badge-secondary">NOT SUBMITTED</span>
                              </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header p-1 bg-primary">
                        </div>
                        <div class="card-body">
                              <div class="row">
                                    <div class="col-md-3"><h5 class="mb-0 pt-1">Grading Sheet</h5></div>
                                    <div class="col-md-1"></div>
                                    <div class="col-md-4">
                                          <select name="grading_sheet_subject" id="grading_sheet_subject" class="form-control select2">
                                          <option selected value="" >SELECT SUBJECT</option>
                                          </select>
                                    </div>
                                    <div class="col-md-4">
                                          <button class="btn btn-primary btn-block" id="grading_sheet_filter" disabled="disabled">VIEW GRADING SHEET</button>
                                    </div>
                              </div>
                              <hr>
                            <table class="table table-bordered table-head-fixed nowrap display table-sm p-0" style="width:100%" id="grading_sheet_table_list"  >
                                <thead>
                                    <th>Student Name</th>
                                    <th class="text-center">Q1</th>
                                    <th class="text-center">Q2</th>
                                    <th class="text-center for_gs">Q3</th>
                                    <th class="text-center for_gs">Q4</th>
                                    <th class="text-center">FINAL RATING</th>
                                    <th class="text-center">REMARK</th>
                                </thead>
                            </table>
                            
                        </div>
                    </div>
                   
                </div>
            </div>
        </div>
    </section>
@endsection

@section('footerjavascript')


    <script src="{{asset('plugins/select2/js/select2.full.min.js') }}"></script>
    <script src="{{asset('plugins/datatables/jquery.dataTables.js') }}"></script>
    <script src="{{asset('plugins/datatables-bs4/js/dataTables.bootstrap4.js') }}"></script>
  

    <script>

          $(document).ready(function(){

            $('.select2').select2()

            var tid = '{{DB::table('teacher')->where('userid',auth()->user()->id)->first()->id}}';

            var students = [];
            var sections = [];


            loaddatatable(students)
            reset_data_table()

            get_advisory()

            function get_advisory(){

                  var syid = $('#syid').val()
                  var semid = $('#semester').val()

                  $.ajax({
                        type:'GET',
                        url:'/teacher/get/advisory',
                        data:{
                                tid:tid,
                                syid:syid,
                                semid:semid,
                        },
                        success:function(data) {
                              sections = data;
                              var arrayUniqueByKey = [...new Map(sections.map(item =>
                              [item['levelid'], item])).values()];

                              $.each(arrayUniqueByKey,function(a,b){
                                    $('#gradelevel').append('<option value="'+b.levelid+'">'+b.levelname+'</option>')
                              })
                              console.log(arrayUniqueByKey)
                        }
                    })
            }

            reset_sf9_report ()
            function reset_sf9_report (){
                  var temp_reset_data = []
                  $("#sf9_sheet_table_list").DataTable({
                        destroy: true,
                        data:temp_reset_data,
                        "scrollX": true,
                        "columnDefs": [
                              {"title":"Student Name","targets":0},
                            //   {"title":"Q1","targets":1},
                            //   {"title":"Q2","targets":2},
                            //   {"title":"Q3","targets":3},
                            //   {"title":"Q4","targets":4},
                              {"title":"Gen. Ave.","targets":1},
                              {"title":"Remarks","targets":2},
                        ]
                  })

            }


            $(document).on('change','#semester , #syid',function(){

                  $('#gradelevel').empty()
                  $('#gradelevel').append('<option value="">SELECT GRADE LEVEL</option>')

                  $('#section').empty()
                  $('#section').append('<option value="">SELECT SECTION</option>')

                  $('#sf9_grade_table').empty();

                  $('#sf9_student_name').empty();
                  $('#sf9_student_name').append('<option value="">SELECT STUDENT</option>')
                  $('#grading_sheet_subject').empty();
                  $('#grading_sheet_subject').append('<option value="">SELECT SUBJECT</option>')
                  reset_data_table()
                  get_advisory()
                  reset_sf9_report()
                

            })

            $(document).on('change','#gradelevel',function(){
                $('#section').empty()

                selectedGradeLevel = $(this).val()

                $('#section').append('<option value="">SELECT SECTION</option>')
                $.each(sections,function(a,b){
                  if(b.levelid == selectedGradeLevel){
                        $('#section').append('<option value="'+b.sectionid+'">'+b.sectionname+'</option>')
                  }
                })

                  if($(this).val() == 14 || $(this).val() == 15){
                        $('#quarter option').each(function(a,b){
                              if($(b).attr('value') == 3 || $(b).attr('value') == 4){
                                    $(b).attr('disabled','disabled')
                              }
                        })
                  }

                  reset_sf9_report()
            })

            $(document).on('change','#section',function(){
                  reset_sf9_report()
            })

            $(document).on('change','#quarter, #gradelevel, #section',function(){
                disablebutton()
            })

            function disablebutton(){

                $('#view_subjects').attr('disabled','disabled')
                $('#post_all').attr('disabled','disabled')
                $('#unpost_all').attr('disabled','disabled')
                $('#approve_all').attr('disabled','disabled')
            }

            var public_quarter;

            $(document).on('click','#filter',function(){

                var valid_input = true

                if($('#gradelevel').val() == ''){

                    valid_input = false;
                    Swal.fire({
                        type: 'info',
                        text: "Please select gradelevel!"
                    });

                }
                else if($('#section').val() == ''){

                    valid_input = false;
                    Swal.fire({
                        type: 'info',
                        text: "Please select section!"
                    });

                }
                else if($('#quarter').val() == ''){

                    valid_input = false;
                    Swal.fire({
                        type: 'info',
                        text: "Please select quarter!"
                    });

                }

                if(valid_input){

                    reset_data_table()
                    var gradelevel = $('#gradelevel').val();
                    var section = $('#section').val();
                    var quarter  = $('#quarter').val(); 
                    var syid  = $('#syid').val(); 
                    var semid  = $('#semester').val(); 

                    public_quarter = quarter

                    

                    $.ajax({
                        type:'GET',
                        url:'/posting/grade/getstudents',
                        data:{
                                gradelevel:gradelevel,
                                section:section,
                                quarter:quarter,
                                sy:syid,
                                semid:semid,
                        },
                        success:function(data) {

                            students = data
                            student_count = students.filter(x=>x.student != 'SUBJECTS').length

                            if(student_count > 0){
                                $('#view_subjects').removeAttr('disabled')
                                $('#post_all').removeAttr('disabled')
                                $('#unpost_all').removeAttr('disabled')
                                $('#approve_all').removeAttr('disabled')
                                $('#grading_sheet_filter').removeAttr('disabled')
                              //   $('#sf9_sheet_filter').removeAttr('disabled')

                                loaddatatable(students)

                                var grading_sheet_subjects = data.filter(x=>x.student == 'SUBJECTS')
                                $('#grading_sheet_subject').empty()
                                $('#grading_sheet_subject').append('<option value="">SELECT SUBJECT</option>')
                                $.each(grading_sheet_subjects[0].grades,function(a,b){
                                      if(b.subjid != "" && b.subjid != null){
                                          $('#grading_sheet_subject').append('<option value="'+b.subjid+'"> <span style="color:gray"">'+b.subjdesc+'</span> - '+b.subjtitle+'</option>')
                                      }
                                })
                            }
                            else{
                                students = []
                                loaddatatable(students)
                                Swal.fire({
                                    type: 'info',
                                    text: "No Enrolled Students!"
                                });
                                $('#view_subjects').attr('disabled','disabled')
                                $('#post_all').attr('disabled','disabled')
                                $('#unpost_all').attr('disabled','disabled')
                                $('#approve_all').attr('disabled','disabled')
                                $('#grading_sheet_filter').attr('disabled','disabled')
                              //   $('#sf9_sheet_filter').attr('disabled','disabled')
                            }
                        }
                    })
                }
            })

            function reset_data_table(){

                var temp_reset_data = []

            //     $("#sf9_sheet_table_list").DataTable({
            //                 destroy: true,
            //                 data:temp_reset_data,
            //                 "scrollX": true,
            //                 "columnDefs": [
            //                     {"title":"Student Name","targets":0},
            //                     {"title":"Q1","targets":1},
            //                     {"title":"Q2","targets":2},
            //                     {"title":"Q3","targets":3},
            //                     {"title":"Q4","targets":4},
            //                     {"title":"Final Rating","targets":5},
            //                     {"title":"Remarks","targets":6},
            //                 ]
            //             })
                        
                $("#grading_sheet_table_list").DataTable({
                    destroy: true,
                    data:temp_reset_data,
                    "scrollX": true,
                    "columnDefs": [
                        {"title":"Student Name","targets":0},
                        {"title":"Q1","targets":1},
                        {"title":"Q2","targets":2},
                        {"title":"Q3","targets":3},
                        {"title":"Q4","targets":4},
                        {"title":"Final Rating","targets":5},
                        {"title":"Remarks","targets":6},
                    ]
                })

            }


            function loaddatatable(data){

                var header = data[0];
                var data = data.filter(x => x.student != 'SUBJECTS')

                if(data.length == 0){

                    $("#student_list").DataTable({
                        destroy: true,
                        data:data,
                        "scrollX": true,
                        "columnDefs": [
                            {"title":"Student Name","targets":0},
                            {"title":"S1","targets":1},
                            {"title":"S2","targets":2},
                            {"title":"S3","targets":3},
                            {"title":"S4","targets":4},
                            {"title":"S5","targets":5},
                            {"title":"S6","targets":6},
                            {"title":"S7","targets":7},
                            {"title":"S8","targets":8},
                            {"title":"S9","targets":9},
                            {"title":"S10","targets":10},
                            {"title":"S11","targets":11},
                            {"title":"S12","targets":12},
                            {"title":"S13","targets":13},
                            {"title":"S14","targets":14},
                            {"title":"S15","targets":15},
                        ]
                    })
                        
                }
                else{

                    $("#student_list").DataTable({
                        destroy: true,
                        data:data,
                        "scrollX": true,
                        columns: [
                                    { "data": "student" },
                                    { "data": null },
                                    { "data": null },
                                    { "data": null },
                                    { "data": null },
                                    { "data": null },
                                    { "data": null },
                                    { "data": null },
                                    { "data": null },
                                    { "data": null },
                                    { "data": null },
                                    { "data": null },
                                    { "data": null },
                                    { "data": null },
                                    { "data": null },
                                    { "data": null },
                            ],
                            

                        "columnDefs": [
                            { "title": "STUDENT", 
                                "targets": 0,
                                'createdCell':  function (td, cellData, rowData, row, col) {
                                    
                                    $(td)[0].innerHTML = '<a href="#" class="view_info"  data-studid="'+rowData.studid+'">'+rowData.student+'</a> '
                                    
                                } 
                            
                            },
                            { "title": header.grades[0].subjdesc, "targets": 1,
                                'createdCell':  function (td, cellData, rowData, row, col) {

                                    $(td).removeAttr('class')

                                    if(rowData.grades[0].status == 4){

                                        // $(td)[0].innerHTML = '<span class="badge badge-info">P</span> '+rowData.grades[0].qg
                                        $(td).addClass('bg-info text-center')
                                        $(td).text(rowData.grades[0].qg)

                                    }
                                    else if(rowData.grades[0].status == 1){

                                        // $(td)[0].innerHTML = '<span class="badge badge-success">S</span> '+rowData.grades[0].qg
                                        $(td).addClass('bg-success text-center')
                                        $(td).text(rowData.grades[0].qg)

                                    }
                                    else if(rowData.grades[0].status == 2){

                                        // $(td)[0].innerHTML = '<span class="badge badge-primary">A</span> '+rowData.grades[0].qg
                                        $(td).addClass('bg-primary text-center')
                                        $(td).text(rowData.grades[0].qg)

                                    }
                                    else if(rowData.grades[0].status == 3){

                                        // $(td)[0].innerHTML = '<span class="badge badge-warning">PG</span> '+rowData.grades[0].qg
                                        $(td).addClass('bg-warning text-center')
                                        $(td).text(rowData.grades[0].qg)

                                    }
                                    else if(rowData.grades[0].status == 5){

                                        $(td).addClass('bg-danger text-center')
                                        $(td).text(rowData.grades[0].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-danger">UP</span> '+rowData.grades[0].qg

                                    }
                                    else if(rowData.grades[0].status == 6){

                                        $(td).addClass('bg-indigo text-center')
                                        $(td).text(rowData.grades[0].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-danger">UP</span> '+rowData.grades[0].qg

                                    }
                                    else{
                                        $(td).text(null)
                                        $(td).addClass('bg-secondary text-center')
                                    }

                                    $(td).addClass('text-center')
                                } 
                            },
                            { "title": header.grades[1].subjdesc, "targets": 2,
                                'createdCell':  function (td, cellData, rowData, row, col) {


                                    if(rowData.grades[1].status == 4){

                                        $(td).addClass('bg-info text-center')
                                        $(td).text(rowData.grades[1].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-info">P</span> '+rowData.grades[1].qg

                                    }
                                    else if(rowData.grades[1].status == 1){
                                        $(td).addClass('bg-success text-center')
                                        $(td).text(rowData.grades[1].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-success">S</span> '+rowData.grades[1].qg

                                    }
                                    else if(rowData.grades[1].status == 2){
                                        $(td).addClass('bg-primary text-center')
                                        $(td).text(rowData.grades[1].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-primary">A</span> '+rowData.grades[1].qg

                                    }
                                    else if(rowData.grades[1].status == 3){
                                        $(td).addClass('bg-warning text-center')
                                        $(td).text(rowData.grades[1].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-warning">PG</span> '+rowData.grades[1].qg

                                    }
                                    else if(rowData.grades[1].status == 5){
                                        $(td).addClass('bg-danger text-center')
                                        $(td).text(rowData.grades[1].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-danger">UP</span> '+rowData.grades[1].qg

                                    }
                                    else{
                                        $(td).text(null)
                                        $(td).addClass('bg-secondary text-center')
                                    }

                                    $(td).addClass('text-center')
                                } 
                            },
                            { "title": header.grades[2].subjdesc, "targets": 3,
                                'createdCell':  function (td, cellData, rowData, row, col) {

                                    if(rowData.grades[2].status == 4){
                                        $(td).addClass('bg-info text-center')
                                        $(td).text(rowData.grades[2].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-info">P</span> '+rowData.grades[2].qg

                                    }
                                    else if(rowData.grades[2].status == 1){
                                        $(td).addClass('bg-success text-center')
                                        $(td).text(rowData.grades[2].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-success">S</span> '+rowData.grades[2].qg

                                    }
                                    else if(rowData.grades[2].status == 2){
                                        $(td).addClass('bg-primary text-center')
                                        $(td).text(rowData.grades[2].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-primary">A</span> '+rowData.grades[2].qg

                                    }
                                    else if(rowData.grades[2].status == 3){
                                        $(td).addClass('bg-warning text-center')
                                        $(td).text(rowData.grades[2].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-warning">PG</span> '+rowData.grades[2].qg

                                    } 
                                    else if(rowData.grades[2].status == 5){
                                        $(td).addClass('bg-danger text-center')
                                        $(td).text(rowData.grades[2].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-danger">UP</span> '+rowData.grades[2].qg

                                    }
                                    else{
                                        $(td).text(null)
                                        $(td).addClass('bg-secondary text-center')
                                    }

                                    $(td).addClass('text-center')
                                } 
                            },
                            { "title": header.grades[3].subjdesc, "targets": 4,
                                'createdCell':  function (td, cellData, rowData, row, col) {

                                   
                                    if(rowData.grades[3].status == 4){
                                        $(td).addClass('bg-info text-center')
                                        $(td).text(rowData.grades[3].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-info">P</span> '+rowData.grades[3].qg

                                    }
                                    else if(rowData.grades[3].status == 1){
                                        $(td).addClass('bg-success text-center')
                                        $(td).text(rowData.grades[3].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-success">S</span> '+rowData.grades[3].qg

                                    }
                                    else if(rowData.grades[3].status == 2){
                                        $(td).addClass('bg-primary text-center')
                                        $(td).text(rowData.grades[3].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-primary">A</span> '+rowData.grades[3].qg

                                    }
                                    else if(rowData.grades[3].status == 3){
                                        $(td).addClass('bg-warning text-center')
                                        $(td).text(rowData.grades[3].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-warning">PG</span> '+rowData.grades[3].qg

                                    }
                                    else if(rowData.grades[3].status == 5){
                                        $(td).addClass('bg-danger text-center')
                                        $(td).text(rowData.grades[3].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-danger">UP</span> '+rowData.grades[3].qg

                                    }
                                    else{

                                        $(td).text(null)
                                        $(td).addClass('bg-secondary text-center')
                                    }


                                    $(td).addClass('text-center')
                                } 
                            },
                            { "title": header.grades[4].subjdesc, "targets": 5,
                                'createdCell':  function (td, cellData, rowData, row, col) {

                                    if(rowData.grades[4].status == 4){
                                        $(td).addClass('bg-info text-center')
                                        $(td).text(rowData.grades[4].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-info">P</span> '+rowData.grades[4].qg

                                    }
                                    else if(rowData.grades[4].status == 1){
                                        $(td).addClass('bg-success text-center')
                                        $(td).text(rowData.grades[4].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-success">S</span> '+rowData.grades[4].qg

                                    }
                                    else if(rowData.grades[4].status == 2){
                                        $(td).addClass('bg-primary text-center')
                                        $(td).text(rowData.grades[4].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-primary">A</span> '+rowData.grades[4].qg

                                    }
                                    else if(rowData.grades[4].status == 3){
                                        $(td).addClass('bg-warning text-center')
                                        $(td).text(rowData.grades[4].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-warning">PG</span> '+rowData.grades[4].qg

                                    }
                                    else if(rowData.grades[4].status == 5){
                                        $(td).addClass('bg-danger text-center')
                                        $(td).text(rowData.grades[4].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-danger">UP</span> '+rowData.grades[4].qg

                                    }
                                    else{

                                        $(td).text(null)
                                        $(td).addClass('bg-secondary text-center')
                                    }


                                    $(td).addClass('text-center')
                                } 
                            },
                            { "title": header.grades[5].subjdesc, "targets": 6,
                                'createdCell':  function (td, cellData, rowData, row, col) {

                                    if(rowData.grades[5].status == 4){
                                        $(td).addClass('bg-info text-center')
                                        $(td).text(rowData.grades[5].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-info">P</span> '+rowData.grades[5].qg

                                    }
                                    else if(rowData.grades[5].status == 1){
                                        $(td).addClass('bg-success text-center')
                                        $(td).text(rowData.grades[5].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-success">S</span> '+rowData.grades[5].qg

                                    }
                                    else if(rowData.grades[5].status == 2){
                                        $(td).addClass('bg-primary text-center')
                                        $(td).text(rowData.grades[5].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-primary">A</span> '+rowData.grades[5].qg

                                    }
                                    else if(rowData.grades[5].status == 3){
                                        $(td).addClass('bg-warning text-center')
                                        $(td).text(rowData.grades[5].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-warning">PG</span> '+rowData.grades[5].qg

                                    }
                                    else if(rowData.grades[5].status == 5){
                                        $(td).addClass('bg-danger text-center')
                                        $(td).text(rowData.grades[5].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-danger">UP</span> '+rowData.grades[5].qg

                                    }
                                    else{

                                        $(td).text(null)
                                        $(td).addClass('bg-secondary text-center')
                                    }

                                    $(td).addClass('text-center')
                                } 
                            },
                            { "title": header.grades[6].subjdesc, "targets": 7,
                                'createdCell':  function (td, cellData, rowData, row, col) {

                                    if(rowData.grades[6].status == 4){
                                        $(td).addClass('bg-info text-center')
                                        $(td).text(rowData.grades[6].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-info">P</span> '+rowData.grades[6].qg

                                    }
                                    else if(rowData.grades[6].status == 1){
                                        $(td).addClass('bg-success text-center')
                                        $(td).text(rowData.grades[6].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-success">S</span> '+rowData.grades[6].qg

                                    }
                                    else if(rowData.grades[6].status == 2){
                                        $(td).addClass('bg-primary text-center')
                                        $(td).text(rowData.grades[6].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-primary">A</span> '+rowData.grades[6].qg

                                    }
                                    else if(rowData.grades[6].status == 3){
                                        $(td).addClass('bg-warning text-center')
                                        $(td).text(rowData.grades[6].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-warning">PG</span> '+rowData.grades[6].qg

                                    }
                                    else if(rowData.grades[6].status == 5){
                                        $(td).addClass('bg-danger text-center')
                                        $(td).text(rowData.grades[6].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-danger">UP</span> '+rowData.grades[6].qg

                                    }
                                    else{

                                        $(td).text(null)
                                        $(td).addClass('bg-secondary text-center')
                                    }

                                    $(td).addClass('text-center')
                                } 
                            },
                            { "title": header.grades[7].subjdesc, "targets": 8,
                                'createdCell':  function (td, cellData, rowData, row, col) {

                                    if(rowData.grades[7].status == 4){
                                        $(td).addClass('bg-info text-center')
                                        $(td).text(rowData.grades[7].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-info">P</span> '+rowData.grades[7].qg

                                    }
                                    else if(rowData.grades[7].status == 1){
                                        $(td).addClass('bg-success text-center')
                                        $(td).text(rowData.grades[7].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-success">S</span> '+rowData.grades[7].qg

                                    }
                                    else if(rowData.grades[7].status == 2){
                                        $(td).addClass('bg-primary text-center')
                                        $(td).text(rowData.grades[7].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-primary">A</span> '+rowData.grades[7].qg

                                    }
                                    else if(rowData.grades[7].status == 3){
                                        $(td).addClass('bg-warning text-center')
                                        $(td).text(rowData.grades[7].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-warning">PG</span> '+rowData.grades[7].qg

                                    }
                                    else if(rowData.grades[7].status == 5){
                                        $(td).addClass('bg-danger text-center')
                                        $(td).text(rowData.grades[7].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-danger">UP</span> '+rowData.grades[7].qg

                                    }
                                    else{

                                        $(td).text(null)
                                        $(td).addClass('bg-secondary text-center')
                                    }

                                    $(td).addClass('text-center')
                                } 
                            },
                            { "title": header.grades[8].subjdesc, "targets": 9,
                                'createdCell':  function (td, cellData, rowData, row, col) {

                                    if(rowData.grades[8].status == 4){
                                        $(td).addClass('bg-info text-center')
                                        $(td).text(rowData.grades[8].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-info">P</span> '+rowData.grades[8].qg

                                    }
                                    else if(rowData.grades[8].status == 1){
                                        $(td).addClass('bg-success text-center')
                                        $(td).text(rowData.grades[8].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-success">S</span> '+rowData.grades[8].qg

                                    }
                                    else if(rowData.grades[8].status == 2){
                                        $(td).addClass('bg-primary text-center')
                                        $(td).text(rowData.grades[8].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-primary">A</span> '+rowData.grades[8].qg

                                    }
                                    else if(rowData.grades[8].status == 3){
                                        $(td).addClass('bg-warning text-center')
                                        $(td).text(rowData.grades[8].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-warning">PG</span> '+rowData.grades[8].qg

                                    }
                                    else if(rowData.grades[8].status == 5){
                                        $(td).addClass('bg-danger text-center')
                                        $(td).text(rowData.grades[8].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-danger">UP</span> '+rowData.grades[8].qg

                                    }
                                    else{

                                        $(td).text(null)
                                        $(td).addClass('bg-secondary text-center')
                                    }


                                    $(td).addClass('text-center')
                                } 
                            },
                            { "title": header.grades[9].subjdesc, "targets": 10,
                                'createdCell':  function (td, cellData, rowData, row, col) {

                                    if(rowData.grades[9].status == 4){
                                        $(td).addClass('bg-info text-center')
                                        $(td).text(rowData.grades[9].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-info">P</span> '+rowData.grades[9].qg

                                    }
                                    else if(rowData.grades[9].status == 1){
                                        $(td).addClass('bg-success text-center')
                                        $(td).text(rowData.grades[9].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-success">S</span> '+rowData.grades[9].qg

                                    }
                                    else if(rowData.grades[9].status == 2){
                                        $(td).addClass('bg-primary text-center')
                                        $(td).text(rowData.grades[9].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-primary">A</span> '+rowData.grades[9].qg

                                    }
                                    else if(rowData.grades[9].status == 3){
                                        $(td).addClass('bg-warning text-center')
                                        $(td).text(rowData.grades[9].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-warning">PG</span> '+rowData.grades[9].qg

                                    }
                                    else if(rowData.grades[9].status == 5){
                                        $(td).addClass('bg-danger text-center')
                                        $(td).text(rowData.grades[9].qg)
                                        //  $(td)[0].innerHTML = '<span class="badge badge-danger">UP</span> '+rowData.grades[9].qg

                                    }
                                    else{

                                        $(td).text(null)
                                        $(td).addClass('bg-secondary text-center')
                                    }


                                    $(td).addClass('text-center')
                                } 
                            },
                            { "title": header.grades[10].subjdesc, "targets": 11,
                                'createdCell':  function (td, cellData, rowData, row, col) {

                                    if(rowData.grades[10].status == 4){
                                        $(td).addClass('bg-info text-center')
                                        $(td).text(rowData.grades[10].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-info">P</span> '+rowData.grades[10].qg

                                    }
                                    else if(rowData.grades[10].status == 1){
                                        $(td).addClass('bg-success text-center')
                                        $(td).text(rowData.grades[10].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-success">S</span> '+rowData.grades[10].qg

                                    }
                                    else if(rowData.grades[10].status == 2){
                                        $(td).addClass('bg-primary text-center')
                                        $(td).text(rowData.grades[10].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-primary">A</span> '+rowData.grades[10].qg

                                    }
                                    else if(rowData.grades[10].status == 3){
                                        $(td).addClass('bg-warning text-center')
                                        $(td).text(rowData.grades[10].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-warning">PG</span> '+rowData.grades[10].qg

                                    }
                                    else if(rowData.grades[10].status == 5){
                                        $(td).addClass('bg-danger text-center')
                                        $(td).text(rowData.grades[10].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-danger">UP</span> '+rowData.grades[10].qg

                                    }
                                    else{

                                        $(td).text(null)
                                        $(td).addClass('bg-secondary text-center')
                                    }


                                    $(td).addClass('text-center')

                                } 
                            },
                            { "title": header.grades[11].subjdesc, "targets": 12,
                                'createdCell':  function (td, cellData, rowData, row, col) {

                                    if(rowData.grades[11].status == 4){
                                        $(td).addClass('bg-info text-center')
                                        $(td).text(rowData.grades[11].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-info">P</span> '+rowData.grades[11].qg

                                    }
                                    else if(rowData.grades[11].status == 1){
                                        $(td).addClass('bg-success text-center')
                                        $(td).text(rowData.grades[11].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-success">S</span> '+rowData.grades[11].qg

                                    }
                                    else if(rowData.grades[11].status == 2){
                                        $(td).addClass('bg-primary text-center')
                                        $(td).text(rowData.grades[11].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-primary">A</span> '+rowData.grades[11].qg

                                    }
                                    else if(rowData.grades[11].status == 3){
                                        $(td).addClass('bg-warning text-center')
                                        $(td).text(rowData.grades[11].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-warning">PG</span> '+rowData.grades[11].qg

                                    }
                                    else if(rowData.grades[11].status == 5){
                                        $(td).addClass('bg-danger text-center')
                                        $(td).text(rowData.grades[11].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-danger">UP</span> '+rowData.grades[11].qg

                                    }
                                    else{

                                        $(td).text(null)
                                        $(td).addClass('bg-secondary text-center')
                                    }


                                    $(td).addClass('text-center')

                                } 
                            },
                            { "title": header.grades[12].subjdesc, "targets": 13,
                                'createdCell':  function (td, cellData, rowData, row, col) {
                                    

                                    if(rowData.grades[12].status == 4){
                                        $(td).addClass('bg-info text-center')
                                        $(td).text(rowData.grades[12].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-info">P</span> '+rowData.grades[12].qg

                                    }
                                    else if(rowData.grades[12].status == 1){
                                        $(td).addClass('bg-success text-center')
                                        $(td).text(rowData.grades[12].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-success">S</span> '+rowData.grades[12].qg

                                    }
                                    else if(rowData.grades[12].status == 2){
                                        $(td).addClass('bg-primary text-center')
                                        $(td).text(rowData.grades[12].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-primary">A</span> '+rowData.grades[12].qg

                                    }
                                    else if(rowData.grades[12].status == 3){
                                        $(td).addClass('bg-warning text-center')
                                        $(td).text(rowData.grades[12].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-warning">PG</span> '+rowData.grades[12].qg

                                    }
                                    else if(rowData.grades[12].status == 5){
                                        $(td).addClass('bg-danger text-center')
                                        $(td).text(rowData.grades[12].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-danger">UP</span> '+rowData.grades[12].qg

                                    }
                                    else{

                                        $(td).text(null)
                                        $(td).addClass('bg-secondary text-center')
                                    }


                                    $(td).addClass('text-center')
                                } 
                            },
                            { "title": header.grades[13].subjdesc, "targets": 14,
                                'createdCell':  function (td, cellData, rowData, row, col) {

                                    console.log(rowData.grades[13].status)

                                    if(rowData.grades[13].status == 4){
                                        $(td).addClass('bg-info text-center')
                                        $(td).text(rowData.grades[13].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-info">P</span> '+rowData.grades[13].qg

                                    }
                                    else if(rowData.grades[13].status == 1){
                                        $(td).addClass('bg-success text-center')
                                        $(td).text(rowData.grades[13].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-success">S</span> '+rowData.grades[13].qg

                                    }
                                    else if(rowData.grades[13].status == 2){
                                        $(td).addClass('bg-primary text-center')
                                        $(td).text(rowData.grades[13].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-primary">A</span> '+rowData.grades[13].qg

                                    }
                                    else if(rowData.grades[13].status == 3){
                                        $(td).addClass('bg-warning text-center')
                                        $(td).text(rowData.grades[13].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-warning">PG</span> '+rowData.grades[13].qg

                                    }
                                    else if(rowData.grades[13].status == 5){
                                        $(td).addClass('bg-danger text-center')
                                        $(td).text(rowData.grades[13].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-danger">UP</span> '+rowData.grades[13].qg

                                    }
                                    else{

                                        $(td).text(null)
                                        $(td).addClass('bg-secondary text-center')
                                    }


                                    $(td).addClass('text-center')
                                } 
                            },
                            { "title": header.grades[14].subjdesc, "targets": 15,
                                'createdCell':  function (td, cellData, rowData, row, col) {

                                    if(rowData.grades[14].status == 4){
                                        $(td).addClass('bg-info text-center')
                                        $(td).text(rowData.grades[14].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-info">P</span> '+rowData.grades[14].qg

                                    }
                                    else if(rowData.grades[14].status == 1){
                                        $(td).addClass('bg-success text-center')
                                        $(td).text(rowData.grades[14].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-success">S</span> '+rowData.grades[14].qg

                                    }
                                    else if(rowData.grades[14].status == 2){
                                        $(td).addClass('bg-primary text-center')
                                        $(td).text(rowData.grades[14].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-primary">A</span> '+rowData.grades[14].qg

                                    }
                                    else if(rowData.grades[14].status == 3){
                                        $(td).addClass('bg-warning text-center')
                                        $(td).text(rowData.grades[14].qg)
                                        // $(td)[0].innerHTML = '<span class="badge badge-warning">PG</span> '+rowData.grades[14].qg

                                    }
                                    else if(rowData.grades[14].status == 5){
                                        $(td).addClass('bg-danger text-center')
                                        $(td).text(rowData.grades[14].qg)
                                        $(td)[0].innerHTML = '<span class="badge badge-danger">UP</span> '+rowData.grades[14].qg

                                    }
                                    else{

                                        $(td).text(null)
                                        $(td).addClass('bg-secondary text-center')

                                    }


                                    $(td).addClass('text-center')
                                } 
                            },
                            
                        ]
                        
                });

                }

        
            }

            var select_student;

            function update_student_detail_option(){

                var data = students.filter(x => x.studid == select_student)
                var count_posted = data[0].grades.filter(x=>x.status != 0 && x.status == 4).length
                var count_unposted = data[0].grades.filter(x=>x.status != 0 && x.status == 5).length
                var subj_count = data[0].grades.filter(x=>x.status != 0).length

                $('#post_grade').removeAttr('disabled')
                $('#unpost_grade').removeAttr('disabled')

                if(count_posted == subj_count){
                    $('#post_grade').attr('disabled','disbled')
                }
                else if(count_unposted == subj_count){
                    $('#unpost_grade').attr('disabled','disbled')
                }

            }


            $(document).on('click','.view_info',function(){
                $('#grade_info').modal()
                select_student = $(this).attr('data-studid')
                var data = students.filter(x => x.studid == select_student)
                update_student_detail_option()
                $('#student_name_modal').val(data[0].student)
                load_grade_detail(data)
            })

            $(document).on('click','#view_subjects',function(){
                $('#subject_list').modal()
                subject_info_table()
                $('.subj_tr').removeClass('bg-secondary')
            })

            function subject_info_table(){
                var temp_data = students.filter( x => x.student == 'SUBJECTS')
                $('#sl_grade_level').val($('#gradelevel option:selected').text())
                $('#sl_section').val($('#section option:selected').text())
                $('#subject_holder').empty()
                $.each(temp_data[0].grades,function(a,b){
                    var bg = ''
                    if(selected_subj == b.gsdid){
                        bg = 'bg-secondary'
                    }

                    if(b.subjid != ""){
                        if(b.status == 0){
                            $('#subject_holder').append('<tr><td class="align-middle">'+b.subjdesc+'</td><td>'+b.subjtitle+'</td><td class="text-center"><span class="badge badge-secondary d-block">NOT SUBMITTED</span></td></tr>')
                        }
                        else if(b.status == 1){
                            $('#subject_holder').append('<tr data-id="'+b.gsdid+'" class="subj_tr subject_option '+bg+'"><td class=" align-middle">'+b.subjdesc+'</td><td>'+b.subjtitle+'</td><td class="text-center"><span class="badge badge-success d-block"> SUBMITTED</span></td></tr>')
                        }
                        else if(b.status == 4){
                            $('#subject_holder').append('<tr data-id="'+b.gsdid+'" class="subj_tr subject_option '+bg+'"><td class=" align-middle"">'+b.subjdesc+'</td><td>'+b.subjtitle+'</td><td class="text-center"><span class="badge badge-info d-block"> POSTED</span></td></tr>')
                        }
                        else if(b.status == 3){
                            $('#subject_holder').append('<tr data-id="'+b.gsdid+'" class="subj_tr subject_option '+bg+'"><td class=" align-middle"">'+b.subjdesc+'</td><td>'+b.subjtitle+'</td><td class="text-center"><span class="badge badge-warning d-block"> PENDING</span></td></tr>')
                        }
                        else if(b.status == 2){
                            $('#subject_holder').append('<tr data-id="'+b.gsdid+'" class="subj_tr subject_option '+bg+'"><td class=" align-middle"">'+b.subjdesc+'</td><td>'+b.subjtitle+'</td><td class="text-center"><span class="badge badge-primary d-block"> APPROVED</span></td></tr>')
                        }
                        else if(b.status == 5){
                            $('#subject_holder').append('<tr data-id="'+b.gsdid+'" class="subj_tr subject_option '+bg+'"><td class="align-middle" >'+b.subjdesc+'</td><td>'+b.subjtitle+'</td><td class="text-center"><span class="badge badge-danger d-block"> UNPOSTED</span></td></tr>')
                        }
                        // else if(b.status == 6){
                        //     $('#subject_holder').append('<tr data-id="'+b.gsdid+'" class="subj_tr subject_option '+bg+'"><td class="align-middle" >'+b.subjdesc+'</td><td>'+b.subjtitle+'</td><td class="text-center"><span class="badge badge-indigo d-block"> CONFLICT</span></td></tr>')
                        // }
                    }
                    
                })
            }

            function default_subj_option(){

                $('#subj_unpost').removeAttr('disabled')
                $('#subj_approve').removeAttr('disabled')
                $('#subj_pending').removeAttr('disabled')
                $('#subj_post').removeAttr('disabled')

            }

            function check_subj_option(){
                var checkStatus = students.filter(x=>x.student == 'SUBJECTS')[0].grades.filter(x=>x.gsdid == selected_subj)[0].status
                if(checkStatus == 5){
                    $('#subj_unpost').attr('disabled','disabled')
                    $('#subj_approve').attr('disabled','disabled')
                }
                else if(checkStatus == 4){
                    $('#subj_post').attr('disabled','disabled')
                    $('#subj_approve').attr('disabled','disabled')
                    $('#subj_pending').attr('disabled','disabled')
                }
                else if(checkStatus == 1){
                    $('#subj_unpost').attr('disabled','disabled')
                }
                else if(checkStatus == 2){
                    $('#subj_approve').attr('disabled','disabled')
                    $('#subj_unpost').attr('disabled','disabled')
                }
                else if(checkStatus == 3){
                    $('#subj_pending').attr('disabled','disabled')
                    $('#subj_unpost').attr('disabled','disabled')
                    $('#subj_post').attr('disabled','disabled')
                }
            }



            // $(document).on('click','.subject_option',function(){

            //     default_subj_option()
            //     selected_subj = $(this).attr('data-id')
            //     check_subj_option()
            //     $('#subject_option').modal()
            //     $('.subj_tr').removeClass('bg-secondary')
            //     $('.subj_tr[data-id="'+selected_subj+'"]').addClass('bg-secondary')

            // })

            var selected_subj;

            function check_item_count_by_subject(status){

                var filter_subject  = students.filter(x => x.student == 'SUBJECTS')[0].grades
                var gradeid = filter_subject.findIndex(x => x.gsdid == selected_subj)
                var new_status = status

                students.filter(function(x){
                    if(x.grades[gradeid].gdid != ""){
                        if(x.student != 'SUBJECT' && x.grades[gradeid].status != new_status){
                            temp_item_count += 1;
                        }else if(x.student == 'SUBJECTS'){
                            temp_item_count += 1;
                        }

                    }
                })

            }

            //all subjects
            function post_subject_grade(){
                var temp_students = students.filter(x => x.student == 'SUBJECTS' )
                selected_subj = null
                $.each(temp_students[0].grades, function(a,b){
                    if(b.subjid != ""){
                        selected_subj = b.gsdid
                        post_subject_grade_ajax()
                    }
                })
            }

            //all subjects
            function unpost_subject_grade(){
                var temp_students = students.filter(x => x.student == 'SUBJECTS')
                $.each(temp_students[0].grades, function(a,b){
                    if(b.subjid != ""){
                        selected_subj = b.gsdid
                        unpost_subject_grade_ajax()
                    }
                })
            }

            function reset_progress_bar(){
                temp_percentage = 0;
                temp_proccess_count = 0;
                temp_item_count = 0;
                $('#progress_bar').css('width','0'+'%')
                $('#percentage').text("0%")
                $('#proccess_done').attr('hidden','hidden')
            }


            
            var temp_percentage
            var temp_item_count


            
           

            $(document).on('click','.view_info',function(){

                $('#grade_info').modal()

                select_student = $(this).attr('data-studid');

                var data = students.filter(x => x.studid == select_student)

                $('#student_name_modal').val(data[0].student)

                load_grade_detail(data)

            })

            function load_grade_detail(data){
                $('#grade_holder').empty()
                var arrayID = students.findIndex(x => x.studid == data[0].studid)
                $.each(data[0].grades,function(a,b){
                  
                    var bg = ''
                    if(selected_subj == b.gdid){
                        bg = 'bg-secondary'
                    }

                    if(b.subjid != ""){
                        var status_string = '';
                        var this_class = 'stud_subj_tr'
                        var qg = ''
                        if(b.status == 1){
                            var status_string = '<span class="badge badge-success d-block">SUBMITTED</span>';
                        }
                        else  if(b.status == 2){
                            var status_string = '<span class="badge badge-primary d-block">APPROVED</span>';
                        }
                        else  if(b.status == 3){
                            var status_string = '<span class="badge badge-warning d-block">PENDING</span>';
                        }
                        else  if(b.status == 4){
                            var status_string = '<span class="badge badge-info d-block">POSTED</span>';
                        }
                        else  if(b.status == 5){
                            var status_string = '<span class="badge badge-danger d-block">UNPOSTED</span>';
                        }
                        else  if(b.status == 6){
                            var status_string = '<span class="badge bg-indigo d-block">CONFLICT</span>';
                        }else{
                            var status_string = '<span class="badge badge-secondary d-block">NOT SUBMITTED</span>';
                            this_class = ''
                        }

                        if(b.status != 0 ){
                            qg = b.qg
                        }

                        $('#grade_holder').append('<tr class="'+this_class+' '+bg+'" data-id="'+b.gdid+'" data-studid="'+data[0].studid+'" data-index="'+a+'" data-studindex="'+arrayID+'"  data-tid="'+b.teacherid+'"><td>'+b.subjdesc+'</td><td class="text-center">'+qg+'</td><td class="text-center">'+status_string+'</td></tr>')
                    }
                })
            }

            var temp_proccess_count = 0;
            var temp_item_count = 0;
            var selected_subjects 
            var stud_index
            var gdid
            var data_index
            var stud_index
            var teacherid

            function default_stud_subj_option(){

                $('#stud_subj_unpost').removeAttr('disabled')
                $('#stud_subj_pending').removeAttr('disabled')
                $('#stud_subj_post').removeAttr('disabled')

            }
          

            function check_stud_subj_option(){
                
                var checkStatus = students.filter(x=>x.studid == studid)[0].grades.filter(x=>x.gdid == gdid)[0].status

                if(checkStatus == 5){
                    $('#stud_subj_unpost').attr('disabled','disabled')
                }
                else if(checkStatus == 4){
                    $('#stud_subj_post').attr('disabled','disabled')
                    $('#stud_subj_pending').attr('disabled','disabled')
                }
                else if(checkStatus == 1){
                    $('#stud_subj_unpost').attr('disabled','disabled')
                }
                else if(checkStatus == 2){
                    $('#stud_subj_unpost').attr('disabled','disabled')
                }
                else if(checkStatus == 3){
                    $('#stud_subj_pending').attr('disabled','disabled')
                    $('#stud_subj_unpost').attr('disabled','disabled')
                    $('#stud_subj_post').attr('disabled','disabled')
                }
            }



            // $(document).on('click','.stud_subj_tr',function(){
               
            //     $('#student_subject_option').modal()
            //     studid = $(this).attr('data-studid')
            //     gdid = $(this).attr('data-id')
            //     data_index = $(this).attr('data-index')
            //     stud_index = $(this).attr('data-studindex') - 1 
            //     teacherid = $(this).attr('data-tid')
            //     default_stud_subj_option()
            //     check_stud_subj_option()

            // })

            // $(document).on('click','#stud_subj_post',function(){
            //     reset_progress_bar()
            //     temp_item_count = 1
            //     Swal.fire({
            //         html:
            //             'Are you sure you want <br>' +
            //             'to post grades for this subject?',
            //         type: 'warning',
            //         showCancelButton: true,
            //         confirmButtonColor: '#3085d6',
            //         cancelButtonColor: '#d33',
            //         confirmButtonText: 'Yes, post grades!'
            //     }).then((result) => {
            //         if (result.value) {
            //             $('#proccess_count_modal').modal()
            //             post_student_grade( studid, gdid, stud_index , data_index, teacherid)
                   
            //         }
            //     })
            // })

            // $(document).on('click','#stud_subj_unpost',function(){
            //     reset_progress_bar()
            //     temp_item_count = 1
            //     Swal.fire({
            //         html:
            //             'Are you sure you want <br>' +
            //             'to unpost grades for this subject?',
            //         type: 'warning',
            //         showCancelButton: true,
            //         confirmButtonColor: '#3085d6',
            //         cancelButtonColor: '#d33',
            //         confirmButtonText: 'Yes, unpost grades!'
            //     }).then((result) => {
            //         if (result.value) {
            //             $('#proccess_count_modal').modal()
            //             unpost_student_grade( studid, gdid, stud_index , data_index )
            //         }
            //     })
            // })

            // $(document).on('click','#stud_subj_pending',function(){
            //     reset_progress_bar()
            //     temp_item_count = 1
            //     Swal.fire({
            //         html:
            //             'Are you sure you want <br>' +
            //             'to add grades to pending?',
            //         type: 'warning',
            //         showCancelButton: true,
            //         confirmButtonColor: '#3085d6',
            //         cancelButtonColor: '#d33',
            //         confirmButtonText: 'Yes, add grades to pending!'
            //     }).then((result) => {
            //         if (result.value) {
            //             $('#proccess_count_modal').modal()
            //             pending_student_grade( studid, gdid, stud_index , data_index, teacherid )
                       
            //         }
            //     })
            // })
        })
    </script>

    <script>
        $(document).ready(function(){

            var select_subject;
            var select_gl;
            var all_data = [];

            $(document).on('click','#grading_sheet_filter',function(){

                var valid_input = true

                select_subject = $('#grading_sheet_subject').val()
                select_gl = $('#gradelevel').val()

                if(valid_input){
                    var gradelevel = $('#gradelevel').val()
                    var section = $('#section').val()
                    var syid = $('#syid').val()
                    var semid = $('#semester').val()

                    if(all_data.length == 0){
                        $.ajax({
                            type:'GET',
                            url:'/grades/report/gradingsheet',
                            data:{
                                    gradelevel:gradelevel,
                                    section:section,
                                    syid:syid,
                                    semid:semid
                            },
                            success:function(data) {
                                all_data = data
                                student_count = all_data.filter(x=>x.student != 'SUBJECTS').length
                                if(student_count > 0){
                                    loaddatatable(all_data)
                                }
                                else{
                                    all_data = []
                                    loaddatatable(all_data)
                                    Swal.fire({
                                        type: 'info',
                                        text: "No Enrolled Students!"
                                    });
                                }
                            }
                        })
                    }else{
                        loaddatatable(all_data)
                    }
                }
            })

            function loaddatatable(data){
                var header = data[0];
                var data = data.filter(x => x.student != 'SUBJECTS')
               
                if(data.length == 0){

                    $("#grading_sheet_table_list").DataTable({
                        destroy: true,
                        data:data,
                        "scrollX": true,
                        "columnDefs": [
                            {"title":"Student Name","targets":0},
                            {"title":"Q1","targets":1},
                            {"title":"Q2","targets":2},
                            {"title":"Q3","targets":3},
                            {"title":"Q4","targets":4},
                            {"title":"Final Rating","targets":5},
                            {"title":"Remarks","targets":6},
                        ]
                    })
                        
                }
                else{

                    $("#grading_sheet_table_list").DataTable({
                        destroy: true,
                        data:data,
                        "scrollX": true,
                        columns: [
                                    { "data": "student" },
                                    { "data": null },
                                    { "data": null },
                                    { "data": null },
                                    { "data": null },
                                    { "data": null },
                                    { "data": null },
                            ],
                        "columnDefs": [
                            { "title": "STUDENT", 
                                "targets": 0,
                                'createdCell':  function (td, cellData, rowData, row, col) {
                                    $(td)[0].innerHTML = rowData.student
                                    
                                } 
                            
                            },
                            { "title": "Q1", 
                                "targets": 1,
                                'createdCell':  function (td, cellData, rowData, row, col) {
                                   $(td).addClass('text-center')
                                   var qg = cellData.grades.filter(x=>x.subjid == select_subject)
                                   if(qg.length != 0){
                                        $(td).text(qg[0].q1)
                                   }else{
                                        $(td).text(null)
                                   }
                         
                                } 
                            
                            },
                            { "title": "Q2", 
                                "targets": 2,
                                'createdCell':  function (td, cellData, rowData, row, col) {
                                    $(td).addClass('text-center')
                                    var qg = cellData.grades.filter(x=>x.subjid == select_subject)
                                    if(qg.length != 0){
                                            $(td).text(qg[0].q2)
                                    }else{
                                            $(td).text(null)
                                    }
                                } 
                            
                            },
                            { "title": "Q3", 
                                "targets": 3,
                                'createdCell':  function (td, cellData, rowData, row, col) {
                                    $(td).addClass('text-center')
                                    var qg = cellData.grades.filter(x=>x.subjid == select_subject)
                                    if(select_gl == 14 || select_gl == 15){
                                        $(td).attr('hidden','hidden')
                                    }else{
                                        $(td).removeAttr('hidden')
                                    }
                                    if(qg.length != 0){
                                            $(td).text(qg[0].q3)
                                    }else{
                                            $(td).text(null)
                                    }
                                } 
                            
                            },
                            { "title": "Q4", 
                                "targets": 4,
                                'createdCell':  function (td, cellData, rowData, row, col) {
                                    $(td).addClass('text-center')
                                    if(select_gl == 14 || select_gl == 15){
                                        $(td).attr('hidden','hidden')
                                    }
                                    else{
                                        $(td).removeAttr('hidden')
                                    }
                                    var qg = cellData.grades.filter(x=>x.subjid == select_subject)
                                    if(qg.length != 0){
                                            $(td).text(qg[0].q4)
                                    }else{
                                            $(td).text(null)
                                    }
                                } 
                            
                            },
                            { "title": "FINAL RATING", 
                                "targets": 5,
                                'createdCell':  function (td, cellData, rowData, row, col) {
                                    $(td).addClass('text-center')
                                    var qg = cellData.grades.filter(x=>x.subjid == select_subject)
                                    var fg = 0;
                                    if(qg.length != 0){
                                        if(select_gl == 14 || select_gl == 15){
                                            if(qg[0].q1 != null && qg[0].q2 != null){
                                                fg = ( qg[0].q1 + qg[0].q2 ) / 2
                                            }
                                        }else{
                                            if([0].q1 != null && qg[0].q2 != null & qg[0].q3 != null & qg[0].q4 != null){
                                                fg = ( qg[0].q1 + qg[0].q2 + qg[0].q3 + qg[0].q4 ) / 4
                                            }
                                        }

                                        if(fg != 0){
                                            $(td).text(fg.toFixed())
                                        }else{
                                            $(td).text(null)
                                        }
                                        
                                    }else{
                                            $(td).text(null)
                                    }
                                } 
                            
                            },
                            { "title": "REMARK", 
                                "targets": 6,
                                'createdCell':  function (td, cellData, rowData, row, col) {
                                    $(td).addClass('text-center')
                                    var qg = cellData.grades.filter(x=>x.subjid == select_subject)
                                    var fg;
                                    if(qg.length != 0){
                                        if(select_gl == 14 || select_gl == 15){
                                            if(qg[0].q1 != null && qg[0].q2 != null){
                                                fg = ( qg[0].q1 + qg[0].q2 ) / 2
                                            }
                                        }else{
                                            if(qg[0].q1 != null && qg[0].q2 != null & qg[0].q3 != null & qg[0].q4 != null){
                                                fg = ( qg[0].q1 + qg[0].q2 + qg[0].q3 + qg[0].q4 ) / 4
                                            }
                                        }
                                        if(fg >= 75 && fg != ''){
                                            $(td).text('PASSED')
                                        }
                                        else if(fg < 75 && fg != ''){
                                            $(td).text('FAILED')
                                        }else{
                                            $(td).text(null)
                                        }
                                    }else{
                                            $(td).text(null)
                                    }
                                } 
                            
                            },

                        ]
                    });

                    if(select_gl == 14 || select_gl == 15){
                        $('.for_gs').attr('hidden','hidden')
                    }
                    else{
                        $('.for_gs').removeAttr('hidden')
                    }

                }

            }

            

        })


    </script>

    <script>
        $(document).ready(function(){

            var all_data
            var select_gl

            $(document).on('click','#sf9_sheet_filter',function(){
                  var valid_input = true
                
                  if($('#gradelevel').val() == ''){
                        valid_input = false;
                        Swal.fire({
                              type: 'info',
                              text: "Please select gradelevel!"
                        });
                  }
                  else if($('#section').val() == ''){
                        valid_input = false;
                        Swal.fire({
                              type: 'info',
                              text: "Please select section!"
                        });

                  }

                  console.log($('#gradelevel').val())

                if(valid_input){
                    var gradelevel = $('#gradelevel').val();
                    var section = $('#section').val();
                    var syid = $('#syid').val()
                    var semid = $('#semester').val()

                    select_gl = $('#gradelevel').val()
                    public_quarter = quarter
                    $.ajax({
                        type:'GET',
                        url:'/grades/report/gradingsheet',
                        data:{
                                gradelevel:gradelevel,
                                section:section,
                                syid:syid,
                                semid:semid
                        },
                        success:function(data) {
                            all_data = data
                            student_count = all_data.filter(x=>x.student != 'SUBJECTS')
                            if(student_count.length > 0){
                                    $('#sf9_student_name').empty()
                                    $('#sf9_student_name').append('<option value="">SELECT STUDENT</option>')
                                    $.each(student_count,function(a,b){
                                          console.log(b)
                                          $('#sf9_student_name').append('<option value="'+b.studid+'">'+b.student+'</option>')
                                    })
                                    $('#sf9_report_button').removeAttr('disabled','disabled')
                                loaddatatable(all_data)


                            }
                            else{
                                all_data = []
                                loaddatatable(all_data)
                                Swal.fire({
                                    type: 'info',
                                    text: "No Enrolled Students!"
                                });
                            }
                        }
                    })
                    
                }
            })

            $(document).on('click','#sf9_report_button',function(){

                  if($('#sf9_student_name').val() == ""){
                        Swal.fire({
                              type: 'info',
                              text: "Please select a student!"
                        });
                        $('#sf9_grade_table').empty()
                        return false      
                  }

                  var temp_student_grade = all_data.filter(x=>x.studid == $('#sf9_student_name').val())
                  var q1final = 0;
                  var q2final = 0;
                  var q3final = 0;
                  var q4final = 0;

                  $('#sf9_grade_table').empty()
                  var tem_gen_ava = 0;
                  $.each(temp_student_grade[0].grades,function(a,b){

                        q1final += b.q1;
                        q2final += b.q2;
                        q3final += b.q3;
                        q4final += b.q4;

                        if(select_gl == 14 || select_gl == 15){

                              var gradefinale = ( b.q1 + b.q2 ) / 2;

                              tem_gen_ava += parseInt(gradefinale.toFixed())

                              var remark = 'testing';
                              if(gradefinale.toFixed() >= 75){
                                    remark = 'PASSED'
                              }else{
                                    remark = 'FAILED'
                              }
                              $('#sf9_grade_table').append('<tr><td>'+b.subjdesc+'</td><td class="text-center">'+b.q1+'</td><td class="text-center">'+b.q2+'</td><td class="text-center">'+gradefinale.toFixed()+'</td><td class="text-center">'+remark+'</td></tr>')

                        }
                        else{

                              $('#sf9_grade_table').append('<tr><td>'+b.q1+'</td><td>'+b.q2+'</td></tr>')

                        }

                        if((a+1) ==  temp_student_grade[0].grades.length){

                          

                              if(select_gl == 14 || select_gl == 15){

                                    var gradefinale = tem_gen_ava / temp_student_grade[0].grades.length
                                    q1final = q1final / temp_student_grade[0].grades.length

                                    q2final = q2final / temp_student_grade[0].grades.length
                                    var remark = 'testing';
                                    if(gradefinale.toFixed() >= 75){
                                        remark = 'PASSED'
                                    }else{
                                         remark = 'FAILED'
                                    }
                                    $('#sf9_grade_table').append('<tr><td class="text-right">GENERAL AVERAGE</td><td class="text-center"></td><td class="text-center"></td><td class="text-center">'+gradefinale.toFixed()+'</td><td class="text-center">'+remark+'</td></tr>')
                              }
                              else{
                                    $('#sf9_grade_table').append('<tr><td>'+b.q1+'</td><td>'+b.q2+'</td></tr>')
                              }
                        }
                  })
            })

            function loaddatatable(data){
                
                var header = data[0];
                var data = data.filter(x => x.student != 'SUBJECTS')

                if(select_gl == 14 || select_gl == 15){
                    $('.for_gs').attr('hidden','hidden')
                    $('.pr').attr('colspan',2)
                }
                else{
                    $('.for_gs').removeAttr('hidden')
                    $('.pr').attr('colspan',4)
                }
               
                if(data.length == 0){

                    $("#sf9_sheet_table_list").DataTable({
                        destroy: true,
                        data:data,
                        "scrollX": true,
                        "columnDefs": [
                            {"title":"Student Name","targets":0},
                            // {"title":"Q1","targets":1},
                            // {"title":"Q2","targets":2},
                            // {"title":"Q3","targets":3},
                            // {"title":"Q4","targets":4},
                            {"title":"Final Rating","targets":1},
                            {"title":"Remarks","targets":2},
                        ]
                    })
                        
                }
                else{

                    $("#sf9_sheet_table_list").DataTable({
                        destroy: true,
                        data:data,
                        "scrollX": true,
                        columns: [
                                    { "data": "student" },
                                    { "data": null },
                                    { "data": null },
                                    // { "data": null },
                                    // { "data": null },
                                    // { "data": null },
                                    // { "data": null },
                            ],
                        "columnDefs": [
                            { "title": "STUDENT", 
                                "targets": 0,
                                'createdCell':  function (td, cellData, rowData, row, col) {
                                    $(td)[0].innerHTML = rowData.student
                                } 
                            },
                            // { "title": "Q1", 
                            //     "targets": 1,
                            //     'createdCell':  function (td, cellData, rowData, row, col) {
                            //         $(td).addClass('text-center')
                            //         var length = rowData.grades.length
                            //         var with_grade_count = rowData.grades.filter(x=>x.q1 != "" && x.q1 != null).length
                            //         var fg = 0
                            //         if(length != with_grade_count){
                            //             $(td).text( (length - with_grade_count ) + 'unposted grade')
                            //         }else{
                            //             $.each(rowData.grades,function(a,b){
                            //                 fg += b.q1
                            //             })

                            //             fg = fg / length
                                        
                            //         }
                            //         if(fg != 0){
                            //             $(td).text( fg.toFixed() )
                            //         }
                            //         else{
                            //             $(td).text(null)
                            //         }
                            //     } 
                            // },
                            // { "title": "Q2", 
                            //     "targets": 2,
                            //     'createdCell':  function (td, cellData, rowData, row, col) {
                            //         $(td).addClass('text-center')
                            //         var length = rowData.grades.length
                            //         var with_grade_count = rowData.grades.filter(x=>x.q2 != "" && x.q2 != null).length
                            //         var fg = 0
                            //         if(length != with_grade_count){
                            //             $(td).text( (length - with_grade_count ) + 'unposted grade')
                            //         }else{
                            //             $.each(rowData.grades,function(a,b){
                            //                 fg += b.q2
                            //             })
                            //             fg = fg / length
                            //         }
                            //         if(fg != 0){
                            //             $(td).text( fg.toFixed() )
                            //         }
                            //         else{
                            //             $(td).text(null)
                            //         }
                            //     } 
                            
                            // },
                            // { "title": "Q3", 
                            //     "targets": 3,
                            //     'createdCell':  function (td, cellData, rowData, row, col) {
                            //         if(select_gl == 14 || select_gl == 15){
                            //             $(td).attr('hidden','hidden')
                            //         }
                            //         else{
                            //             $(td).removeAttr('hidden')
                            //         }
                            //         $(td).addClass('text-center')
                            //         var length = rowData.grades.length
                            //         var with_grade_count = rowData.grades.filter(x=>x.q3 != "" && x.q3 != null).length
                            //         var fg = 0
                            //         if(length != with_grade_count){
                            //             $(td).text( (length - with_grade_count ) + 'unposted grade')
                            //         }else{
                            //             $.each(rowData.grades,function(a,b){
                            //                 fg += b.q3
                            //             })

                            //             fg = fg / length
                                        
                            //         }
                            //         if(fg != 0){
                            //             $(td).text( fg.toFixed() )
                            //         }
                            //         else{
                            //             $(td).text(null)
                            //         }
                            //     } 
                            
                            // },
                            // { "title": "Q4", 
                            //     "targets": 4,
                            //     'createdCell':  function (td, cellData, rowData, row, col) {
                            //         if(select_gl == 14 || select_gl == 15){
                            //             $(td).attr('hidden','hidden')
                            //         }
                            //         else{
                            //             $(td).removeAttr('hidden')
                            //         }
                            //         $(td).addClass('text-center')
                            //         var length = rowData.grades.length
                            //         var with_grade_count = rowData.grades.filter(x=>x.q4 != "" && x.q4 != null).length
                            //         var fg = 0
                            //         if(length != with_grade_count){
                            //             $(td).text( (length - with_grade_count ) + 'unposted grade')
                            //         }else{
                            //             $.each(rowData.grades,function(a,b){
                            //                 fg += b.q4
                            //             })

                            //             fg = fg / length
                                        
                            //         }
                            //         if(fg != 0){
                            //             $(td).text( fg.toFixed() )
                            //         }
                            //         else{
                            //             $(td).text(null)
                            //         }
                            //     } 
                            
                            // },
                            { "title": "Gen. Ave.", 
                                "targets": 1,
                                'createdCell':  function (td, cellData, rowData, row, col) {

                                    $(td).addClass('text-center')
                                    var genave = 0
                                    $.each(rowData.grades,function(a,b){
                                        if(select_gl == 14 || select_gl == 15){
                                            genave += parseInt( ( (b.q1 + b.q2) / 2 ).toFixed() )
                                        }else{

                                            if(fg1 != 0 && fg2 != 0 && fg3 != 0 && fg4 != 0){
                                                fg = ( fg1 + fg2 + fg3 + fg4 ) /4
                                            }
                                        }

                                    })

                                    genave = ( genave / rowData.grades.length ).toFixed()

                                    if(genave != 0){     
                                        $(td).text( genave )
                                    }
                                    else{
                                        $(td).text(null)
                                    }

                                    // var length = rowData.grades.length

                                    // var q1_grades = rowData.grades.filter(x=>x.q1 != "" && x.q1 != null).length
                                    // var q2_grades = rowData.grades.filter(x=>x.q2 != "" && x.q2 != null).length
                                    // var q3_grades = rowData.grades.filter(x=>x.q3 != "" && x.q3 != null).length
                                    // var q4_grades = rowData.grades.filter(x=>x.q4 != "" && x.q4 != null).length

                                    // var fg1 = 0;
                                    // var fg2 = 0;
                                    // var fg3 = 0;
                                    // var fg4 = 0;

                                    // var fg = 0;

                                    // if(q1_grades == length){
                                    //     $.each(rowData.grades,function(a,b){
                                    //         fg1 += b.q1
                                    //     })

                                    //     fg1 = fg1 / length;
                                    // }
                                    // if(q2_grades == length){
                                    //     $.each(rowData.grades,function(a,b){
                                    //         fg2 += b.q2
                                    //     })
                                    //     fg2 = fg2 / length
                                    // }
                                    // if(q3_grades == length){
                                    //     $.each(rowData.grades,function(a,b){
                                    //         fg3 += b.q3
                                    //     })
                                    //     fg3 = fg3 / length
                                    // }
                                    // if(q4_grades == length){
                                    //     $.each(rowData.grades,function(a,b){
                                    //         fg4 += b.q4
                                    //     })
                                    //     fg4 = fg4 / length;
                                    // }

                                    // if(select_gl == 14 || select_gl == 15){

                                    //     console.log(fg1 + ' - ' + fg2)
                                    //     if(fg1 != 0 && fg2 != 0){
                                    //         fg = ( fg1 + fg2) / 2
                                    //     }
                                    // }else{

                                    //     if(fg1 != 0 && fg2 != 0 && fg3 != 0 && fg4 != 0){
                                    //         fg = ( fg1 + fg2 + fg3 + fg4 ) /4
                                    //     }
                                    // }
                                  
                                    
                                  
                                } 
                            
                            },
                            { "title": "Remark", 
                                "targets": 2,
                                'createdCell':  function (td, cellData, rowData, row, col) {
                                    $(td).addClass('text-center')
                                    var length = rowData.grades.length

                                    var q1_grades = rowData.grades.filter(x=>x.q1 != "" && x.q1 != null).length
                                    var q2_grades = rowData.grades.filter(x=>x.q2 != "" && x.q2 != null).length
                                    var q3_grades = rowData.grades.filter(x=>x.q3 != "" && x.q3 != null).length
                                    var q4_grades = rowData.grades.filter(x=>x.q4 != "" && x.q4 != null).length

                                    var fg1 = 0;
                                    var fg2 = 0;
                                    var fg3 = 0;
                                    var fg4 = 0;

                                    var fg = 0;

                                    if(q1_grades == length){
                                        $.each(rowData.grades,function(a,b){
                                            fg1 += b.q1
                                        })
                                        fg1 = fg1 / length;
                                    }
                                    if(q2_grades == length){
                                        $.each(rowData.grades,function(a,b){
                                            fg2 += b.q2
                                        })
                                        fg2 = fg2 / length
                                    }
                                    if(q3_grades == length){
                                        $.each(rowData.grades,function(a,b){
                                            fg3 += b.q3
                                        })
                                        fg3 = fg3 / length
                                    }
                                    if(q4_grades == length){
                                        $.each(rowData.grades,function(a,b){
                                            fg4 += b.q4
                                        })
                                        fg4 = fg4 / length;
                                    }

                                    if(select_gl == 14 || select_gl == 15){
                                        if(fg1 != 0 && fg2 != 0){
                                            fg = ( fg1 + fg2) / 2
                                        }
                                    }else{
                                        if(fg1 != 0 && fg2 != 0 && fg3 != 0 && fg4 != 0){
                                            fg = ( fg1 + fg2 + fg3 + fg4 ) /4
                                        }
                                    }
                                    
                                    if(fg != 0){
                                        if(fg >= 75){
                                            $(td).text('PASSED')
                                        }else{
                                            $(td).text('FAILED')
                                        }
                                    }
                                    else{
                                        $(td).text(null)
                                    }
                                } 
                            
                            },

                        ]
                    });

                }

            }


        })
    </script>
       
    
@endsection


