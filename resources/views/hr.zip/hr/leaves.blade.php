

<!-- DataTables -->
<link rel="stylesheet" href="{{asset('plugins/datatables-bs4/css/dataTables.bootstrap4.css')}}">
<link rel="stylesheet" href="{{asset('plugins/summernote/summernote-bs4.css')}}">
<link rel="stylesheet" href="{{asset('plugins/select2/css/select2.min.css')}}">
<link rel="stylesheet" href="{{asset('plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')}}">
@extends(''.$extends.'')
@section('content')
<style>
    
    @media screen and (max-width : 906px){
        .desk{
        visibility:hidden;
        }
        .div-only-mobile{
        visibility:visible;
        }
        .viewtime{
            width: 200px !important;
        }
    }

</style>
<section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <!-- <h1>Leaves</h1> -->
          <h4 class="text-warning" style="text-shadow: 1px 1px 1px #000000">
          <!-- <i class="fa fa-chart-line nav-icon"></i>  -->
          LEAVES</h4>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="/home">Home</a></li>
            <li class="breadcrumb-item active">Leaves</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>
{{-- <div class="row">
    <div class="col-md-3">
        <div class="stats-info">
            <h6>Today Presents</h6>
            <h4>12 / 60</h4>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stats-info">
            <h6>Planned Leaves</h6>
            <h4>8 <span>Today</span></h4>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stats-info">
            <h6>Unplanned Leaves</h6>
            <h4>0 <span>Today</span></h4>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stats-info">
            <h6>Pending Requests</h6>
            <h4>12</h4>
        </div>
    </div>
</div> --}}
@if(session()->has('messageApproved'))
    <div class="alert alert-success alert-dismissible col-12">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <h5><i class="icon fas fa-check"></i> Alert!</h5>
        {{ session()->get('messageApproved') }}
    </div>
@endif
@if(session()->has('messageDispproved'))
    <div class="alert alert-success alert-dismissible col-12">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <h5><i class="icon fas fa-check"></i> Alert!</h5>
        {{ session()->get('messageDispproved') }}
    </div>
@endif
<div class="card">
            <div class="card-header bg-info">
                @if(auth()->user()->type == '10')
                    <div class="float-left">
                        <p class=""  >
                            <a href="#" class="btn btn-sm btn-light" data-toggle="modal" data-target="#addemployeeleave">
                                <i class="fa fa-plus text-muted"></i>
                            </a>
                            Apply leave 
                        </p>
                        <div id="addemployeeleave" class="modal custom-modal fade" role="dialog" style="display: none;" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                            <div class="modal-dialog modal-dialog-centered modal-md" role="document" style="color: black;">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title" >Leave Application</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                    </div>
                                    <div class="modal-body" style="text-align: none !important">
                                        <form action="/globalapplyleave" method="get">
                                            @csrf
                                            <label>Employee/s:</label>
                                            <div class="">
                                                <select id="select2" class="form-control select2 m-0 text-uppercase" multiple="multiple" data-placeholder="Select employee/s:" name="leaveapplicants[]" required>
                                                    <option></option>
                                                    @foreach($employees as $employee)
                                                        <option value="{{$employee->id}}">
                                                            {{strtoupper($employee->lastname)}}, {{strtoupper($employee->firstname)}} {{strtoupper($employee->suffix)}}
                                                        </option>
                                                    @endforeach
                                                </select>
                                                <br>
                                                <strong>Leave Type</strong>
                                                <select class="form-control form-control-sm" name="leavetype" required>
                                                    <option></option>
                                                    @foreach ($leavetypes as $leavetype)
                                                        <option value="{{$leavetype->id}}">{{$leavetype->leave_type}}</option>                        
                                                    @endforeach
                                                </select>
                                                <br>
                                                <label>DATE</label>
                                                <br>
                                                <label>From - To</label>
                                                <input type="text" class="form-control" id="leavedaterange" name="leavedaterange" required>
                                                <br>
                                                <label>Remarks</label>
                                                <br>
                                                <textarea id="compose-textarea" class="form-control" name="leaveremarks" style="height: 100px" required></textarea>
                                                <br>
                                            </div>
                                            <div class="submit-section">
                                                <button type="submit" class="btn btn-primary submit-btn float-right">Apply</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                @endif
                <div class="float-right"><p class=""  >Settings <a href="/leavesettings" class="btn btn-sm btn-light"><i class="fa fa-cogs text-muted"></i></a></p></div>
            </div>
            <div class="card-body">
                <div id="example1_wrapper" class="dataTables_wrapper dt-bootstrap4">
                    <div class="row">
                        <div class="col-sm-12 " style="overflow: scroll">
                            <table id="example1" style="font-size: 12px" class="table table-bordered table-striped dataTable" role="grid" aria-describedby="example1_info">
                                <thead class="bg-warning">
                                    <tr>
                                        {{-- <th>#</th> --}}
                                        <th>Employee</th>
                                        <th style="width:13%">Leave Type</th>
                                        <th style="width:10%">From</th>
                                        <th style="width:10%">To</th>
                                        <th style="width:10%">Days</th>
                                        <th>Reason</th>
                                        <th>Status</th>
                                        {{-- <th>Actions</th> --}}
                                    </tr>
                                </thead>
                                <tbody>
                                    @if(isset($leaves))
                                    @foreach ($leaves as $leave)
                                        <tr>
                                            @if($leave->usertypeid == '6')
                                            <td>{{$leave->name}}</td>
                                            @else
                                            <td>{{$leave->lastname}}, {{$leave->firstname}}</td>
                                            @endif
                                            <td>{{$leave->leave_type}}</td>
                                            <td>{{$leave->date_from}}</td>
                                            <td>{{$leave->date_to}}</td>
                                            <td>{{$leave->numofdays}}</td>
                                            <td>{{$leave->reason}}</td>
                                            <td>
                                                @if($leave->status == 'pending')
                                                    @if($leave->leaveapplicant == 1)
                                                    <button class="btn btn-sm btn-block btn-warning" disabled><strong>Pending</strong></button>
                                                    @else
                                                    <button class="btn btn-sm btn-block btn-warning" data-toggle="modal" data-target="#pending{{$leave->id}}"><strong>Pending</strong></button>
                                                    <div class="modal fade" id="pending{{$leave->id}}" style="display: none;" aria-hidden="true">
                                                        <div class="modal-dialog modal-md">
                                                            <form action="/leaves/changestatus" method="get" id="{{$leave->id}}" name="changestatus">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        @if($leave->usertypeid == '6')
                                                                        <h4 class="modal-title">{{$leave->name}}</h4>
                                                                        @else
                                                                        <h4 class="modal-title">{{$leave->lastname}}, {{$leave->firstname}}</h4>
                                                                        @endif
                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">×</span>
                                                                        </button>
                                                                    </div>
                                                                    <div class="modal-body leaveapprovalcontainer" style="text-align: none !important;">
                                                                        <input id="{{$leave->id}}" type="hidden" value="{{$leave->id}}" name="leaveid"/>
                                                                        <h4><strong>{{$leave->leave_type}} Leave</strong></h4>
                                                                        <br>
                                                                        Days: {{$leave->numdays}}
                                                                        <br>
                                                                        <br>
                                                                        From: {{$leave->date_from}}
                                                                        <br>
                                                                        <br>
                                                                        To: {{$leave->date_to}}
                                                                        <br>
                                                                        <br>
                                                                        <strong>Remarks</strong>
                                                                        <textarea id="{{$leave->id}}" class="form-control" name="content" rows="2" disabled>{{$leave->reason}}</textarea>
                                                                        <br>
                                                                        <!-- <div class="form-group clearfix">
                                                                            <div class="icheck-primary d-inline">
                                                                              <input type="radio" id="radioPrimary1" value="1" name="withorwithoutpay" >
                                                                              <label for="radioPrimary1">
                                                                                  With Pay
                                                                              </label>
                                                                            </div>
                                                                            <br>
                                                                            <br>
                                                                            <div class="icheck-primary d-inline">
                                                                              <input type="radio" id="withorwithoutpay" value="0" name="withorwithoutpay" checked="">
                                                                              <label for="withorwithoutpay">
                                                                                  Without Pay
                                                                              </label>
                                                                            </div>
                                                                        </div> -->
                                                                    </div>
                                                                    {{-- </div> --}}
                                                                    <div class="modal-footer justify-content-between">
                                                                        <input id="{{$leave->id}}" type="hidden" value="sad" name="status"/>
                                                                        <button type="button" class="btn btn-warning disapproved" id="disapproved{{$leave->id}}">Disapprove</button>
                                                                        <button type="button" class="btn btn-primary approves" id="approved{{$leave->id}}">Approve</button>
                                                                    </div>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                    @endif
                                                @elseif($leave->status == 'disapproved')
                                                    <button class="btn btn-sm btn-block btn-danger">Disapproved</button>
                                                @elseif($leave->status == 'approved')
                                                    <button class="btn btn-sm btn-block btn-success">Approved</button>
                                                @endif
                                            </td>
                                        </tr>
                                        
                                    @endforeach
                                    @endif
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<script src="{{asset('plugins/jquery/jquery.min.js')}}"></script>
<!-- Bootstrap 4 -->
<script src="{{asset('plugins/select2/js/select2.full.min.js')}}"></script>
<script src="{{asset('plugins/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
<!-- ChartJS -->
<script src="{{asset('plugins/chart.js/Chart.min.js')}}"></script>
<!-- DataTables -->
<script src="{{asset('plugins/datatables/jquery.dataTables.js')}}"></script>
<script src="{{asset('plugins/datatables-bs4/js/dataTables.bootstrap4.js')}}"></script>
<script src="{{asset('plugins/summernote/summernote-bs4.min.js')}}"></script>
<script src="{{asset('plugins/moment/moment.min.js')}}"></script>
<script src="{{asset('plugins/daterangepicker/daterangepicker.js')}}"></script>
<script>
    $(function () {
        
        $('.select2').select2();

        $("#example1").DataTable({
            pageLength : 10,
            lengthMenu: [[5, 10, 20, -1], [5, 10, 20, 'Show All']]
        });
        
        $('.compose-textarea').summernote({
            
            toolbar: []
        });
        $('#leavedaterange').daterangepicker({
            locale: {
                format: 'YYYY-MM-DD'
            }
        });
    })
   
    $(document).ready(function(){
        $('.note-editable').attr('contenteditable','false');
                $('.note-editable').css('backgroundColor','white');
                $('.note-editable').css('backgroundColor','white');
                $('.note-editor').removeClass('card');
        window.setTimeout(function () {
            $(".alert-success").fadeTo(500, 0).slideUp(500, function () {
                $(this).remove();
            });
        }, 5000);
        window.setTimeout(function () {
            $(".alert-danger").fadeTo(500, 0).slideUp(500, function () {
                $(this).remove();
            });
        }, 5000);
   })
   $(document).on('click', '.disapproved', function(){
    //    console.log($(this).closest('form[name=changestatus]'));
       $(this).prev('input').val($(this)[0].innerText);
       $(this).closest('form[name=changestatus]').submit();

   })
   $(document).on('click', '.approves', function(){
    //    console.log($(this).closest('form[name=changestatus]'));
       $(this).prev().prev('input').val($(this).text());
       $(this).closest('form[name=changestatus]').submit();

   });
//    $(document).on('click', 'input[name=withorwithoutpay]', function(){
//        if($(this).val() == '1'){
//             $('.leaveapprovalcontainer').append(
//                 '<labe>Amount</label>'+
//                 '<input type="number" class="form-control form-controlsm" name="payamount" id="payamount" placeholder="0.00" required>;'
//             )
//        }
//        else{
//            $('#payamount').remove();
//        }
//    })
  </script>
@endsection

