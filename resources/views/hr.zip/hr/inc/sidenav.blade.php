

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4 asidebar">
    <!-- Brand Logo -->
    <!-- <a href="/home" class="brand-link">
      <img src="{{asset('dist/img/AdminLTELogo.png')}}"
           alt="AdminLTE Logo"
           class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light">AdminLTE 3</span>
    </a> -->
    <div class="ckheader">
        <a href="#" class="brand-link sidehead">
            <img src="{{asset(DB::table('schoolinfo')->first()->picurl)}}"
               {{-- alt="{{DB::table('schoolinfo')->first()->abbreviation}}" --}}
               class="brand-image img-circle elevation-3"
               style="opacity: .8">
          <span class="brand-text font-weight-light" style="position: absolute;top: 6%;">{{DB::table('schoolinfo')->first()->abbreviation}}</span>
          <span class="brand-text font-weight-light" style="position: absolute;top: 50%;font-size: 16px!important;color:#ffc107"><b>HR'S PORTAL</b></span>
        </a>
    </div>
    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user (optional) -->
      <!-- <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="{{asset('dist/img/user2-160x160.jpg')}}" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
            <a href="#" class="d-block">{{auth()->user()->name}}</a>
        </div>
      </div> -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
            @php
            $hr_profile = Db::table('teacher')
                ->select(
                    'teacher.id',
                    'teacher.lastname',
                    'teacher.middlename',
                    'teacher.firstname',
                    'teacher.suffix',
                    'teacher.licno',
                    'teacher.tid',
                    'teacher.deleted',
                    'teacher.isactive',
                    'teacher.picurl',
                    'usertype.utype'
                    )
                ->join('usertype','teacher.usertypeid','=','usertype.id')
                ->where('teacher.userid', auth()->user()->id)
                ->first();
                
            $hr_info = Db::table('employee_personalinfo')
                ->select(
                    'employee_personalinfo.id as employee_personalinfoid',
                    'employee_personalinfo.nationalityid',
                    'employee_personalinfo.religionid',
                    'employee_personalinfo.dob',
                    'employee_personalinfo.gender',
                    'employee_personalinfo.address',
                    'employee_personalinfo.contactnum',
                    'employee_personalinfo.email',
                    'employee_personalinfo.maritalstatusid',
                    'employee_personalinfo.spouseemployment',
                    'employee_personalinfo.numberofchildren',
                    'employee_personalinfo.emercontactname',
                    'employee_personalinfo.emercontactrelation',
                    'employee_personalinfo.emercontactnum',
                    'employee_personalinfo.departmentid',
                    'employee_personalinfo.designationid',
                    'employee_personalinfo.date_joined'
                    )
                ->where('employee_personalinfo.employeeid',$hr_profile->id)
                ->get();
                $number = rand(1,3);
                if(count($hr_info)==0){
                    $avatar = 'assets/images/avatars/unknown.png';
                }
                else{
                    if(strtoupper($hr_info[0]->gender) == 'FEMALE'){
                        $avatar = 'avatar/T(F) '.$number.'.png';
                    }
                    else{
                        $avatar = 'avatar/T(M) '.$number.'.png';
                    }
                }
            @endphp
          <img src="{{asset($hr_profile->picurl)}}" onerror="this.onerror = null, this.src='{{asset($avatar)}}'" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info pt-0" style="    margin-top: -7px;">
            <a href="#" class="d-block">{{strtoupper(auth()->user()->name)}}</a>
            <h6 class="text-white m-0 text-warning">{{auth()->user()->email}}</h6>
        </div>
      </div>
      <!-- Sidebar Menu -->
                    <nav class="mt-2">
                        <ul class="nav nav-pills nav-sidebar flex-column side" data-widget="treeview" role="menu" data-accordion="false">
                            <!-- Add icons to the links using the .nav-icon class
                            with font-awesome or any other icon font library -->
                            <!-- <li class="nav-header text-warning"><h4>HR'S PORTAL</h4></li> -->
                            <li class="nav-item">
                                <a href="/home"  id="dashboard" class="nav-link {{Request::url() == url('/home') ? 'active' : ''}}">
                                    <i class="nav-icon fa fa-home"></i>
                                    <p>
                                        Home
                                    </p>
                                </a>
                            </li>
                            <li class="nav-header text-warning"><i class="fa fa-users text-warning"></i> EMPLOYEES</li>
                            
                            @php
                                date_default_timezone_set('Asia/Manila');
                                $date = date('Y-m-d');
                            @endphp
                            <li class="nav-item">
                                <a href="/employeeslist/dashboard" class="nav-link {{Request::url() == url('/employeeslist/dashboard') ? 'active' : ''}}">
                                    <i class="fa fa-users nav-icon"></i>
                                    <p>
                                        Employees
                                    </p>
                                </a>
                            </li>
                            
                            {{-- <li class="nav-item">
                                <a href="/attendance/{{Crypt::encrypt('dashboard')}}" class="nav-link {{Request::url() == url('/attendance'.'/'.Crypt::encrypt('dashboard')) ? 'active' : ''}}">
                                    <i class="fa fa-list-alt nav-icon"></i>
                                    <p>
                                        Attendance
                                    </p>
                                </a>
                            </li> --}}
                            <li class="nav-item">
                                <a href="/hr/attendance/index" class="nav-link {{Request::url() == url('/hr/attendance/index') ? 'active' : ''}}">
                                    <i class="fa fa-list-alt nav-icon"></i>
                                    <p>
                                        Attendance
                                    </p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="/leaves/dashboard" class="nav-link {{Request::url() == url('/leaves/dashboard') ? 'active' : ''}}">
                                    <i class="fa fa-file-contract nav-icon"></i>
                                    <p>
                                        Filed Leaves
                                    </p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="/overtime/dashboard" class="nav-link {{Request::url() == url('/overtime/dashboard') ? 'active' : ''}}">
                                    <i class="fa fa-file-contract nav-icon"></i>
                                    <p>
                                        Filed Overtimes
                                    </p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="/employeestatus/{{Crypt::encrypt('dashboard')}}" class="nav-link {{Request::url() == url('/employeestatus'.'/'.Crypt::encrypt('dashboard')) ? 'active' : ''}}">
                                    <i class="fa fa-user-check nav-icon"></i>
                                    <p>
                                        Employee Status
                                    </p>
                                </a>
                            </li>
                            <li class="nav-header text-warning"><i class="fa fa-cogs text-warning"></i> SETTINGS</li>
                            <li class="nav-item">
                                <a href="/requirements/dashboard" class="nav-link {{Request::url() == url('/requirements/dashboard') ? 'active' : ''}}">
                                    <i class="fa fa-file-import nav-icon"></i>
                                    <p>
                                        Employment Reqs.
                                    </p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="/hr/settings/departments/dashboard" class="nav-link {{Request::url() == url('/hr/settings/departments/dashboard') ? 'active' : ''}}">
                                    <i class="fa fa-building nav-icon"></i>
                                    <p>
                                        Departments
                                    </p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="/hr/settings/designations/dashboard" class="nav-link {{Request::url() == url('/hr/settings/designations/dashboard') ? 'active' : ''}}">
                                    <i class="fa fa-users-cog nav-icon"></i>
                                    <p>
                                        Designations
                                    </p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="/holidays" class="nav-link {{Request::url() == url('/holidays') ? 'active' : ''}}">
                                    <i class="fa fa-calendar-alt nav-icon"></i>
                                    <p>
                                        Holidays
                                    </p>
                                </a>
                            </li>
                            {{-- <li class="nav-item">
                                <a href="/hrbracketing" class="nav-link {{Request::url() == url('/hrbracketing') ? 'active' : ''}}">
                                    <i class="fa fa-list-alt nav-icon"></i>
                                    <p>
                                        Bracketing
                                    </p>
                                </a>
                            </li> --}}
                            <li class="nav-item">
                                <a href="/newdeductionsetup/{{Crypt::encrypt('dashboard')}}" class="nav-link {{Request::url() == url('/standarddeductions/dashboard') ? 'active' : ''}}">
                                {{-- <a href="/standarddeductions/{{Crypt::encrypt('dashboard')}}" class="nav-link {{Request::url() == url('/standarddeductions/dashboard') ? 'active' : ''}}"> --}}

                                    <i class="fa fa-minus-square nav-icon"></i>
                                    <p>
                                        Deductions
                                    </p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="/standardallowances/{{Crypt::encrypt('dashboard')}}" class="nav-link {{Request::url() == url('/standardallowances/dashboard') ? 'active' : ''}}">
                                    <i class="fa fa-plus-square nav-icon"></i>
                                    <p>
                                        Allowances
                                    </p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="/leavesettings" class="nav-link {{Request::url() == url('/leavesettings') ? 'active' : ''}}">
                                    <i class="fa fa-file-archive nav-icon"></i>
                                    <p>
                                        Leave Settings
                                    </p>
                                </a>
                            </li>
                            <li class="nav-header text-warning"><i class="fa fa-money-bill text-warning"></i> PAYROLL</li>
                            <li class="nav-item">
                                <a href="/hr/payroll/index" class="nav-link {{Request::url() == url('/hr/payroll/index') ? 'active' : ''}}">
                                    <i class="fa fa-money-bill nav-icon"></i>
                                    <p>
                                        Payroll
                                    </p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="/hr/payrollsummary/index" class="nav-link {{Request::url() == url('/hr/payrollsummary/index') ? 'active' : ''}}">
                                    <i class="fa fa-file-invoice nav-icon"></i>
                                    <p>
                                        Payroll Summary
                                    </p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="/hrreports/thirteenthmonth/{{Crypt::encrypt('view')}}" class="nav-link {{Request::url() == url('/hrreports/thirteenthmonth/'.Crypt::encrypt("view").'') ? 'active' : ''}}">
                                    <span class="nav-icon fa-stack">
                                        <!-- The icon that will wrap the number -->
                                        <span class="fa fa-square-o fa-stack-1x"></span>
                                        <!-- a strong element with the custom content, in this case a number -->
                                        <strong class="fa-stack" style="font-size:11px;">
                                            13<sup>th</sup>    
                                        </strong>
                                    </span>
                                    <p>
                                        13<sup>th</sup> Month
                                    </p>
                                </a>
                            </li>
                            {{-- <li class="nav-header">HR</li> --}}
                            <li class="nav-header text-warning">Your Portal</li>

                            @php
                                $priveledge = DB::table('faspriv')
                                                ->join('usertype','faspriv.usertype','=','usertype.id')
                                                ->select('faspriv.*','usertype.utype')
                                                ->where('userid', auth()->user()->id)
                                                ->where('faspriv.deleted','0')
                                                ->where('faspriv.privelege','!=','0')
                                                ->get();

                                $usertype = DB::table('usertype')->where('deleted',0)->where('id',auth()->user()->type)->first();

                            @endphp

                            @foreach ($priveledge as $item)
                                @if($item->usertype != Session::get('currentPortal'))
                                    <li class="nav-item">
                                        <a class="nav-link portal" href="/gotoPortal/{{$item->usertype}}" id="{{$item->usertype}}">
                                            <i class=" nav-icon fas fa-cloud"></i>
                                            <p>
                                                {{$item->utype}}
                                            </p>
                                        </a>
                                    </li>
                                @endif
                            @endforeach

                            @if($usertype->id != Session::get('currentPortal'))
                                <li class="nav-item">
                                    <a class="nav-link portal" href="/gotoPortal/{{$usertype->id}}">
                                        <i class=" nav-icon fas fa-cloud"></i>
                                        <p>
                                            {{$usertype->utype}}
                                        </p>
                                    </a>
                                </li>
                            @endif
                            @if(auth()->user()->type == 10 )
                            <li class="nav-item">
                                <a href="/employeedailytimerecord/dashboard" class="nav-link {{Request::url() == url('/employeedailytimerecord/dashboard') ? 'active' : ''}}">
                                    <i class="nav-icon fa fa-user-clock"></i>
                                    <p>
                                        Daily Time Record
                                    </p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="/applyleave/{{Crypt::encrypt('dashboard')}}"  id="dashboard" class="nav-link {{Request::url() == url('/applyleave/dashboard') ? 'active' : ''}}">
                                    <i class="nav-icon fa fa-leaf"></i>
                                    <p>
                                        Apply Leave
                                    </p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="/applyovertimedashboard/{{Crypt::encrypt('dashboard')}}"  id="dashboard" class="nav-link {{Request::url() == url('/applyovertimedashboard/dashboard') ? 'active' : ''}}">
                                    <i class="nav-icon fa fa-clock"></i>
                                    <p>
                                        Apply Overtime
                                    </p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="/employeepayrolldetails"  id="employeepayrolldetails" class="nav-link {{Request::url() == url('/employeepayrolldetails') ? 'active' : ''}}">
                                    <i class="nav-icon fa fa-clock"></i>
                                    <p>
                                        Payroll Details
                                    </p>
                                </a>
                            </li>
                            @endif
                            <li class="nav-header text-warning"><i class="fa fa-folder-open text-warning"></i> REPORTS</li>
                            <li class="nav-item">
                                <a href="/summaryofattendance/dashboard" class="nav-link {{Request::url() == url('/summaryofattendance/dashboard') ? 'active' : ''}}">
                                    <i class="nav-icon fa fa-calendar-check"></i>
                                    <p>
                                        Attendance Report
                                    </p>
                                </a>
                            </li>
                        </ul>
                        <br>
                        <br>
                        <br>
                    </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>